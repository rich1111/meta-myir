# Data I/O

- 參考專案：[Modbus-DataIO-v34b](http://192.168.11.201/jack.chen/Modbus-DataIO-v34b)
- 網頁路徑：`Modbus-DataIO-v34b/firmware/<MODULE>/WebPages2`<br/>
  `MODULE` 為以下 (不包含 `DAR01-CPU02.X`)
  - `MOD2008-4AI+4AO.X`
  - `MOD2108-8AI.X`
  - `MOD2208-8AO.X`
  - `MOD2012-8DI+4RLY.X`
  - `MOD2016-8DI+8DO.X`
  - `MOD2016-8DI+6DO+2PWM.X`
  - `MOD2116-16DI.X`
  - `MOD2216-16DO.X`

## 開發注意事項
protocol的MQTT完成8AI、8AO但沒有測試
**只要有更動到 `.htm`，記得執行以下腳本**

在專案根目錄執行

```
$ sh ./scripts/generate_page_contents.sh
```

## Copying to remote server

- scp -r * root@192.168.1.220:/www/data_io
- scp -r * root@192.168.1.201:/www/data_io
- root / eWinsonicOT!
- 8AO

## 當Jack有整個更新，需要換掉舊的Token時執行以下
- ssh-keygen -R 192.168.1.201
- ssh root@192.168.1.201
- exit

# Nginx Settings

## Path:

- /etc/nginx/conf.d/luci.locations

## Add below

location /data_io/ {
try_files $uri /data_io/index.htm;
}