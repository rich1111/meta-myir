changeModuleType = (moduleTypeCode) => {
  currentModuleType = moduleTypeCode;
  // navSelectModuleTypeDropdown_label.innerText = MODULE_TYPE_CODE[moduleTypeCode];

  let showDigital = false;
  let showDi16Status = false;
  let showDo16Status = false;
  let showDicounter = true;
  let showDoPulse = false;
  let showPwm = false;
  let showAnalog = false;
  let showAi8 = false;
  let showAo8 = false;
  let showRelay = false;
  let showSnmp = true;

  let navDigitalText = "I / O Status";

  switch (moduleTypeCode) {
    case MODULE_TYPE_CODE.MOD008:
      showAnalog = true;
      showSnmp = false;
      break;
    case MODULE_TYPE_CODE.MOD108:
      showAi8 = true;
      showSnmp = false;
      break;
    case MODULE_TYPE_CODE.MOD208:
      showAo8 = true;
      showSnmp = false;
      break;
    case MODULE_TYPE_CODE.MOD012:
      showRelay = true;
      // showDicounter = true;
      showDoPulse = true;
      break;
    case MODULE_TYPE_CODE.MOD016:
      showDigital = true;
      // showDicounter = true;
      showDoPulse = true;
      break;
    case MODULE_TYPE_CODE.MOD016P:
      showDigital = true;
      // showDicounter = true;
      showDoPulse = true;
      showPwm = true;
      break;
    case MODULE_TYPE_CODE.MOD116:
      showDi16Status = true;
      // showDicounter = true;
      break;
    case MODULE_TYPE_CODE.MOD216:
      navDigitalText = "Output Status";
      showDo16Status = true;
      showDoPulse = true;
      break;
  }

  // navDigitalItem.parentNode.style.display = showDigital ? "block" : "none";
  // navDigitalItem.querySelector("span").innerText = navDigitalText;
  // navDi16StatusItem.parentNode.style.display = showDi16Status ? "block" : "none";
  // navDo16StatusItem.parentNode.style.display = showDo16Status ? "block" : "none";
  // navDoPulseItem.parentNode.style.display = showDoPulse ? "block" : "none";
  // navPwmItem.parentNode.style.display = showPwm ? "block" : "none";
  // navAnalogItem.parentNode.style.display = showAnalog ? "block" : "none";
  // navAo8Item.parentNode.style.display = showAo8 ? "block" : "none";
  // navAi4Ao4TuningItem.parentNode.style.display = showAnalog ? "block" : "none";
  // navAi8CalibrationItem.parentNode.style.display = showAi8 ? "block" : "none";
  // navSnmpItem.parentNode.style.display = showSnmp ? "block" : "none";

  // navDicounterItem.parentNode.style.display = showDicounter ? "block" : "none";
  // navRelayItem.parentNode.style.display = showRelay ? "block" : "none";

}