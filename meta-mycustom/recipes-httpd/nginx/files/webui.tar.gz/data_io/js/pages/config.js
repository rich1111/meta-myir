class ConfigPage {
  constructor(props) {
    this.state = {
      dhcp: true
    };
    this.init();
  }

  init = async () => {
    const config = await Api.getNetConfig();
    this.setNetConfig(config);

    if (!(currentPage instanceof ConfigPage)) {
      return;
    }
    const passSubmit = document.getElementById("passSubmit");
    if (passSubmit) {
      passSubmit.addEventListener('click', this.submitPassword);
    }
    const netSubmit = document.getElementById("netSubmit");
    if (netSubmit) {
      netSubmit.addEventListener('click', this.submitNetwork);
    }

    const dhcp = document.getElementById("dhcp");
    if (dhcp) {
      dhcp.addEventListener('click', this.switchIPType);
    }
    const staticIP = document.getElementById("staticIP");
    if (staticIP) {
      staticIP.addEventListener('click', this.switchIPType);
    }
  }

  setNetConfig = (config) => {
    this.setStaticIP(config.proto);
    const ipAddress = document.getElementById("ipAddress");
    const subnetMask = document.getElementById("subnetMask");
    const gateway = document.getElementById("gateway");
    ipAddress.value = config.ipaddr;
    subnetMask.value = config.netmask;
    gateway.value = config.gateway;
  }

  submitPassword = async (e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };
    try {
      const oldPassword = document.getElementById("oldPassword").value;
      const newPassword = document.getElementById("newPassword").value;
      const confirmPassword = document.getElementById("confirmPassword").value;
      // Check if passwords input & match
      if (oldPassword === "" || newPassword === "" || confirmPassword === "") {
        customErrorProps.data.error.message = "Old and New password fields must be filled!";
        throw new CustomError(customErrorProps);
      }
      if (newPassword !== confirmPassword) {
        customErrorProps.data.error.message = "Confirm password does not match!";
        throw new CustomError(customErrorProps);
      }
      DialogUtility.confirm({ text: "Change password! You will need to re-login with new password!" }).then(async (result) => {
        if (result.isConfirmed) {
          const payload = {
            username: "admin",
            oldpassword: oldPassword,
            newpassword: newPassword
          };
          const result = await Api.changePassword(payload).catch((err) => {
            ErrorUtility.handleError(err);
          });
          if (result.code === 400) {
            DialogUtility.showError({ title: "Password change failed!", text: result.message });
          } else {
            //DialogUtility.showSuccess({});
            location.replace("./login.html");
          }
        }
      });

    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  submitNetwork = async (e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };

    try {
      const isDHCP = this.state.dhcp;
      console.log("DHCP:", isDHCP);
      const payload = {
        proto: "dhcp",
        ipaddr: "",
        netmask: "",
        gateway: "",
        broadcast: ""
      };
      if (!isDHCP) {
        const ipAddress = document.getElementById("ipAddress").value;
        const subnetMask = document.getElementById("subnetMask").value;
        const gateway = document.getElementById("gateway").value;
        // Check if valid ip's
        if (StringUtility.validIP(ipAddress) === false) {
          customErrorProps.data.error.message = "IP Address is invalid!";
          throw new CustomError(customErrorProps);
        }
        if (StringUtility.validIP(subnetMask) === false) {
          customErrorProps.data.error.message = "Subnet Mask is invalid!";
          throw new CustomError(customErrorProps);
        }
        if (StringUtility.validIP(gateway) === false) {
          customErrorProps.data.error.message = "Gateway IP is invalid!";
          throw new CustomError(customErrorProps);
        }
        payload.proto = "static";
        payload.ipaddr = ipAddress;
        payload.netmask = subnetMask;
        payload.gateway = gateway;
      }

      DialogUtility.confirm({ text: "Reset IP! System will automatically use the new settings!" }).then(async (result) => {
        if (result.isConfirmed) {
          const res = await Api.setNetConfig(payload);
          DialogUtility.showSuccess({});
        }
      });
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  switchIPType = async (e) => {
    console.log(e);
    this.setStaticIP(e.srcElement.defaultValue);
  }

  setStaticIP(selected) {
    if (selected === "dhcp") {
      document.getElementById("dhcp").checked = true;
    } else if (selected === "static") {
      document.getElementById("staticIP").checked = true;
    }
    const disable = selected === "dhcp" ? true : false;
    // Set whether DHCP in state
    this.state = { dhcp: disable };
    const ipAddress = document.getElementById("ipAddress");
    const subnetMask = document.getElementById("subnetMask");
    const gateway = document.getElementById("gateway");
    ipAddress.disabled = disable;
    subnetMask.disabled = disable;
    gateway.disabled = disable;
  }


  dispose() {
    const passSubmit = document.getElementById("passSubmit");
    const netSubmit = document.getElementById("netSubmit");

    passSubmit.removeEventListener('click', this.submitPassword);
    netSubmit.removeEventListener('click', this.submitNetwork);
  }

}