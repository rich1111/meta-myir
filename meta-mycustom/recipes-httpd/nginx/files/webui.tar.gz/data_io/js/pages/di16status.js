
class Di16StatusPage {
  constructor(props) {
    this.state = {
      refereshTime: 1000,
      intervalId: undefined
    };

    this.init();
  }

  init = async () => {

    const { refereshTime } = this.state;

    this.loadPage();

    this.state.intervalId = setInterval(
      this.loadPage, refereshTime
    );

    this.initIntervalSelect();
  }

  onRefreshTimeChange = (e) => {
    try {
      const value = parseInt(e.target.value);
      if (isNaN(value)) {
        throw Error();
      }

      this.state.refereshTime = value;

      const { intervalId } = this.state;
      if (intervalId) {
        clearInterval(intervalId);
      }

      this.state.intervalId = setInterval(
        this.loadPage,
        this.state.refereshTime
      );
    } catch (error) {
      console.error(error);
      DialogUtility.showError({
        title: "Change Time Error",
        text: "Changing freshing time failed, please retry",
      });
    }
  }

  initIntervalSelect = () => {
    const refreshSelect = document.getElementById("refresh");
    const {
      refereshTime,
    } = this.state;

    if (refreshSelect) {
      refreshSelect.value = refereshTime;
      refreshSelect.addEventListener('change', this.onRefreshTimeChange);
    }
  }


  loadPage = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    if (mainstat == null || loadstat == null) {
      return;
    }

    // Make sure we're displaying the status display
    mainstat.style.display = 'inline';
    loadstat.style.display = 'none';

    try {

      const di = (await Api.getDigitalInput()).io.di;
      for (let i = 0; i < 16; i++) {
        let entry = di.filter((e) => e.diIndex == i)[0];
        let cellElem = document.getElementById("di_" + i);
        let flag = 0 < entry?.diStatus;
        setCircle(cellElem, flag);
      }

      const lastUpdateTimeElem = document.getElementById("lastUpdateTime");
      const now = (new Date()).toUTCString();
      setInnerText(lastUpdateTimeElem, now);

    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  dispose() {
    const { intervalId } = this.state;
    if (intervalId) {
      clearInterval(intervalId);
    }
  }
}