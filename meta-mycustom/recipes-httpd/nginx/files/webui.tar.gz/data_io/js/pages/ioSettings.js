/**
 * For module 12, 16, 116
 */
class IOSettingsPage {
  constructor(props) {
    this.state = {
      inputBoard: [],
      outputBoard: [],
      modType: "",
      haveIandO: false,
      isAorD: "",
      inputPort: 0,
      outputPort: 0,
      intervalId: undefined,
      refreshTime: 1000,
      diCounterResetStatus : Array(16).fill(0),
      buttonStatus: false,
    };

    this.init();
    setDisableWithButton();
  }

  init = () => {
    switch (currentModuleType) {
      case MODULE_TYPE_CODE.MOD012:
        this.state.modType = "8DI4RELAY";
        this.state.haveIandO = true;
        this.state.inputPort = 8;
        this.state.outputPort = 4;
        this.state.isAorD = "DIDO";
        break;
      case MODULE_TYPE_CODE.MOD016:
        this.state.modType = "8DI8DO";
        this.state.haveIandO = true;
        this.state.inputPort = 8;
        this.state.outputPort = 8;
        this.state.isAorD = "DIDO";
        break;
      case MODULE_TYPE_CODE.MOD116:
        this.state.modType = "16DI";
        this.state.inputPort = 16;
        this.state.isAorD = "DI";
        break;
      case MODULE_TYPE_CODE.MOD216:
        this.state.modType = "16DO";
        this.state.outputPort = 16;
        this.state.isAorD = "DO";
        break;
      case MODULE_TYPE_CODE.MOD108:
        this.state.modType = "8AI";
        this.state.inputPort = 8;
        this.state.isAorD = "AI";
        break;
      case MODULE_TYPE_CODE.MOD208:
        this.state.modType = "8AO";
        this.state.outputPort = 8;
        this.state.isAorD = "AO";
        break;
    }
    const { modType } = this.state;
    if(modType === "16DI"){
      this.initInputPage();
      this.addOption();
      this.initInputButtons();
    } else if(modType === "16DO"){
      this.initOutputPage("16DO");
      this.addOption();
      this.initOutputButtons();
    } else if(modType === "8DI4RELAY" || modType === "8DI8DO"){
      this.initInputPage();
      this.initOutputPage("8DOandRelay");
      this.addOption();
      this.initInputButtons();
      this.initOutputButtons();
    } else if(modType === "8AI"){
      this.initAIPage();
    } else if(modType === "8AO"){
      this.initAOPage();
    }
    this.initButton();
    this.initIntervalSelect();

    this.state.intervalId = setInterval(this.loadingPage, this.state.refreshTime);
  }

  addOption = () => {
    const refreshSelect = document.getElementById("refresh");
    const newOption = document.createElement("option");
    newOption.value = "500";
    newOption.text = "500";
    refreshSelect.prepend(newOption);
  }
  
  // getPeerToPeer = async() => {
  //   console.log(this.state.p2pServer);
  //   const server = (await Api.getPeerToPeerSettings()).server;
  //   const getChStatus = server.map(item => item.enabled === 1 ? item : null).filter(item => item !== null);
  //   this.state.p2pServer = Array(this.state.outputPort).fill(true);
  //   if(getChStatus.length > 0){
  //     for(let i = 0; i < getChStatus.length; i++){
  //       const getCh = getChStatus[i].channelID;
  //       const getNumber = Number(getCh.split('-')[1]);
  //       const localCount = getChStatus[i].localCount;
  //       for(let j = 0; j < localCount; j++){
  //         this.state.p2pServer[getNumber + j] = false;
  //       }
  //     }
  //   }
  // }


  initInputPage = () => {
    const displayInput = document.getElementById("displayInput");

    try {
      displayInput.innerHTML = `
      <table class="table table-bordered" style="table-layout:fixed">
        <thead id="inputThead">
          <tr>
            <th width="80px">Channel</th>
            <th width="180px">Channel Alias Name</th>
            <th width="110px">Mode</th>
            <th width="70px">Signal</th>
            <th width="14%">Filter</th>
            <th width="9%">Counter Value</th>
            <th width="11%">CNTR Setting</th>
            <th width="11%">Trigger</th>
            <th width="7%">Freq</th>
            <th width="8%">CNTR Reset</th>
          </tr>
        </thead>
        <tbody id="inputTbody">
        </tbody>
      </table>
      `;

      const inputTbody = document.getElementById("inputTbody");
      for(let i = 0; i < this.state.inputPort; i++){
        const inputRow = document.createElement("tr");
        inputRow.innerHTML = `
          <td><span id="DI_${i}">DI-${i < 10 ? "0"+i : i}</span></td>
					<td><span id="DI_AN${i}"></span></td>
					<td>
						<select id="DI_EN${i}" style="width:90px;border: none;" disabled>
							<option value="0">DI</option>
							<option value="1">Counter</option>
						</select>
					</td>
					<td><span id="DI_S${i}">?</span></td>
          <td style="padding-right: 10px"><span id="DI_FT${i}"></span><span style="float:right;">0.1ms</span></td>
					<td><span id="DI_VAL${i}">?</span></td>
          <td>
						<select id="DI_CNTRS${i}" style="width:90px;border: none;" disabled>
							<option value="0">Restart</option>
							<option value="1">Continue</option>
						</select>
					</td>
          <td>
						<select id="DI_HL${i}" style="width:90px;border: none;" disabled>
							<option value="0">Low-Hi</option>
							<option value="1">Hi-Low</option>
              <option value="2">Both</option>
						</select>
					</td>
          <td><span id="DI_FRQ${i}">?</span></td>
					<td><button id="DI_RST${i}" type="button" disabled>Reset</button>
					</td>
        `;
        inputTbody.appendChild(inputRow);
      }
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }
  initOutputPage = (type) => {
    const displayOutput = document.getElementById("displayOutput");
    
    try {
      displayOutput.innerHTML = `
      <table class="${type === "16DO" ? "table table-bordered" : "table table-bordered margin-top10"}" style="table-layout:fixed;">
        <thead id="outputThead">
          <tr>
            <th width="80px">Channel</th>
            <th width="180px">Channel Alias Name</th>
            <th width="110px">Mode</th>
            <th width="70px">Signal</th>
            <th width="15%">Power On Default</th>
            <th width="10%">Status</th>
            <th width="12%">Pulse Count</th>
            <th width="11.5%">ON Width</th>
            <th width="11.5%">OFF Width</th>
          </tr>
        </thead>
        <tbody id="outputTbody">
        </tbody>
      </table>
      `;
      const outputTbody = document.getElementById("outputTbody");

      for(let i = 0; i < this.state.outputPort; i++){
        const outputRow = document.createElement("tr");
        outputRow.innerHTML = `
          ${this.state.modType === "8DI4RELAY" ? `<td><span id="DO_${i}">Relay-${"0" + i}</span></td>` : `<td><span id="DO_${i}">DO-${i < 10 ? "0" + i : i}</span></td>`}
          <td><span id="DO_AN${i}"></span></td>
          <td>
            <select id="DO_PSE${i}" style="width:90px;border: none;" disabled>
              <option value="0">DO</option>
              <option value="1">Pulse</option>
            </select>
          </td>
          <td><button id="DO_S${i}" type="button" style="width:40px;" disabled>?</button></td>
          <td>
            <select id="DO_DF${i}" style="width:110px;border: none;" disabled>
              <option value="-1">Disable</option>
              <option value="0">L-Enable</option>
              <option value="1">H-Enable</option>
            </select>
          </td>
          <td><span id="DO_STATUS${i}">?</span></td>
          <td><span id="doPulseCount_${i}"></span></td>
          <td><span id="doPulseOnWidth_${i}"></span></td>
          <td><span id="doPulseOffWidth_${i}"></span></td>
        `;
        outputTbody.appendChild(outputRow);
      }
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  initAIPage = () => {
    const { inputPort } = this.state;
    const displayInput = document.getElementById("displayInput");

    try {
      displayInput.innerHTML = `
      <table class="table table-bordered" style="table-layout:fixed">
        <thead id="inputThead">
          <tr>
          <th width="80px">Channel</th>
          <th width="180px">Channel Alias Name</th>
          <th width="110px">Mode</th>
          <th width="12%">Range</th>
          <th width="12%">Present Value</th>
          <th width="12%">Min. In. Value</th>
          <th width="12%">Max. In. Value</th>
          <th width="14%">Status</th>
          </tr>
        </thead>
        <tbody id="inputTbody"></tbody>
      </table>
      `;
      
      const inputTbody = document.getElementById("inputTbody");
      for(let i = 0; i < inputPort; i++){
        const tbodyRow = document.createElement("tr");
        tbodyRow.innerHTML = `
          <td style="height:31px;"><span id="AI_${i}">AI-0${i}</span></td>
          <td><span id="AI_AN${i}"></span></td>
          <td><span id="AI_MODE${i}"></span></td>
          <td><span id="AI_RANGE${i}"></span></td>
          <td><span id="AI_CV${i}"></span></td>
          <td><span id="AI_MIN${i}"></span></td>
          <td><span id="AI_MAX${i}"></span></td>
          <td><span id="AI_STATUS${i}"></span></td>
        `;
        inputTbody.appendChild(tbodyRow);
      }
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  initAOPage = () => {
    const { outputPort } = this.state;
    const displayOutput = document.getElementById("displayOutput");

    try {
      displayOutput.innerHTML = `
      <table class="table table-bordered" style="table-layout:fixed;">
        <thead id="outputThead">
          <tr>
            <th width="80px">Channel</th>
            <th width="180px">Channel Alias Name</th>
            <th width="110px">Mode</th>
            <th width="12%">Range</th>
            <th width="12%">Present Value</th>
            <th width="11%">Default Value</th>
            <th width="14%">Power On Default</th>
            <th width="13%">Status</th>
          </tr>
        </thead>
        <tbody id="outputTbody"></tbody>
      </table>
      `;

      const outputTbody = document.getElementById("outputTbody");
      for(let i = 0; i < outputPort; i++){
        const outputRow = document.createElement("tr");
        outputRow.innerHTML = `
          <td style="height:31px;"><span id="AO_${i}">AO-0${i}</span></td>
          <td><span id="AO_AN${i}"></span></td>
          <td>
            <select id="AO_MODE${i}" style="width:90px;border: none;" disabled>
              <option value="0">Voltage</option>
              <option value="2">Current</option>
						</select>
          </td>
          <td><span id="AO_RANGE${i}"></span></td>
          <td><span id="AO_CV${i}"></span></td>
          <td><span id="AO_DV${i}"></span></td>
          <td><input id="AO_DE${i}" type="checkbox" disabled></td>
          <td><span id="AO_STATUS${i}"></span></td>
        `;
        outputTbody.appendChild(outputRow);
      }
      this.initAOButton();
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  initInputButtons = () => {
    for(let i = 0; i < this.state.inputPort; i++){
      const DI_RST_button = document.getElementById(`DI_RST${i}`);
      const DI_EN_select = document.getElementById(`DI_EN${i}`);
      const DI_CNTRS_select = document.getElementById(`DI_CNTRS${i}`);
      const DI_HL_select = document.getElementById(`DI_HL${i}`);

      if (DI_RST_button == null || DI_EN_select == null || DI_CNTRS_select == null || DI_HL_select == null) {
        continue;
      }

      DI_RST_button.addEventListener('click', (e) => {
        this.state.diCounterResetStatus[i] = 1; // 記錄這個按鈕的狀態為 1 (已經按下)
        }
      );
      DI_EN_select.addEventListener('change', (e) => {        
        this.renderBackgroundColor(i, "DI", Number(e.target.value));
      });

      DI_CNTRS_select.addEventListener('change', (e) => {
        this.renderBackgroundColor(i, "DI", Number(e.target.value));
      });

      DI_HL_select.addEventListener('change', (e) => {
        this.renderBackgroundColor(i, "DI", Number(e.target.value));
      });
    }
  }
  initOutputButtons = () => {
    for(let i = 0; i < this.state.outputPort; i++){
      const DO_PSE_select = document.getElementById(`DO_PSE${i}`);
      const DO_S_button = document.getElementById(`DO_S${i}`);
      const DO_DF_select = document.getElementById(`DO_DF${i}`);
    
      if (DO_PSE_select == null || DO_S_button == null || DO_DF_select == null) {
        continue;
      }
      DO_S_button.addEventListener('click', (e) => {
        e.target.innerHTML = e.target.innerHTML === "H" ? "L" : "H";
        e.target.style.color = e.target.innerHTML === "H" ? "#00FF00" : "#000000";
      });

      DO_PSE_select.addEventListener('change', (e) => {
        this.renderBackgroundColor(i, "DO", Number(e.target.value));
      });
    }
  }
  initAOButton = () => {
    for(let i = 0; i < this.state.outputPort; i++){
      const AO_MODE_select = document.getElementById(`AO_MODE${i}`);
      const AO_DE_checkBox = document.getElementById(`AO_DE${i}`);

      if (AO_MODE_select == null || AO_DE_checkBox == null) {
        continue;
      }

      AO_MODE_select.addEventListener('change', (e) => {
        this.renderBackgroundColor(i, "AO", Number(e.target.value));
        const AO_DV = document.getElementById(`AO_DV${i}`);
        AO_DV.max = e.target.value === "0" ? 10 : 20;
        const AO_CV = document.getElementById(`AO_CV${i}`);
        AO_CV.max = e.target.value === "0" ? 10 : 20;
      });
    }
  }

  initButton = () => {
    const { inputPort, outputPort, modType, diCounterResetStatus } = this.state;
    rename.addEventListener("click", (e) => {
      e.preventDefault();
      this.state.buttonStatus = true;
      const refreshTime = document.getElementById('refresh-time');
      const save = document.getElementById("save");
      const rename = document.getElementById("rename");
      const refreshSelect = document.getElementById("refresh");
  
      try {
        const { intervalId } = this.state;
        if (intervalId) {
          clearInterval(intervalId);
        }
        refreshTime.style.backgroundColor = "#a8a8a8";
        refreshSelect.disabled = true;
        if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DI"){
          for (let i = 0; i < inputPort; i++) {
            const diCounterStatus = document.getElementById('DI_EN' + i);
            const DI_FT = document.getElementById('DI_FT' + i);
            const DI_CNTRS = document.getElementById('DI_CNTRS' + i);
            const DI_HL = document.getElementById('DI_HL' + i);
            const diCounterReset = document.getElementById('DI_RST' + i);
            const diAliasSpan = document.getElementById('DI_AN' + i);
            const diInputElement = document.createElement('input');
            

            diInputElement.id = 'DI_AN' + i;
            diInputElement.style.width = '160px';
            diInputElement.style.marginBottom = '0px';
            diInputElement.type = 'text';
            diInputElement.value = diAliasSpan.innerHTML;
            
            diAliasSpan.parentNode.replaceChild(diInputElement, diAliasSpan);

            const DI_FT_Input = document.createElement('input');
            DI_FT_Input.id = 'DI_FT' + i;
            DI_FT_Input.style.width = '70px';
            DI_FT_Input.type = 'number';
            DI_FT_Input.min = 0;
            DI_FT_Input.max = 65535;
            DI_FT_Input.title = "Range: 1-65535; 0 is disabled";
            DI_FT_Input.disabled = true;
            DI_FT_Input.value = DI_FT.innerHTML;
            DI_FT.parentNode.replaceChild(DI_FT_Input, DI_FT);

            diCounterStatus.disabled = false;
            if(diCounterStatus.value === "1"){
              DI_FT_Input.disabled = true;
              DI_CNTRS.disabled = false;
              DI_HL.disabled = false;
              diCounterReset.disabled = false;
            } else if(diCounterStatus.value === "0"){
              DI_FT_Input.disabled = false;
              DI_CNTRS.disabled = true;
              DI_HL.disabled = true;
              diCounterReset.disabled = true;
            }
            // DI_FT_Input.parentNode.style.paddingLeft = "10px";
          }
        }
        if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DO"){
          for (let i = 0; i < outputPort; i++) {
            const doPulseStatus = document.getElementById('DO_PSE' + i);
            const doAliasSpan = document.getElementById('DO_AN' + i);
            const doInputElement = document.createElement('input');

            const DO_S = document.getElementById('DO_S' + i);
            const DO_DF = document.getElementById('DO_DF' + i);
            const DO_STATUS = document.getElementById('DO_STATUS' + i);
            const doPulseCountSpan = document.getElementById('doPulseCount_' + i);
            const doPulseOnWidthSpan = document.getElementById('doPulseOnWidth_' + i);
            const doPulseOffWidthSpan = document.getElementById('doPulseOffWidth_' + i);
    
            const doPulseCountInput = document.createElement('input');
            const doPulseOnWidthInput = document.createElement('input');
            const doPulseOffWidthInput = document.createElement('input');
    
            doInputElement.id = 'DO_AN' + i;
            doInputElement.style.width = '160px';
            doInputElement.style.marginBottom = '0px';
            doInputElement.type = 'text';
            doInputElement.value = doAliasSpan.innerHTML;

            doPulseStatus.disabled = false;
            doPulseCountInput.id = 'doPulseCount_' + i;
            doPulseCountInput.style.width = '80px';
            doPulseCountInput.style.marginBottom = '0px';
            doPulseCountInput.type = 'number';
            doPulseCountInput.maxLength = '2';
            doPulseCountInput.min = 0;
            doPulseCountInput.max = 65535;
            doPulseCountInput.title = "Range: 1-65535;0 is always";
            doPulseCountInput.disabled = true;
            doPulseCountInput.value = doPulseCountSpan.innerHTML;
    
            doPulseOnWidthInput.id = 'doPulseOnWidth_' + i;
            doPulseOnWidthInput.style.width = '80px';
            doPulseOnWidthInput.style.marginBottom = '0px';
            doPulseOnWidthInput.type = 'number';
            doPulseOnWidthInput.maxLength = '2';
            doPulseOnWidthInput.min = 500;
            doPulseOnWidthInput.max = 65535;
            doPulseOnWidthInput.title = "Range: 500-65535";
            doPulseOnWidthInput.disabled = true;
            doPulseOnWidthInput.value = doPulseOnWidthSpan.innerHTML;
    
            doPulseOffWidthInput.id = 'doPulseOffWidth_' + i;
            doPulseOffWidthInput.style.width = '80px';
            doPulseOffWidthInput.style.marginBottom = '0px';
            doPulseOffWidthInput.type = 'number';
            doPulseOffWidthInput.maxLength = '2';
            doPulseOffWidthInput.min = 500;
            doPulseOffWidthInput.max = 65535;
            doPulseOffWidthInput.title = "Range: 500-65535";
            doPulseOffWidthInput.disabled = true;
            doPulseOffWidthInput.value = doPulseOffWidthSpan.innerHTML;
    
            doAliasSpan.parentNode.replaceChild(doInputElement, doAliasSpan);
            doPulseCountSpan.parentNode.replaceChild(doPulseCountInput, doPulseCountSpan);
            doPulseOnWidthSpan.parentNode.replaceChild(doPulseOnWidthInput, doPulseOnWidthSpan);
            doPulseOffWidthSpan.parentNode.replaceChild(doPulseOffWidthInput, doPulseOffWidthSpan);
            
            if(doPulseStatus.value === "1"){
              doPulseCountInput.disabled = false;
              doPulseOnWidthInput.disabled = false;
              doPulseOffWidthInput.disabled = false;
            } else if(doPulseStatus.value  === "0"){
              DO_S.disabled = false;
              DO_DF.disabled = false;
              DO_STATUS.disabled = false;
            }

            doPulseCountInput.parentNode.style.paddingLeft = "10px";
            doPulseOnWidthInput.parentNode.style.paddingLeft = "10px";
            doPulseOffWidthInput.parentNode.style.paddingLeft = "10px";
          }
        }
        if(modType === "8AI"){
          for (let i = 0; i < inputPort; i++) {
            const aiAliasSpan = document.getElementById('AI_AN' + i);
            const aiInputElement = document.createElement('input');
            aiInputElement.id = 'AI_AN' + i;
            aiInputElement.style.width = '160px';
            aiInputElement.type = 'text';
            aiInputElement.value = aiAliasSpan.innerHTML;
            aiAliasSpan.parentNode.replaceChild(aiInputElement, aiAliasSpan);
          }
        }
        if(modType === "8AO"){
          for (let i = 0; i < outputPort; i++) {
            const aoAliasSpan = document.getElementById('AO_AN' + i);
            const aoInputElement = document.createElement('input');
            const aoModeSelect = document.getElementById('AO_MODE' + i);
            const aoDECheckBox = document.getElementById('AO_DE' + i);
            const defaultValueSpan = document.getElementById('AO_DV' + i);
            const defaultValueElement = document.createElement('input');
            const aoValueSpan = document.getElementById('AO_CV' + i);
            const aoValueElement = document.createElement('input');
            
            aoModeSelect.disabled = false;
            aoDECheckBox.disabled = false;

            aoInputElement.id = 'AO_AN' + i;
            aoInputElement.style.width = '160px';
            aoInputElement.type = 'text';
            aoInputElement.value = aoAliasSpan.innerHTML;
            aoAliasSpan.parentNode.replaceChild(aoInputElement, aoAliasSpan);

            defaultValueElement.max = parseInt(aoModeSelect.value) === 0 ? 10 : 20;
            defaultValueElement.min = 0;
            defaultValueElement.id = 'AO_DV' + i;
            defaultValueElement.style.width = '80px';
            defaultValueElement.type = 'number';
            defaultValueElement.step = '0.001';
            defaultValueElement.value = defaultValueSpan.innerHTML;
            defaultValueSpan.parentNode.replaceChild(defaultValueElement, defaultValueSpan);

            aoValueElement.max = parseInt(aoModeSelect.value) === 0 ? 10 : 20;
            aoValueElement.min = 0;
            aoValueElement.id = 'AO_CV' + i;
            aoValueElement.style.width = '80px';
            aoValueElement.type = 'number';
            aoValueElement.step = '0.001';
            aoValueElement.value = aoValueSpan.innerHTML;
            aoValueSpan.parentNode.replaceChild(aoValueElement, aoValueSpan);

            const AO_DV = document.getElementById(`AO_DV${i}`);
            if(AO_DV) {
              AO_DV.addEventListener('blur', () => {
                console.log(Math.round(AO_DV.value * 1000));
                setValue(AO_DV, Math.round(AO_DV.value * 1000) / 1000);
              });
            };
            const AO_CV = document.getElementById(`AO_CV${i}`);
            if(AO_CV) {
              AO_CV.addEventListener('blur', () => {
                console.log(Math.round(AO_CV.value * 1000));
                setValue(AO_CV, Math.round(AO_CV.value * 1000) / 1000);
              });
            };
          }
        }
        rename.disabled = true;
        save.disabled = false;
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
    save.addEventListener("click", async(e) => {
      e.preventDefault();
      this.state.buttonStatus = false;
      const refreshTime = document.getElementById('refresh-time');
      const save = document.getElementById("save");
      const rename = document.getElementById("rename");
      const refreshSelect = document.getElementById("refresh");

      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };
      const digitalAliasPayload = {
        io: {
          di: [
            // {
              // "diIndex": index,
              // "diAlias": input?.diAlias,
            // }
          ],
          do: []
        },
        slot: 0
      }
      const analogAliasPayload = {
        io: {
          ai: [],
          ao: []
        },
        slot: 0
      }

      const diPayload = {
        io: {
          di: []
        },
        slot: 0
      }
      const doPayload = {
        io: {
          do: []
        },
        slot: 0
      }
      const aoPayload = {
        io: {
          ao: []
        },
        slot: 0
      }
      
      try {
        if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DI"){
          for (let i = 0; i < inputPort; i++) {
            const diCounterReset = diCounterResetStatus[i];
            const DI_FT = parseInt(document.getElementById('DI_FT' + i).value);

            if(DI_FT) {
              if (DI_FT < 0 || DI_FT > 65535) {
                customErrorProps.data.error.message = "Filter should be 0-65535!";
                throw new CustomError(customErrorProps);
              }
            }

            let entry = {
              "diCounterReset": diCounterReset,
              "diCounterStatus": parseInt(document.getElementById('DI_EN' + i).value),
              "diIndex": i,
              "diCounterSetting" : parseInt(document.getElementById('DI_CNTRS' + i).value),
              "diCounterTrigger": parseInt(document.getElementById('DI_HL' + i).value),
              "diFilter": DI_FT,
            }
            diPayload.io.di[i] = entry;
          }

          for (let i = 0; i < inputPort; i++) {
            const diAliasInput = document.getElementById('DI_AN' + i);
            digitalAliasPayload.io.di.push({
              diIndex: i,
              diAlias: diAliasInput.value,
            });
          }
        }

        if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DO"){

          let newP2pServer = [];
          const server = (await Api.getPeerToPeerSettings()).server;
          const getChStatus = server.map(item => item.enabled === 1 ? item : null).filter(item => item !== null);
          newP2pServer = Array(this.state.outputPort).fill(true);
          if(getChStatus.length > 0){
            for(let i = 0; i < getChStatus.length; i++){
              const getCh = getChStatus[i].channelID;
              const getNumber = Number(getCh.split('-')[1]);
              const localCount = getChStatus[i].localCount;
              for(let j = 0; j < localCount; j++){
                newP2pServer[getNumber + j] = false;
              }
            }
          }
          console.log(newP2pServer);
          
          for (let i = 0; i < outputPort; i++) {
            const doPulseStatus = parseInt(document.getElementById('DO_PSE' + i).value);
            const doStatus = document.getElementById('DO_S' + i).innerHTML === "H" ? 1 : 0;
            const doDefault = parseInt(document.getElementById('DO_DF' + i).value);
            const doPulseCount = parseInt(document.getElementById('doPulseCount_' + i).value);
            const doPulseOnWidth = parseInt(document.getElementById('doPulseOnWidth_' + i).value);
            const doPulseOffWidth = parseInt(document.getElementById('doPulseOffWidth_' + i).value);

            // 不能用p2pServer[i]，要用this.state.p2pServer[i]
            if(newP2pServer[i] === false && doPulseStatus === 1 && i < 10){
              customErrorProps.data.error.message = `Channel DO-0${i} is used in P2P, the mode cannot be changed!`;
              throw new CustomError(customErrorProps);
            } else if(newP2pServer[i] === false && doPulseStatus === 1 && i >= 10){
              customErrorProps.data.error.message = `Channel DO-${i} is used in P2P, the mode cannot be changed!`;
              throw new CustomError(customErrorProps);
            }
            // Check allowed values
            if (doPulseCount < 0 || doPulseCount > 65535) {
              customErrorProps.data.error.message = "Pulse Count should be 0-65535!";
              throw new CustomError(customErrorProps);
            }
            if (doPulseOnWidth < 500 || doPulseOnWidth > 65535) {
              customErrorProps.data.error.message = "Pulse-On Width should be 500-65535!";
              throw new CustomError(customErrorProps);
            }
            if (doPulseOffWidth < 500 || doPulseOffWidth > 65535) {
              customErrorProps.data.error.message = "Pulse-Off Width should be 500-65535!";
              throw new CustomError(customErrorProps);
            }

            let entry = {
              "doDefaultEnable": doDefault === -1 ? 0 : 1,
              "doDefaultValue": doDefault === 1 ? 1 : 0,
              "doIndex": i,
              "doMode": doPulseStatus,  //因要改doPulseStatus，需同時送doMode跟doPulseStatus的值，故設定跟doPulseStatus一樣的值
              "doPulseCount": doPulseCount,
              "doPulseOnWidth": doPulseOnWidth,
              "setDomPropertydoPulseOffWidth": doPulseOffWidth,
              "doPulseStatus": doPulseStatus,
              "doStatus": doStatus,
            }
            doPayload.io.do[i] = entry;
          }
          for (let i = 0; i < outputPort; i++) {
            const doAliasInput = document.getElementById('DO_AN' + i);
            digitalAliasPayload.io.do.push({
              doIndex: i,
              doAlias:  doAliasInput.value,
            });
          }
        }
        if(modType === "8AI"){
          for (let i = 0; i < inputPort; i++) {
            const aiAliasInput = document.getElementById('AI_AN' + i);
            analogAliasPayload.io.ai.push({
              aiIndex: i,
              aiAlias: aiAliasInput.value,
            });
          }
        }
        if(modType === "8AO"){
          let newP2pServer = [];
          const server = (await Api.getPeerToPeerSettings()).server;
          const getChStatus = server.map(item => item.enabled === 1 ? item : null).filter(item => item !== null);
          newP2pServer = Array(this.state.outputPort).fill(true);
          if(getChStatus.length > 0){
            for(let i = 0; i < getChStatus.length; i++){
              const getCh = getChStatus[i].channelID;
              const getNumber = Number(getCh.split('-')[1]);
              const localCount = getChStatus[i].localCount;
              for(let j = 0; j < localCount; j++){
                newP2pServer[getNumber + j] = false;
              }
            }
          }

          for(let i = 0; i < outputPort; i++){
            const aoDefaultValueInput = document.getElementById('AO_DV' + i);
            const aoValueInput = document.getElementById('AO_CV' + i);
            const aoModeSelect = document.getElementById('AO_MODE' + i);
            const aoDECheckBox = document.getElementById('AO_DE' + i);
                        
            if(newP2pServer[i] === false && this.state.outputBoard[i]?.output?.aoMode !== parseInt(aoModeSelect.value)){
              console.log(this.state, this.state.outputBoard[i]?.output?.aoMode, parseInt(aoModeSelect.value));
                
              customErrorProps.data.error.message = `Channel AO-0${i} is used in P2P, the mode cannot be changed! Please disable P2P for this channel.`;
              throw new CustomError(customErrorProps);
            }
            console.log(Number(aoDefaultValueInput.value));
            
            if(aoModeSelect.value === "0" && (Number(aoDefaultValueInput.value) < 0 || Number(aoDefaultValueInput.value) > 10)){
              customErrorProps.data.error.message = `Default Value should be between 0 and 10 at channel AO-0${i}!`;
              throw new CustomError(customErrorProps);
            } else if(aoModeSelect.value === "2" && (Number(aoDefaultValueInput.value) < 0 || Number(aoDefaultValueInput.value) > 20)){
              customErrorProps.data.error.message = `Default Value should be between 0 and 20 at channel AO-0${i}!`;
              throw new CustomError(customErrorProps);
            }
            if(aoModeSelect.value === "0" && (Number(aoValueInput.value) < 0 || Number(aoValueInput.value) > 10)){
              customErrorProps.data.error.message = `Present Value should be between 0 and 10 at channel AO-0${i}!`;
              throw new CustomError(customErrorProps);
            } else if(aoModeSelect.value === "2" && (Number(aoValueInput.value) < 0 || Number(aoValueInput.value) > 20)){
              customErrorProps.data.error.message = `Present Value should be between 0 and 20 at channel AO-0${i}!`;
              throw new CustomError(customErrorProps);
            }

            aoPayload.io.ao.push({
              aoIndex: i,
              aoMode: parseInt(aoModeSelect.value),
              aoDefaultValueScaled: Number(aoDefaultValueInput.value),
              aoDefaultEnable: aoDECheckBox.checked ? 1 : 0,
              aoValueScaled: Number(aoValueInput.value),
            });
          }
          for(let i = 0; i < outputPort; i++){
            const aoAliasInput = document.getElementById('AO_AN' + i);
            analogAliasPayload.io.ao.push({
              aoIndex: i,
              aoAlias: aoAliasInput.value,
            });
          }
        }

        let res = {};
        let aliasRes = {};
        if(modType === "8AO"){
          aliasRes = await Api.editAnalogOutput(aoPayload);
        }
        if(modType === "8AI" || modType === "8AO"){
          aliasRes = await Api.editAlias(analogAliasPayload);
        } else {
          aliasRes = await Api.editAlias(digitalAliasPayload);
          if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DI"){
            // console.log(diPayload);
            res = await Api.editDigitalInput(diPayload);
          }
          if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DO"){
            res = await Api.editDigitalOutput(doPayload);
          }
        }
        
        DialogUtility.showSuccess({
          text: aliasRes.error?.message || res.error?.message,
        });

        this.state.intervalId = setInterval(this.loadingPage, this.state.refreshTime);

        refreshTime.style.backgroundColor = "#eeeeee";
        refreshSelect.disabled = false;
        rename.disabled = false;
        save.disabled = true;
        this.handleReadOnly();
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

  handleReadOnly = () => {
    const { modType, inputPort, outputPort } = this.state;

    if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DI"){
      for (let i = 0; i < inputPort; i++) {
        const diAliasInput = document.getElementById('DI_AN' + i);
        const diSpanElement = document.createElement('span');
        diSpanElement.id = 'DI_AN' + i;
        diSpanElement.innerHTML = diAliasInput.value;
        diAliasInput.parentNode.replaceChild(diSpanElement, diAliasInput);

        const DI_FT = parseInt(document.getElementById('DI_FT' + i).value);
        const DI_FTSpan = document.createElement('span');
        DI_FTSpan.id = 'DI_FT' + i;
        DI_FTSpan.title = "Range: 1-65535; 0 is disabled";
        DI_FTSpan.style.paddingRight = "10px";
        DI_FTSpan.innerHTML = DI_FT;
        document.getElementById('DI_FT' + i).parentNode.replaceChild(DI_FTSpan, document.getElementById('DI_FT' + i));
      }
    }
    if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DO"){
      for (let i = 0; i < outputPort; i++) {
        const doAliasInput = document.getElementById('DO_AN' + i);
        const doSpanElement = document.createElement('span');
        doSpanElement.id = 'DO_AN' + i;
        doSpanElement.innerHTML = doAliasInput.value;
        doAliasInput.parentNode.replaceChild(doSpanElement, doAliasInput);

        const doPulseStatusInput = document.getElementById('DO_PSE' + i);
        const doPulseCount = parseInt(document.getElementById('doPulseCount_' + i).value);
        const doPulseOnWidth = parseInt(document.getElementById('doPulseOnWidth_' + i).value);
        const doPulseOffWidth = parseInt(document.getElementById('doPulseOffWidth_' + i).value);

        const doPulseCountSpan = document.createElement('span');
        doPulseCountSpan.id = 'doPulseCount_' + i;
        doPulseCountSpan.title = "Range: 1-65535;0 is always";
        doPulseCountSpan.innerHTML = doPulseCount;

        const doPulseOnWidthSpan = document.createElement('span');
        doPulseOnWidthSpan.id = 'doPulseOnWidth_' + i;
        doPulseOnWidthSpan.title = "Range: 500-65535";
        doPulseOnWidthSpan.innerHTML = doPulseOnWidth;

        const doPulseOffWidthSpan = document.createElement('span');
        doPulseOffWidthSpan.id = 'doPulseOffWidth_' + i;
        doPulseOffWidthSpan.title = "Range: 500-65535";
        doPulseOffWidthSpan.innerHTML = doPulseOffWidth;

        document.getElementById('doPulseCount_' + i).parentNode.replaceChild(doPulseCountSpan, document.getElementById('doPulseCount_' + i));
        document.getElementById('doPulseOnWidth_' + i).parentNode.replaceChild(doPulseOnWidthSpan, document.getElementById('doPulseOnWidth_' + i));
        document.getElementById('doPulseOffWidth_' + i).parentNode.replaceChild(doPulseOffWidthSpan, document.getElementById('doPulseOffWidth_' + i));

        doPulseStatusInput.disabled = true;
        if(parseInt(doPulseStatusInput.value) === 1){
          document.getElementById('doPulseCount_' + i).disabled = true;
          document.getElementById('doPulseOnWidth_' + i).disabled = true;
          document.getElementById('doPulseOffWidth_' + i).disabled = true;
        }else if(parseInt(doPulseStatusInput.value) === 0){
          document.getElementById('DO_S' + i).disabled = true;
          document.getElementById('DO_DF' + i).disabled = true;
          document.getElementById('DO_STATUS' + i).disabled = true;
        }
      }
    }
    if(modType === "8AI"){
      for (let i = 0; i < inputPort; i++) {
        const aiAliasInput = document.getElementById('AI_AN' + i);
        const aiSpanElement = document.createElement('span');

        aiSpanElement.id = 'AI_AN' + i;
        aiSpanElement.innerHTML = aiAliasInput.value;
        aiAliasInput.parentNode.replaceChild(aiSpanElement, aiAliasInput);
      }
    }
    if(modType === "8AO"){
      for (let i = 0; i < outputPort; i++) {
        const aoAliasInput = document.getElementById('AO_AN' + i);
        const aoSpanElement = document.createElement('span');
        aoSpanElement.id = 'AO_AN' + i;
        aoSpanElement.innerHTML = aoAliasInput.value;
        aoAliasInput.parentNode.replaceChild(aoSpanElement, aoAliasInput);

        const aoDefaultValueInput = document.getElementById('AO_DV' + i);
        const aoDefaultValueElement = document.createElement('span');
        aoDefaultValueElement.id = 'AO_DV' + i;
        aoDefaultValueElement.innerHTML = aoDefaultValueInput.value;
        aoDefaultValueInput.parentNode.replaceChild(aoDefaultValueElement, aoDefaultValueInput);

        const aoValueInput = document.getElementById('AO_CV' + i);
        const aoValueElement = document.createElement('span');
        aoValueElement.id = 'AO_CV' + i;
        aoValueElement.innerHTML = aoValueInput.value;
        aoValueInput.parentNode.replaceChild(aoValueElement, aoValueInput);

        document.getElementById('AO_MODE' + i).disabled = true;
        document.getElementById('AO_DE' + i).disabled = true;
      }
    }
  }

  initIntervalSelect = () => {
    const refreshSelect = document.getElementById("refresh");
    if (refreshSelect) {
      refreshSelect.value = this.state.refreshTime;
      refreshSelect.addEventListener('change', this.onRefreshTimeChange);
    }
  }

  onRefreshTimeChange = (e) => {
    this.state.refreshTime = e.target.value;
    const { intervalId, modType } = this.state;
    
    if (intervalId) {
      clearInterval(intervalId);
    }

    this.state.intervalId = setInterval(this.loadingPage, this.state.refreshTime);
  }

  loadingPage = async() => {
    const { modType, inputBoard, outputBoard } = this.state;
    const allButton = document.querySelector('.allFn');
    try {
      var mainstatDI = document.getElementById('displayInput');
	    var loadstatDI = document.getElementById('loadingInput');
      var mainstatDO = document.getElementById('displayOutput');
	    var loadstatDO = document.getElementById('loadingOutput');

      // Make sure we're displaying the status display
      if (mainstatDI != null && loadstatDI != null) {
        mainstatDI.style.display = 'block';
        loadstatDI.style.display = 'none';
      }
      if(mainstatDO != null && loadstatDO != null){
        mainstatDO.style.display = 'block';
        loadstatDO.style.display = 'none';
      }

      if(modType === "8AI" || modType === "16DI"){
        mainstatDO.style.display = 'none';
        loadstatDO.style.display = 'none';
      } else if(modType === "8AO" || modType === "16DO"){
        mainstatDI.style.display = 'none';
        loadstatDI.style.display = 'none';
      }
      if(modType === "16DI" || modType === "8DI4RELAY" || modType === "8DI8DO"){
        const digitalInputs = (await Api.getDigitalInput()).io.di;

        digitalInputs.forEach(input => {
          const { diIndex } = input;
          if (inputBoard[diIndex] === undefined) {
            inputBoard[diIndex] = {};
          }
          inputBoard[diIndex].input = input;
        });

        inputBoard.forEach(item => {
          const { input } = item;
          const cells = [
            { name: "DI_",     value: input.diIndex,                },
            { name: "DI_AN",   value: input.diAlias,                },
            { name: "DI_S",    value: input.diStatus,               },
            { name: "DI_EN",   value: input.diCounterStatus,        },
            { name: "DI_VAL",  value: input.diCounterValue,         },  // 靠diCounterOverflowFlag判斷顏色
            { name: "DI_FT",   value: input.diFilter,               },
            { name: "DI_CNTRS",value: input.diCounterSetting,       },
            { name: "DI_FRQ",  value: input.diCounterFrequency,     },
            { name: "DI_HL",   value: input.diCounterTrigger,       },
            { name: "DI_RST",  value: input.diCounterReset,         },
          ];        

          cells.forEach(cell => {
            this.renderBoardCell({
              index:  input?.diIndex,
              name:   cell.name,
              value:  cell.value,
              overflow: input?.diCounterOverflowFlag,
            });
          });
        });
      }
      if(modType === "16DO" || modType === "8DI8DO" || modType === "8DI4RELAY"){
        const digitalOutpus = (await Api.getDigitalOutput()).io.do;
        
        digitalOutpus.forEach(output => {
          const { doIndex } = output;
          if (outputBoard[doIndex] === undefined) {
            outputBoard[doIndex] = {};
          }
          outputBoard[doIndex].output = output;
        });

        outputBoard.forEach(item => {
          const { output } = item;
          const cells = [
            { name: "DO_",              value: output.doIndex,                                           },
            { name: "DO_AN",            value: output.doAlias,                                           },
            { name: "DO_S",             value: output.doStatus,                                          },
            { name: "DO_DF",            value: output.doDefaultEnable === 0 ? -1 : output.doDefaultValue,},
            { name: "DO_PSE",           value: output.doPulseStatus,                                     },
            { name: "DO_STATUS",        value: output.doSafeMode,                                        },
            { name: "doPulseCount_",    value: output.doPulseCount,                                      },
            { name: "doPulseOnWidth_",  value: output.doPulseOnWidth,                                    },
            { name: "doPulseOffWidth_", value: output.doPulseOffWidth                                    },
          ]; 

          cells.forEach(cell => {
            this.renderBoardCell({
              index:  output?.doIndex,
              name:   cell.name,
              value:  cell.value,
            });
          });
        });
      }
      if(modType === "8AI"){
        const analogInputs = (await Api.getAnalogInput()).io.ai;
        
        let saveChIndex = [];
        if(inputBoard.length !== 0){
          const checkModeChange = analogInputs.map((item, index) => {
            if(inputBoard[index] !== undefined && item.aiMode !== inputBoard[index].input.aiMode){
              saveChIndex.push(`AI-0${index}`);
              return item.aiMode !== inputBoard[index].input.aiMode ? item : null;
            }
            return null;
          }).filter(item => item !== null);

          const allCh = saveChIndex.join(', ');
          if(checkModeChange.length !== 0){
            DialogUtility.showError({
              text: "The mode of the channel " + allCh + " has changed, please check the mode!",
            });
          }
        }

        analogInputs.forEach(input => {
          const { aiIndex } = input;
          if (inputBoard[aiIndex] === undefined) {
            inputBoard[aiIndex] = {};
          }
          inputBoard[aiIndex].input = input;
        });
        
        inputBoard.forEach(item => {
          const { input } = item;
          const cells = [
            { name: "AI_",       value: input.aiIndex,                                                },
            { name: "AI_AN",     value: input.aiAlias,                                                },
            { name: "AI_MODE",   value: input.aiMode === 0 ? "Voltage" : "Current",                   },
            { name: "AI_RANGE",  value: input.aiMode === 0 ? "0V ~ 10V" : "0mA ~ 20mA",               },
            { name: "AI_CV",     value: input.aiValueScaled,                                          },
            { name: "AI_MIN",    value: input.aiMode === 0 && input.aiOVPFlag === 0 
              ? input.aiMinVoltage : input.aiMode === 0 && input.aiOVPFlag === 1 
              ? input.aiOVPMinVolCount : input.aiMode === 2 && input.aiOVPFlag === 0 
              ? input.aiMinCurrent : input.aiOVPMinCurCount,                                          },
            { name: "AI_MAX",    value: input.aiMode === 0 && input.aiOVPFlag === 0 
              ? input.aiMaxVoltage : input.aiMode === 0 && input.aiOVPFlag === 1 
              ? input.aiOVPMaxVolCount : input.aiMode === 2 && input.aiOVPFlag === 0 
              ? input.aiMaxCurrent : input.aiOVPMaxCurCount,                                          },
            { name: "AI_STATUS", value: input.aiOVPFlag,                                              },
          ];
          cells.forEach(cell => {
            this.renderBoardCell({
              index:  input?.aiIndex,
              name:   cell.name,
              value:  cell.value,
              overflow: input?.aiOVPFlag,
              overSpec: input?.aiMode === 0 ? input.aiOVPMinVolCount + input.aiOVPMaxVolCount : input.aiOVPMinCurCount + input.aiOVPMaxCurCount,
            });
          });
        });
      }
      if (modType === "8AO") {
        const analogOutputs = (await Api.getAnalogOutput()).io.ao;
        analogOutputs.forEach(output => {
          const { aoIndex } = output;
          if (outputBoard[aoIndex] === undefined) {
            outputBoard[aoIndex] = {};
          }
          outputBoard[aoIndex].output = output;
        });
        outputBoard.forEach(item => {
          const { output } = item;
          const cells = [
            { name: "AO_",       value: output.aoIndex,                                               },
            { name: "AO_AN",     value: output.aoAlias,                                               },
            { name: "AO_MODE",   value: output.aoMode,                                                },
            { name: "AO_RANGE",  value: output.aoMode === 0 ? "0V ~ 10V" : "0mA ~ 20mA",              },
            { name: "AO_CV",     value: output.aoValueScaled,                                         },
            { name: "AO_DV",     value: output.aoDefaultValueScaled,                                  },
            { name: "AO_DE",     value: output.aoDefaultEnable,                                       },
            { name: "AO_STATUS", value: output.aoSafeMode === 1 ? 1 : output.aoOVPFlag === 1 ? 2 : 0, },
          ];
          cells.forEach(cell => {
            this.renderBoardCell({
              index:  output?.aoIndex,
              name:   cell.name,
              value:  cell.value,
              overflow: output?.aoOVPFlag,
              overSpec: output?.aoMode === 0 ? output.aoOVPMinVolCount + output.aoOVPMaxVolCount : output.aoOVPMinCurCount + output.aoOVPMaxCurCount,
            });
          });
        });
      }

      if (!(currentPage instanceof IOSettingsPage)) {
        return;
      }
    } catch(error) {
      ErrorUtility.handleError(error);
      if (mainstatDI == null || loadstatDI == null || mainstatDO == null || loadstatDO == null) {
        return;
      }
      if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DI" || modType === "8AI"){
        mainstatDI.style.display = 'none';
        loadstatDI.style.display = 'inline';
      } else if(modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DO" || modType === "8AO"){
        mainstatDO.style.display = 'none';
        loadstatDO.style.display = 'inline';
      }
      allButton.style.display = 'none';
    }
  }

  renderBackgroundColor = (index, type, value) => {
    const DI_VAL = document.getElementById('DI_VAL' + index);
    // const DI_OF = document.getElementById('DI_OF' + index);
    const DI_RST = document.getElementById('DI_RST' + index);
    const DI_HL = document.getElementById('DI_HL' + index);
    const DI_FT = document.getElementById('DI_FT' + index);
    const DI_CNTRS = document.getElementById('DI_CNTRS' + index);
    const DI_FRQ = document.getElementById('DI_FRQ' + index);

    const DO_S = document.getElementById('DO_S' + index);
    const DO_DF = document.getElementById('DO_DF' + index);
    const DO_STATUS = document.getElementById('DO_STATUS' + index);
    const doPulseCount = document.getElementById('doPulseCount_' + index);
    const doPulseOnWidth = document.getElementById('doPulseOnWidth_' + index);
    const doPulseOffWidth = document.getElementById('doPulseOffWidth_' + index);
    
    if(type === "DI" && value === 1){
      DI_FT.parentElement.style.backgroundColor = "#a8a8a8";
      DI_VAL.parentElement.style.backgroundColor = "#f9f9f9";
      // DI_OF.parentElement.style.backgroundColor = "#f9f9f9";
      DI_RST.parentElement.style.backgroundColor = "#f9f9f9";
      DI_HL.parentElement.style.backgroundColor = "#f9f9f9";
      DI_CNTRS.parentElement.style.backgroundColor = "#f9f9f9";
      DI_FRQ.parentElement.style.backgroundColor = "#f9f9f9";
      if(this.state.buttonStatus === true){
        DI_FT.disabled = true;
        DI_RST.disabled = false;
        DI_HL.disabled = false;
        DI_CNTRS.disabled = false;
        DI_FRQ.disabled = false;
      }
    } else if(type === "DI" && value === 0){
      DI_FT.parentElement.style.backgroundColor = "#f9f9f9";
      DI_VAL.parentElement.style.backgroundColor = "#a8a8a8";
      // DI_OF.parentElement.style.backgroundColor = "#a8a8a8";
      DI_RST.parentElement.style.backgroundColor = "#a8a8a8";
      DI_HL.parentElement.style.backgroundColor = "#a8a8a8";
      DI_CNTRS.parentElement.style.backgroundColor = "#a8a8a8";
      DI_FRQ.parentElement.style.backgroundColor = "#a8a8a8";

      if(this.state.buttonStatus === true){
        DI_FT.disabled = false;
        DI_RST.disabled = true;
        DI_HL.disabled = true;
        DI_CNTRS.disabled = true;
        DI_FRQ.disabled = true;
      }
    } else if(type === "DO" && value === 1){
      DO_S.parentElement.style.backgroundColor = "#a8a8a8";
      DO_DF.parentElement.style.backgroundColor = "#a8a8a8";
      DO_STATUS.parentElement.style.backgroundColor = "#a8a8a8";

      doPulseCount.parentElement.style.backgroundColor = "#f9f9f9";
      doPulseOnWidth.parentElement.style.backgroundColor = "#f9f9f9";
      doPulseOffWidth.parentElement.style.backgroundColor = "#f9f9f9";
      if(this.state.buttonStatus === true){
        DO_S.disabled = true;
        DO_DF.disabled = true;
        DO_STATUS.disabled = true;
        doPulseCount.disabled = false;
        doPulseOnWidth.disabled = false;
        doPulseOffWidth.disabled = false;
      }
    } else if(type === "DO" && value === 0){
      DO_S.parentElement.style.backgroundColor = "#f9f9f9";
      DO_DF.parentElement.style.backgroundColor = "#f9f9f9";
      DO_STATUS.parentElement.style.backgroundColor = "#f9f9f9";

      doPulseCount.parentElement.style.backgroundColor = "#a8a8a8";
      doPulseOnWidth.parentElement.style.backgroundColor = "#a8a8a8";
      doPulseOffWidth.parentElement.style.backgroundColor = "#a8a8a8";
      if(this.state.buttonStatus === true){
        DO_S.disabled = false;
        DO_DF.disabled = false;
        DO_STATUS.disabled = false;
        doPulseCount.disabled = true;
        doPulseOnWidth.disabled = true;
        doPulseOffWidth.disabled = true;
      }
    }
    setDisableAllButton();
    setDisableAllCheckbox();
  }

  renderBoardCell = ({ index, name, value, overflow, overSpec }) => {
    const id = name + index;
    const cell = document.getElementById(id);

    const flag = 0 < value;
    
    if (cell == null) {
      return;
    }

    if (name === "DI_VAL" || name === "DI_FRQ") {
      cell.innerHTML = value;
      cell.parentElement.style.textAlign = "right";
      cell.parentElement.style.paddingRight = "10px";
    } else if(name === "DI_FT" || name === "doPulseCount_" || name === "doPulseOnWidth_" || name === "doPulseOffWidth_" ) {
      cell.innerHTML = value;
      cell.parentElement.style.paddingLeft = "10px";
    }
    if(name === "DI_VAL" && overflow === 1){
      cell.style.color = "#FF0000";
    }
    if(name === "AI_CV" && overflow === 1 || name === "AO_CV" && overflow === 1){
      cell.style.color = "#0000ff";
    }

    if(name === "AI_CV" || name === "AO_CV" || name === "AO_DV" || name ==="AI_MIN" || name === "AI_MAX"){
      cell.innerHTML = parseFloat(value).toFixed(3);
      cell.innerHTML = Math.round(value * 1000) / 1000;
    }
    if(name === "DO_STATUS" && value === 0 || name === "AI_STATUS" && value === 0 || name === "AO_STATUS" && value === 0){
      cell.innerHTML = "Normal";
      cell.style.color = "#000000";
    } else if(name === "DO_STATUS" && value === 1 || name === "AO_STATUS" && value === 1){
      cell.innerHTML = "Safe Mode";
      cell.style.color = "#0000ff";
    } else if(name === "AI_STATUS" && value === 1){
      cell.innerHTML = `Over Spec-${overSpec}`;
      // cell.innerHTML = `Over Spec-<span style="color: #0000ff;">${overSpec}</span>`;
      cell.style.color = "#0000ff";
    } else if(name === "AO_STATUS" && value === 2){
      cell.innerHTML = `OVP-${overSpec}`;
      // cell.innerHTML = `OVP-<span style="color: #0000ff;">${overSpec}</span>`;
      cell.style.color = "#0000ff";
    }

    if (name === "DI_EN" || name === "DI_CNTRS" || name === "DI_HL"|| name === "DO_PSE" || name === "DO_DF" || name === "AO_MODE"){
      cell.value = value;
    } else if (name === "DI_AN" || name === "DO_AN" || name === "AI_AN" || name === "AI_MODE" || name === "AI_RANGE" || name === "AO_AN" || name === "AO_MODE" || name === "AO_RANGE") {
      cell.innerHTML = value;
    } else if (name === "AO_DE") { //name === "DO_DFE" || 
      cell.checked = flag;
    } else if (name === "DI_S") {
      setCircleWithFont(cell, flag);
    } else if (name === "DO_S") {
      cell.innerHTML = flag ? "H" : "L";
      cell.style.color = flag ? "#00FF00" : "#000000";
    }
    // else if (name === "DI_OF") {
    //   setCircle(cell, flag);
    // }
    // else if (name === "DO_DFV") {
    //   cell.innerHTML = flag ? "ON" : "OFF";
    //   cell.style.color = flag ? "#00FF00" : "#000000";
    // }

    if(name === "DI_S" || name === "DI_RST" || name === "DO_S" || name === "AO_DE"){  // || name === "DO_DFE"
      cell.parentElement.style.textAlign = "center";
    } else if(name === "DI_" || name === "DI_AN" || name === "DI_EN" || name === "DI_FT" || name === "DI_CNTRS" || name === "DI_FRQ" || name === "DI_HL" || 
      name === "DO_" || name === "DO_AN" || name === "DO_PSE" || name === "DO_DF" || name === "DO_STATUS" || name === "doPulseCount_" || name === "doPulseOnWidth_" || name === "doPulseOffWidth_" ||
      name === "AI_" || name === "AI_AN" || name === "AI_MODE" || name === "AI_RANGE" || name === "AI_CV" || name ==="AI_MIN" || name === "AI_MAX" || name === "AI_STATUS" ||
      name === "AO_" || name === "AO_AN" || name === "AO_MODE" || name === "AO_RANGE" || name === "AO_CV" || name === "AO_DV" || name === "AO_STATUS"){
      cell.parentElement.style.paddingLeft = "10px";
    }

    const DI_EN = document.getElementById('DI_EN' + index) ? document.getElementById('DI_EN' + index).value : null;
    const DO_PSE = document.getElementById('DO_PSE' + index) ? document.getElementById('DO_PSE' + index).value : null;
    if(name === "DI_EN"){
      this.renderBackgroundColor(index, "DI", value);
    } else if(name === "DO_PSE"){
      this.renderBackgroundColor(index, "DO", value);
    }
    if((name === "DI_RST" || name === "DI_CNTRS" || name === "DI_HL") && DI_EN === 1 || name === "DI_FT" && DI_EN === 0){
      cell.disabled = false;
    } else if((name === "DI_RST" || name === "DI_CNTRS" || name === "DI_HL") && DI_EN === 0 || name === "DI_FT" && DI_EN === 0){
      cell.disabled = true;
    }
    if(name === "DO_S" && DO_PSE === 1 || name === "DO_DF" && DO_PSE === 1 || name === "DO_STATUS" && DO_PSE === 1){  //|| name === "DO_DFV" && DO_PSE === 1 || name === "DO_DFE" && DO_PSE === 1
      cell.disabled = true;
    } else if(name === "DO_S" && DO_PSE === 0 || name === "DO_DF" && DO_PSE === 1 || name === "DO_STATUS" && DO_PSE === 1){  // || name === "DO_DFV" && DO_PSE === 0 || name === "DO_DFE" && DO_PSE === 0
      cell.disabled = false;
    }
    if(name === "doPulseCount_" && DO_PSE === 0 || name === "doPulseOnWidth_" && DO_PSE === 0 || name === "doPulseOffWidth_" && DO_PSE === 0){
      cell.disabled = true;
    } else if(name === "doPulseCount_" && DO_PSE === 1 || name === "doPulseOnWidth_" && DO_PSE === 1 || name === "doPulseOffWidth_" && DO_PSE === 1){
      cell.disabled = false;
    }

  }
  
  dispose() {
    const { intervalId } = this.state;
    if (intervalId !== undefined) {
      clearInterval(intervalId);
    }
  }
}