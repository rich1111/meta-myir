class PwmPage {
  constructor(props) {
    this.loadPage();
    this.initButtons();
  }

  loadPage = async () => {
    try {
      var mainstat = document.getElementById('display');
      var loadstat = document.getElementById('loading');

      // Make sure we're displaying the status display
      if (mainstat != null && loadstat != null) {
        mainstat.style.display = 'inline';
        loadstat.style.display = 'none';
      }

      const pwms = (await Api.getPwm()).io.pwm;

      pwms.forEach((pwm) => {
        var index = pwm.pwmIndex;
        const pwmEnable = document.getElementById('pwmEnable_' + index);
        const pwmFrequency = document.getElementById('pwmFrequency_' + index);
        const pwmDutyCycle = document.getElementById('pwmDutyCycle_' + index);
        const pwmDefaultEnable = document.getElementById('pwmDefaultEnable_' + index);
        const pwmDefaultFrequency = document.getElementById('pwmDefaultFrequency_' + index);
        const pwmDefaultDutyCycle = document.getElementById('pwmDefaultDutyCycle_' + index);

        setDomProperty(pwmEnable, "checked", pwm?.pwmEnable);
        setDomProperty(pwmFrequency, "value", pwm?.pwmFrequency);
        setDomProperty(pwmDutyCycle, "value", pwm?.pwmDutyCycle);
        setDomProperty(pwmDefaultEnable, "checked", pwm?.pwmDefaultEnable);
        setDomProperty(pwmDefaultFrequency, "value", pwm?.pwmDefaultFrequency);
        setDomProperty(pwmDefaultDutyCycle, "value", pwm?.pwmDefaultDutyCycle);
      });

    } catch (error) {
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  initButtons = () => {
    save.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const pwmEnable_0 = document.getElementById('pwmEnable_0').checked ? 1 : 0;
        const pwmFrequency_0 = parseFloat(document.getElementById('pwmFrequency_0').value);
        const pwmDutyCycle_0 = parseFloat(document.getElementById('pwmDutyCycle_0').value);
        const pwmDefaultEnable_0 = document.getElementById('pwmDefaultEnable_0').checked ? 1 : 0;
        const pwmDefaultFrequency_0 = parseFloat(document.getElementById('pwmDefaultFrequency_0').value);
        const pwmDefaultDutyCycle_0 = parseFloat(document.getElementById('pwmDefaultDutyCycle_0').value);
        // Check allowed values
        if (pwmFrequency_0 < 1 || pwmFrequency_0 > 5000) {
          customErrorProps.data.error.message = "PWM Frequency must be between 1 and 5000";
          throw new CustomError(customErrorProps);
        }
        if (pwmDutyCycle_0 < 0 || pwmDutyCycle_0 > 100) {
          customErrorProps.data.error.message = "PWM DutyCycle must be between 0 and 100";
          throw new CustomError(customErrorProps);
        }
        if (pwmDefaultFrequency_0 < 1 || pwmDefaultFrequency_0 > 5000) {
          customErrorProps.data.error.message = "PWM DefaultFrequency must be between 1 and 5000";
          throw new CustomError(customErrorProps);
        }
        if (pwmDefaultDutyCycle_0 < 0 || pwmDefaultDutyCycle_0 > 100) {
          customErrorProps.data.error.message = "PWM DefaultDutyCycle must be between 0 and 100";
          throw new CustomError(customErrorProps);
        }

        const pwmEnable_1 = document.getElementById('pwmEnable_1').checked ? 1 : 0;
        const pwmFrequency_1 = parseFloat(document.getElementById('pwmFrequency_1').value);
        const pwmDutyCycle_1 = parseFloat(document.getElementById('pwmDutyCycle_1').value);
        const pwmDefaultEnable_1 = document.getElementById('pwmDefaultEnable_1').checked ? 1 : 0;
        const pwmDefaultFrequency_1 = parseFloat(document.getElementById('pwmDefaultFrequency_1').value);
        const pwmDefaultDutyCycle_1 = parseFloat(document.getElementById('pwmDefaultDutyCycle_1').value);
        // Check allowed values
        if (pwmFrequency_1 < 1 || pwmFrequency_1 > 5000) {
          customErrorProps.data.error.message = "PWM Frequency must be between 1 and 5000";
          throw new CustomError(customErrorProps);
        }
        if (pwmDutyCycle_1 < 0 || pwmDutyCycle_1 > 100) {
          customErrorProps.data.error.message = "PWM DutyCycle must be between 0 and 100";
          throw new CustomError(customErrorProps);
        }
        if (pwmDefaultFrequency_1 < 1 || pwmDefaultFrequency_1 > 5000) {
          customErrorProps.data.error.message = "PWM DefaultFrequency must be between 1 and 5000";
          throw new CustomError(customErrorProps);
        }
        if (pwmDefaultDutyCycle_1 < 0 || pwmDefaultDutyCycle_1 > 100) {
          customErrorProps.data.error.message = "PWM DefaultDutyCycle must be between 0 and 100";
          throw new CustomError(customErrorProps);
        }

        const payload = {
          io: {
            pwm: [
              {
                pwmIndex: 0,
                pwmEnable: pwmEnable_0,
                pwmFrequency: pwmFrequency_0,
                pwmDutyCycle: pwmDutyCycle_0,
                pwmDefaultEnable: pwmDefaultEnable_0,
                pwmDefaultFrequency: pwmDefaultFrequency_0,
                pwmDefaultDutyCycle: pwmDefaultDutyCycle_0
              },
              {
                pwmIndex: 1,
                pwmEnable: pwmEnable_1,
                pwmFrequency: pwmFrequency_1,
                pwmDutyCycle: pwmDutyCycle_1,
                pwmDefaultEnable: pwmDefaultEnable_1,
                pwmDefaultFrequency: pwmDefaultFrequency_1,
                pwmDefaultDutyCycle: pwmDefaultDutyCycle_1
              }
            ]
          },
          slot: 0
        }

        const res = await Api.editPwm(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

}