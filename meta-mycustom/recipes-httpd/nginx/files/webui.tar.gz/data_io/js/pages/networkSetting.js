class NetworkPage {

    constructor(props) {
        this.state = {
            dhcp: true,
        };
        this.init();
        setDisable();
    }

    init = async() => {
        const configurationDiv = document.querySelector('.tab.configuration');
        const serverDiv = document.querySelector('.tab.server');
        const netSubmit = document.getElementById("netSubmit");
        const serverSubmit = document.getElementById("serverSubmit"); 
        setDisableSingleOrButton(netSubmit);
        setDisableSingleOrButton(serverSubmit);

        configurationDiv.addEventListener('click', (e) => {
            e.preventDefault();
            this.initNet();
            serverSubmit.removeEventListener('click', this.submitServer);
        });

        configurationDiv.click();

        serverDiv.addEventListener('click', (e) => {
            e.preventDefault();
            this.initServer();
            netSubmit.removeEventListener('click', this.submitNetwork);
        });
        
        if (!(currentPage instanceof NetworkPage)) {
            return;
        }
    }

    initNet = () => {
        const dhcp = document.getElementById("dhcp");
        if (dhcp) {
            dhcp.addEventListener('click', this.switchIPType);
        }
        const staticIP = document.getElementById("staticIP");
        if (staticIP) {
            staticIP.addEventListener('click', this.switchIPType);
        }
        setDisableSingleOrButton(staticIP);
        this.initConfig();
    }

    initConfig = async () => {
        const config = await Api.getNetConfig();
        this.setNetConfig(config);

        const netSubmit = document.getElementById("netSubmit");
        if (netSubmit) {
            netSubmit.addEventListener('click', this.submitNetwork);
        }
    }

    setNetConfig = (config) => {
        this.setStaticIP(config.proto);
        const ipAddress = document.getElementById("ipAddress");
        const subnetMask = document.getElementById("subnetMask");
        const gateway = document.getElementById("gateway");
        ipAddress.value = config.ipaddr;
        subnetMask.value = config.netmask;
        gateway.value = config.gateway;
    }

    submitNetwork = async (e) => {
        e.preventDefault();
        const customErrorProps = {
            data: {
                error: {
                message: "",
                }
            }
        };
    
        try {
            const isDHCP = this.state.dhcp;
            console.log("DHCP:", isDHCP);
            const payload = {
                proto: "dhcp",
                ipaddr: "",
                netmask: "",
                gateway: "",
                broadcast: ""
            };
            if (!isDHCP) {
                const ipAddress = document.getElementById("ipAddress").value;
                const subnetMask = document.getElementById("subnetMask").value;
                const gateway = document.getElementById("gateway").value;
                // Check if valid ip's
                if (StringUtility.validIP(ipAddress) === false) {
                    customErrorProps.data.error.message = "IP Address is invalid!";
                    throw new CustomError(customErrorProps);
                }
                if (StringUtility.validIP(subnetMask) === false) {
                    customErrorProps.data.error.message = "Subnet Mask is invalid!";
                    throw new CustomError(customErrorProps);
                }
                if (StringUtility.validIP(gateway) === false) {
                    customErrorProps.data.error.message = "Gateway IP is invalid!";
                    throw new CustomError(customErrorProps);
                }
                payload.proto = "static";
                payload.ipaddr = ipAddress;
                payload.netmask = subnetMask;
                payload.gateway = gateway;
            }
    
            DialogUtility.confirm({ text: "Reset IP! System will automatically use the new settings!" }).then(async (result) => {
                if (result.isConfirmed) {
                    const res = await Api.setNetConfig(payload);
                    DialogUtility.showSuccess({});
                }
            });
        } catch (error) {
            ErrorUtility.handleError(error);
        }
    }
        
    switchIPType = async (e) => {
        this.setStaticIP(e.srcElement.defaultValue);
    }
    
    setStaticIP(selected) {
        if (selected === "dhcp") {
            document.getElementById("dhcp").checked = true;
        } else if (selected === "static") {
            document.getElementById("staticIP").checked = true;
        }
        const disable = selected === "dhcp" ? true : false;
        // Set whether DHCP in state
        this.state = { dhcp: disable };
        const ipAddress = document.getElementById("ipAddress");
        const subnetMask = document.getElementById("subnetMask");
        const gateway = document.getElementById("gateway");
        ipAddress.disabled = disable;
        subnetMask.disabled = disable;
        gateway.disabled = disable;
        setDisableSingleOrButton(ipAddress);
        setDisableSingleOrButton(subnetMask);
        setDisableSingleOrButton(gateway);
    }


    initServer = async () => {
        const nameAndLocation = (await Api.getNameAndLocation());
        this.setAliasAndLocation(nameAndLocation);
        const serverSubmit = document.getElementById("serverSubmit");
        if (serverSubmit) {
            serverSubmit.addEventListener('click', this.submitServer);
        }
    }
    
    setAliasAndLocation = (nameAndLocation) => {
        const alias = document.getElementById("alias");
        const location = document.getElementById("location");
        alias.value = nameAndLocation.name;
        location.value = nameAndLocation.location;
    }

    submitServer = async (e) => {
        e.preventDefault();
        const customErrorProps = {
            data: {
                error: {
                message: "",
                }
            }
        };
        try {
            const alias = document.getElementById("alias").value;
            const location = document.getElementById("location").value;
            if (alias === "" || location === "") {
                customErrorProps.data.error.message = "Alias and Location fields must be filled!";
                throw new CustomError(customErrorProps);
            }
            DialogUtility.confirm({ text: "Change Alias and Location!" }).then(async (result) => {
                if (result.isConfirmed) {
                    const payload = {
                        name: alias,
                        location: location
                    };
                    console.log(payload);
                    const res = await Api.editNameAndLocation(payload);
                    DialogUtility.showSuccess({});
                }
            });
        } catch (error) {
            ErrorUtility.handleError(error);
        }
    }
    
    dispose(){

    }
}