/**
 * Only for module 12
 */
class RelayPage {
  constructor(props) {
    this.state = {
      refereshTime: 1000,
      intervalId: undefined,
      board: [],
      refreshCallBack: this.onRefreshTimeChange,
    };
    this.init();
  }

  init = async() => {
    this.initButtons();
    this.initIntervalSelect();

    this.state.intervalId = setInterval(
      this.loadPage, 
      this.state.refereshTime
    );
  }

  initIntervalSelect = () => {
    const refreshSelect = document.getElementById("refresh");
    const {
      refereshTime, refreshCallBack
    } = this.state;

    if (refreshSelect) {
      refreshSelect.value = refereshTime;
      refreshSelect.addEventListener('change', refreshCallBack);
    }
  }

  initButtons = () => {
    for (let i = 0; i < 4; i++) {
      const DO_button       = document.getElementById(`DO${i}`);
      const DDO_EN_button   = document.getElementById(`DDO_EN${i}`);
      const DDO_VAL_button  = document.getElementById(`DDO_VAL${i}`);

      DO_button.addEventListener('click', 
        () => this.sendEditApi(i, "doStatus"),
      );

      DDO_EN_button.addEventListener('click', 
        () => this.sendEditApi(i, "doDefaultEnable"),
      );

      DDO_VAL_button.addEventListener('click', 
        () => this.sendEditApi(i, "doDefaultValue"),
      );
    }
  }

  sendEditApi = (i, editFieldName) => {
    const payload = this.getEdittingDigitalOutputPayload(i);
    if (typeof payload[editFieldName] === "number") {
      payload[editFieldName] = 1 - payload[editFieldName];
      Api.editDigitalOutputByPort(payload);
    }
  }

  getEdittingDigitalOutputPayload  = (index) => {
    const output = this.state.board[index]?.output;
    return {
      port: index,
      doStatus: output?.doStatus,
      doDefaultEnable: output?.doDefaultEnable,
      doDefaultValue: output?.doDefaultValue,
    };
  }

  onRefreshTimeChange = (e) => {
    this.state.refereshTime = e.target.value;
    const { intervalId } = this.state;

    if (intervalId) {
      clearInterval(intervalId);
    }

    this.state.intervalId = setInterval(
      this.loadPage,
      this.state.refereshTime
    );
  }

  loadPage = async() => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    try {
      // Make sure we're displaying the status display
      mainstat.style.display = 'inline';
      loadstat.style.display = 'none';

      const digitalInputs = (await Api.getDigitalInput()).io.di;
      const digitalOutpus = (await Api.getDigitalOutput()).io.do;

      if (!(currentPage instanceof RelayPage)) {
        return;
      }
  
      const { board } = this.state;
  
      digitalInputs.forEach((input) => {
        const { diIndex } = input;
        if (board[diIndex] === undefined) {
          board[diIndex] = {};
        }
        board[diIndex].input = input;
      });
  
      digitalOutpus.forEach((output) => {
        const { doIndex } = output;
        if (board[doIndex] === undefined) {
          board[doIndex] = {};
        }
        board[doIndex].output = output;
      });

      board.forEach((item, index) => {
        const { input, output } = item;
        let channel = output?.doIndex;
        if (channel === undefined) {
          channel = input?.diIndex;
        }

        const cells = [
          { name: "DO",         value: output?.doStatus,          },
          { name: "DDO_EN",     value: output?.doDefaultEnable,   },
          { name: "DDO_VAL",    value: output?.doDefaultValue,    },
          { name: "DI",         value: input?.diStatus,           },
        ];

        cells.forEach((cell) => {
          if (cell.name === "DI") {
            const cellElem = document.getElementById(cell.name + channel);
            const flag = 0 < cell.value;
            setCircle(cellElem, flag)
          } else {
            this.renderDIOStatusBoardCell({
              index: channel,
              name: cell.name,
              value: cell.value,
            });
          }
        })
      });

      const lastUpdateTimeElem = document.getElementById("lastUpdateTime");
      const now = (new Date()).toUTCString();
      setInnerText(lastUpdateTimeElem, now);

    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  renderDIOStatusBoardCell = ({ name, index, value }) => {
    const id = name + index;
    const cell = document.getElementById(id);
    const flag = 0 < value;

    if (cell == null) {
      return;
    }

    cell.innerHTML = flag ? "ON" : "OFF";
    cell.style.color = flag ? "#00FF00" : "#000000";
  }

  dispose() {
    const { intervalId } = this.state;
    if (intervalId) {
      clearInterval(intervalId);
    }
  }
}
