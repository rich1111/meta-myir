class PeerToPeerPage {
    constructor() {
        this.state = {
            client: [],
            server: [],
            modType: "",
            serverPort: null,
            channelIDPort: null,  
            haveIandO: false,  //是否有I和O，來顯示不同的table
            allServerIP: [],  //紀錄所有remote IP
            allClientIP: [],  //紀錄所有client IP
            serverBoard: [],
            localDeviceType: "", //AI, AO, DI, DO, DIDO
            remoteChPort: [ //紀錄每個remote IP的port數
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
            ],
            localChPort: [], //紀錄每個local的CH是否被選取
            isDOorPulse:[],
            aoIsVorC: [],  //記錄AO Local的port是V or C
            userRole: sessionStorage.getItem('role'),
            remoteChPort: [],
            remoteIP0: [], //記錄每個remote IP的port是V or C
            remoteIP1: [],
            remoteIP2: [],
            remoteIP3: [],
            remoteIP4: [],
            remoteIP5: [],
            remoteIP6: [],
            remoteIP7: [],
            remoteIP8: [],
            remoteIP9: [],
            saveRemoteTorF0: [],
            saveRemoteTorF1: [],
            saveRemoteTorF2: [],
            saveRemoteTorF3: [],
            saveRemoteTorF4: [],
            saveRemoteTorF5: [],
            saveRemoteTorF6: [],
            saveRemoteTorF7: [],
            saveRemoteTorF8: [],
            saveRemoteTorF9: [],
            saveLocalTorF0: [],
            saveLocalTorF1: [],
            saveLocalTorF2: [],
            saveLocalTorF3: [],
            saveLocalTorF4: [],
            saveLocalTorF5: [],
            saveLocalTorF6: [],
            saveLocalTorF7: [],
            saveLocalTorF8: [],
            saveLocalTorF9: [],
        };
        this.init();
    }

    init = async() => {
        let loadstatClient = document.getElementById('loadingClient');
        let loadstatServer = document.getElementById('loadingServer');
        let mainstatClient = document.getElementById('displayClient');
        let mainstatServer = document.getElementById('displayServer');
        // let clientButton = document.getElementById('clientButton');
        // let serverButton = document.getElementById('serverButton');
        let container = document.getElementById('container');

        switch (currentModuleType) {
            case MODULE_TYPE_CODE.MOD012:
                this.state.modType = "8DI4RELAY";
                this.state.channelIDPort = 4;
                for(let i = 0; i < 4; i++) {
                    this.state.localChPort.push(false)
                }
                this.state.haveIandO = true;
                this.state.localDeviceType = "DIDO";
                break;
            case MODULE_TYPE_CODE.MOD016:
                this.state.modType = "8DI8DO";
                this.state.channelIDPort = 8;
                for(let i = 0; i < 8; i++) {
                    this.state.localChPort.push(false)
                }
                this.state.haveIandO = true;
                this.state.localDeviceType = "DIDO";
                break;
            case MODULE_TYPE_CODE.MOD108:
                this.state.modType = "8AI";
                this.state.localDeviceType = "AI";
                break;
            case MODULE_TYPE_CODE.MOD116:
                this.state.modType = "16DI";
                this.state.localDeviceType = "DI";
                break;
            case MODULE_TYPE_CODE.MOD208:
                this.state.modType = "8AO";
                this.state.channelIDPort = 8;
                for(let i = 0; i < 8; i++) {
                    this.state.localChPort.push(false)
                }
                this.state.localDeviceType = "AO";
                break;
            case MODULE_TYPE_CODE.MOD216:
                this.state.modType = "16DO";
                this.state.channelIDPort = 16;
                for(let i = 0; i < 16; i++) {
                    this.state.localChPort.push(false)
                }
                this.state.localDeviceType = "DO";
                break;
            // case MODULE_TYPE_CODE.MOD008:
            //     this.state.modType = "4AI4AO";
            //     this.state.channelIDPort = 4;
            //     break;
            // case MODULE_TYPE_CODE.MOD016P:
            //     this.state.modType = "8DI6DO2PWM";
            //     break;                
        }
        
        try {
            const peerToPeerSetting = await Api.getPeerToPeerSettings();
            const { server, client, serverPort } = peerToPeerSetting;
            this.state.server = server;
            this.state.client = client;
            this.state.serverPort = serverPort;
            if(this.state.modType === "8AI" || this.state.modType === "16DI") {
                mainstatClient.style.display = 'block';
                this.loadingClientPage();
            } else if(this.state.modType === "8AO") {
                mainstatServer.style.display = 'block';
                this.loadingServerPage();
                const analogOutputs = (await Api.getAnalogOutput()).io.ao;
                this.state.aoIsVorC = analogOutputs.map(item => {
                    return item.aoMode === 0 ? true : false
                });
            } else if(this.state.modType === "16DO") {
                mainstatServer.style.display = 'block';
                const getDO = (await Api.getDigitalOutput()).io.do;
                const doMode = getDO.map(item => {
                    return item.doMode === 1 ? false : true
                });
                this.state.isDOorPulse = doMode;
                this.loadingServerPage();
            } else if(this.state.modType === "8DI4RELAY" || this.state.modType === "8DI8DO") {
                const generateTab = () => {
                    return`
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="tab client nav-link active" id="nav-client-tab" data-bs-toggle="tab" data-bs-target="#nav-client" type="button" role="tab" aria-controls="nav-client" aria-selected="true">Client Mode Setting</button>
                            <button class="tab server nav-link" id="nav-server-tab" data-bs-toggle="tab" data-bs-target="#nav-server" type="button" role="tab" aria-controls="nav-server" aria-selected="false">Server Mode Setting</button>
                        </div>
                    </nav>
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-client" role="tabpanel" aria-labelledby="nav-client-tab">
                            <div class="widget-content nopadding">
                                <div id="loadingClient" style="display:none">Error:<br />Connection to Peer to Peer was lost.</div>
                                <div id="displayClient" class="widget-content nopadding">
                                    <table class="table table-bordered no-footer-border" style="table-layout:fixed">
                                        <thead>
                                            <tr>
                                                <th width="30px">No.</th>
                                                <th width="50px">Enable</th>
                                                <th width="170px">Remote IP</th>
                                                <th width="66%">Remote Port</th>
                                            </tr>
                                        </thead>
                                        <tbody id="clientTbody">
                                        </tbody>
                                    </table>
                                    <div id="clientButton" class="allFn">
                                        <button id="clientSave" class="function-style">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-server" role="tabpanel" aria-labelledby="nav-server-tab">
                            <div class="widget-content nopadding">
                                <div id="loadingServer" style="display:none">Error:<br />Connection to Peer to Peer was lost.</div>
                                <div id="displayServer" class="widget-content nopadding">
                                    <table class="table table-bordered no-footer-border" style="table-layout:fixed">
                                        <thead>
                                            <tr>
                                                <th width="30px">No.</th>
                                                <th width="50px">Enable</th>
                                                <th width="170px">Remote Client IP Address</th>
                                                <th class="icon-style" width="23%" colspan="2">Remote Input</th>
                                                <th class="icon-style" width="23%" colspan="2">Local Output</th>
                                                <th width="20%">Signal</th>
                                            </tr>
                                            <tr>
                                                <th></th>
                                                <th></th>
                                                <th></th>
                                                <th>Starting CH</th>
                                                <th>CH Count</th>
                                                <th>Starting CH</th>
                                                <th>CH Count</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody id="serverTbody">
                                        </tbody>
                                    </table>
                                    <div id="serverButton" class="allFn">
                                        <button id="serverSave" class="function-style">Save</button>
                                        <span>Local Server Port: <input type="number" id="localPort" title="Range: 1-65535; default is 9020" min="1" max="65535"></input></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    `;
                }
                container.innerHTML = generateTab();     
                const getDO = (await Api.getDigitalOutput()).io.do;
                const doMode = getDO.map(item => {
                    return item.doMode === 1 ? false : true
                });
                this.state.isDOorPulse = doMode;
                
                this.loadingClientPage();

                const clientDiv = document.getElementById('nav-client-tab');
                clientDiv.addEventListener('click', (e) => {
                    this.loadingClientPage();
                });
                const serverDiv = document.getElementById('nav-server-tab');
                serverDiv.addEventListener('click', (e) => {
                    this.loadingServerPage();
                });
            }
            const clientSave = document.getElementById('clientSave');
            const serverSave = document.getElementById('serverSave');
            if(clientSave) {
                clientSave.addEventListener('click', this.clientSave);
                setDisableSingleOrButton(clientSave);
            }
            if(serverSave) {
                serverSave.addEventListener('click', this.serverSave);
                setDisableSingleOrButton(serverSave);
            }
        } catch (error) {
            ErrorUtility.handleError(error);
            mainstatClient.style.display = 'none';
            mainstatServer.style.display = 'none';
            if(this.state.modType === "8AI" || this.state.modType === "16DI" || this.state.modType === "8DI8DO" || this.state.modType === "8DI4RELAY") {
                loadstatClient.style.display = 'inline';
            }else if(this.state.modType === "8AO" || this.state.modType === "16DO" || this.state.modType === "8DI8DO" || this.state.modType === "8DI4RELAY") {
                loadstatServer.style.display = 'inline';
            }
        }
        if (!(currentPage instanceof PeerToPeerPage)) {
            return;
        }
    }

    checkRemoteAndLocal = () => {
        let allInconsistentChannels = [];
        
        for(let i = 0; i < this.state.server.length; i++) {
            const enable = document.getElementById('S_enabled' + i).checked ? 1 : 0;
            const serverCh = document.getElementById('S_channelID' + i).value;
            const getNumber = Number(serverCh.split('-')[1]);
            const remoteCh = document.getElementById('S_remoteChannelID' + i).value;
            const getRemoteNumber = Number(remoteCh.split('-')[1]);

            // console.log(1, i, enable, this.state);
            this.state[`saveRemoteTorF${i}`] = [];
            this.state[`saveLocalTorF${i}`] = [];
            this.checkRemoteAndLocalChMode(i);
            // console.log(2, i, enable, this.state);
            if(enable === 1 && this.state[`saveRemoteTorF${i}`].length === this.state[`saveLocalTorF${i}`].length) {
                for(let j = 0; j < this.state[`saveRemoteTorF${i}`].length; j++) {
                    if(this.state[`saveRemoteTorF${i}`][j] !== this.state[`saveLocalTorF${i}`][j]) {
                        allInconsistentChannels.push(`AI-0${getRemoteNumber + j} at No.${i + 1}`);
                    }
                }
            } else if(enable === 1 && this.state[`saveRemoteTorF${i}`].length !== this.state[`saveLocalTorF${i}`].length) {
                for(let j = 0; j < this.state[`saveLocalTorF${i}`].length; j++) {
                    if(this.state[`saveLocalTorF${i}`][j] !== this.state[`saveRemoteTorF${i}`][0]) {
                        allInconsistentChannels = [];
                        allInconsistentChannels.push(`AI-0${getRemoteNumber} at No.${i + 1}`);
                    }
                }
            } else {
                continue;
            }
        }
        if (allInconsistentChannels.length > 0) {
            const allCh = allInconsistentChannels.join(', ');
            DialogUtility.showError({
                text: allInconsistentChannels.length === 1 ? "The mode of the following channel has changed, please check the mode: " + allCh
                : "The mode of the following channels has changed, please check the mode: " + allCh,
            });
        }
    }

    clientSave = async(e) => {
        e.preventDefault();
        const customErrorProps = {
            data: {
                error: {
                message: "",
                }
            }
        };
        try {
            const payload = {
                client: [],
            };

            for(let i = 0; i < 10; i++) {
                const clientEnable = document.getElementById('C_enabled' + i).checked ? 1 : 0;
                const clientIP = document.getElementById('C_remoteIP' + i).value.trim();
                const clientPort = parseInt(document.getElementById('C_remotePort' + i).value);

                payload.client.push({
                    index: i,
                    enabled: clientEnable,
                    remoteIP: clientIP,
                    remotePort: clientPort,
                    interval: 2000
                });

                if(clientEnable === 1 && !clientIP || clientPort === "") {
                    customErrorProps.data.error.message = `All fields at No.${i + 1} are required.`;
                    throw new CustomError(customErrorProps);
                } else if(clientEnable === 1 && StringUtility.validIP(clientIP) === false) {
                    customErrorProps.data.error.message = `Remote IP at No.${i + 1} is invalid.`;
                    throw new CustomError(customErrorProps);
                }
                if (clientEnable === 1 && (isNaN(clientPort) || clientPort < 1 || clientPort > 65535)) {
                    customErrorProps.data.error.message = `Remote Port at No.${i + 1} must be between 1 and 65535.`;
                    throw new CustomError(customErrorProps);
                }
            }
            
            const res = await Api.editPeerToPeerSettings(payload);
            
            DialogUtility.showSuccess({
                text: res.error.message,
            });

            const peerToPeerSetting = await Api.getPeerToPeerSettings(); // Reload page
            const { client } = peerToPeerSetting;
            this.state.client = client;
            this.loadingClientPage();
        } catch (error) {
            ErrorUtility.handleError(error);
        } finally {
            this.state.localChPort = [];
            for(let i = 0; i < this.state.channelIDPort; i++) {
                this.state.localChPort.push(false)
            }
        }
    }
    serverSave = async(e) => {
        e.preventDefault();
        const customErrorProps = {
            data: {
                error: {
                message: "",
                }
            }
        };
        
        try {
            const serverPort = parseInt(document.getElementById('localPort').value);
            
            const payload = {
                server: [],
                serverPort: serverPort,
            };
            this.state.localChPort = [];
            for(let i = 0; i < 10; i++) {
                const serverEnable = document.getElementById('S_enabled' + i).checked ? 1 : 0;
                const remoteIP = document.getElementById('S_remoteIP' + i).value.trim();
                const serverRemoteCh = document.getElementById('S_remoteChannelID' + i).value;
                const getRemoteNumber = Number(serverRemoteCh.split('-')[1]);
                const serverRemoteCount = parseInt(document.getElementById('S_remoteCount' + i).value);
                const serverCh = document.getElementById('S_channelID' + i).value;
                const getNumber = Number(serverCh.split('-')[1]);
                const serverLocalCount = parseInt(document.getElementById('S_localCount' + i).value);
                
                if(this.state.modType === "8AO" ) {
                    const S_function = document.getElementById(`S_function${i}`).value;
                    const S_funcValue = document.getElementById(`S_funcValue${i}`).value;
                    if(S_function !== 0 && (isNaN(S_funcValue) || S_funcValue < 0)) {
                        customErrorProps.data.error.message = `The value of Signal at No.${i + 1} is invalid.`;
                        throw new CustomError(customErrorProps);
                    } else {
                        payload.server.push({
                            index: i,
                            enabled: serverEnable,
                            remoteIP: remoteIP,
                            remoteCount: serverRemoteCount,
                            channelID: serverCh,
                            localCount: serverLocalCount,
                            remoteChannelID: serverRemoteCh,
                            function: parseInt(S_function),
                            funcValue: parseInt(S_funcValue)
                        });
                    }
                } else {
                    const serverReverse = document.getElementById('S_reverse' + i).value;
                    payload.server.push({
                        index: i,
                        enabled: serverEnable,
                        remoteIP: remoteIP,
                        remoteCount: serverRemoteCount,
                        channelID: serverCh,
                        localCount: serverLocalCount,
                        remoteChannelID: serverRemoteCh,
                        reverse: parseInt(serverReverse)
                    });
                }
                
                console.log(payload);
                
                this.state[`saveRemoteTorF${i}`] = [];
                this.state[`saveLocalTorF${i}`] = [];

                this.checkRemoteCount(i);
                this.checkChannelID(i);

                if(serverEnable === 1 && !remoteIP || serverRemoteCount === "" || serverLocalCount === "") {
                    customErrorProps.data.error.message = `All fields at No.${i + 1} are required.`;
                    throw new CustomError(customErrorProps);
                } else if(serverEnable === 1 && StringUtility.validIP(remoteIP) === false) {
                    customErrorProps.data.error.message = `Remote IP at No.${i + 1} is invalid.`;
                    throw new CustomError(customErrorProps);
                } else if(serverEnable === 1 && serverRemoteCh === "") {
                    customErrorProps.data.error.message = `Remote Starting CH at No.${i + 1} is required.`;
                    throw new CustomError(customErrorProps);
                } else if(serverEnable === 1 && serverCh === "") {
                    customErrorProps.data.error.message = `Local Starting CH at No.${i + 1} is required.`;
                    throw new CustomError(customErrorProps);
                } else if (serverEnable === 1 && (serverRemoteCount + getRemoteNumber > this.state.remoteChPort[i] || serverRemoteCount < 1)) {  //邏輯C
                    customErrorProps.data.error.message = `Remote CH Count at No.${i + 1} is invalid.`;
                    throw new CustomError(customErrorProps);
                } else if(serverEnable === 1 && (serverLocalCount + getNumber > this.state.channelIDPort || serverLocalCount < 1)) {  //邏輯B
                    customErrorProps.data.error.message = `Local CH Count at No.${i + 1} is invalid.`;
                    throw new CustomError(customErrorProps);
                } else if(serverEnable === 1 && serverRemoteCount > 1 && serverRemoteCount !== serverLocalCount) {  //邏輯A
                    customErrorProps.data.error.message = `Remote CH Count and Local CH Count at No.${i + 1} must be the same.`;
                    throw new CustomError(customErrorProps);
                } else if(serverEnable === 0 && (serverCh !== "" || serverLocalCount > 0)) {
                    customErrorProps.data.error.message = `Local Starting CH or CH Count at No.${i + 1} is invalid.`;
                    throw new CustomError(customErrorProps);
                } else if(serverEnable === 1 && this.state[`saveRemoteTorF${i}`].length === this.state[`saveLocalTorF${i}`].length && this.state[`saveRemoteTorF${i}`].length !== 0) {
                    for(let j = 0; j < this.state[`saveRemoteTorF${i}`].length; j++) {
                        if(this.state[`saveRemoteTorF${i}`][j] !== this.state[`saveLocalTorF${i}`][j]) {
                            customErrorProps.data.error.message = `The mode of Local CH AO-0${getNumber + j} at No.${i + 1} is inconsistent.`;
                            throw new CustomError(customErrorProps);
                        }
                    }
                } else if(serverEnable === 1 && this.state[`saveRemoteTorF${i}`].length !== this.state[`saveLocalTorF${i}`].length && this.state[`saveRemoteTorF${i}`].length !== 0) {
                    for(let j = 0; j < this.state[`saveLocalTorF${i}`].length; j++) {
                        if(this.state[`saveLocalTorF${i}`][j] !== this.state[`saveRemoteTorF${i}`][0]) {
                            customErrorProps.data.error.message = `The mode of Local CH AO-0${getNumber + j} at No.${i + 1} is inconsistent.`;
                            throw new CustomError(customErrorProps);
                        }
                    }
                }
            }
            if (isNaN(serverPort)) {
                customErrorProps.data.error.message = "Server Port is required.";
                throw new CustomError(customErrorProps);
            } else if (serverPort < 1 || serverPort > 65535) {
                customErrorProps.data.error.message = "Server Port must be between 1 and 65535.";
                throw new CustomError(customErrorProps);
            } 
            
            const res = await Api.editPeerToPeerSettings(payload);
            
            DialogUtility.showSuccess({
                text: res.error.message,
            });

            const peerToPeerSetting = await Api.getPeerToPeerSettings(); // Reload page
            this.state.server = peerToPeerSetting.server;
            this.state.serverPort = peerToPeerSetting.serverPort;
            this.loadingServerPage();
        } catch (error) {
            ErrorUtility.handleError(error);
        } finally {
            this.state.localChPort = [];
            for(let i = 0; i < this.state.channelIDPort; i++) {
                this.state.localChPort.push(false)
            }
        }
    }

    loadingClientPage = () => {
        this.state.allClientIP = this.state.client.map(item => item.remoteIP);

        const clientTbody = document.getElementById('clientTbody');
        clientTbody.innerHTML = "";

        for (let i = 0; i < 10; i++) {
            const matchClient = this.state.client.find(item => item.index == i);
            const clientRow = document.createElement('tr');
            
            clientRow.innerHTML = `
                <td class="font-style"><span id="C_index${i}">${i + 1}</span></td>
                <td class="icon-style"><input id="C_enabled${i}" type="checkbox" ${matchClient?.enabled === 1 ? 'checked' : ''}></td>
                <td class="font-style"><input id="C_remoteIP${i}" type="text" value="${matchClient?.remoteIP}"></td>
                <td class="font-style"><input id="C_remotePort${i}" type="number" min="1" max="65535" style="width: 80px;" title="Range: 1-65535" value="${matchClient?.remotePort}"></td>
            `;
            clientTbody.appendChild(clientRow);
            const remoteIP = document.getElementById('C_remoteIP' + i);
            if(remoteIP){
                remoteIP.addEventListener('blur', () => this.getIp(i, "client"));
            }
        }
        setDisableWithRadio();
        this.getAllIp("client");
    }

    loadingServerPage = () => {
        const localPort = document.getElementById('localPort');
    
        this.state.allServerIP = this.state.server.map(item => item.remoteIP);
        this.state.serverBoard = this.state.server;
        setDomProperty(localPort, "value", this.state.serverPort);

        const serverTbody = document.getElementById('serverTbody');
        serverTbody.innerHTML = "";

        for (let i = 0; i < 10; i++) {
            const matchServer = this.state.server.find(item => item.index == i);
            const serverRow = document.createElement('tr');
            
            serverRow.innerHTML = `
                <td class="font-style"><span id="S_index${i}">${i + 1}</span></td>
                <td class="icon-style"><input id="S_enabled${i}" type="checkbox" ${matchServer?.enabled === 1 ? 'checked' : ''}></td>
                <td class="font-style"><input id="S_remoteIP${i}" type="text" value="${matchServer?.remoteIP}"></td>
                <td class="font-style"><select id="S_remoteChannelID${i}" style="width:90px;border: none;"></select></td>
                <td class="font-style"><input id="S_remoteCount${i}" type="number" style="width: 80px;" value="${matchServer?.remoteCount}" min="0"></td>
                <td class="font-style"><select id="S_channelID${i}" style="width:90px;border: none;"></select></td>
                <td class="font-style"><input id="S_localCount${i}" type="number" style="width: 80px;" value="${matchServer?.localCount}" min="0"></td>
                ${ this.state.modType === "8AO" 
                    ? 
                    `<td class="font-style">
                        <select id="S_function${i}" style="width:80px;border:none;" value="${matchServer?.function}">
                            <option value="0">Mirror</option>
                            <option value="1">+=</option> 
                            <option value="2">-=</option>
                            <option value="3">*=</option>
                            <option value="4">/=</option>
                        </select>
                        <input id="S_funcValue${i}" type="number" step="0.0001" value="${matchServer?.funcValue}" style="width: 80px; margin-left: 10px" min="0" disabled="${matchServer?.function === 0 ? true : false}">
                    </td>`
                    :
                    `<td class="font-style">
                        <select id="S_reverse${i}" style="width:80px;border:none;">
                            <option value="0">Mirror</option>
                            <option value="1">Reverse</option> 
                        </select>
                    </td>`
                }
            `;
            serverTbody.appendChild(serverRow);

            const functionSelect = document.getElementById(`S_function${i}`);
            const funcValueInput = document.getElementById(`S_funcValue${i}`);
            if (functionSelect && funcValueInput) {
                functionSelect.value = matchServer?.function;
                funcValueInput.disabled = matchServer?.function === 0;
    
                functionSelect.addEventListener('change', () => {
                    const selectedValue = parseInt(functionSelect.value, 10);
                    funcValueInput.disabled = selectedValue === 0;
                    funcValueInput.value = selectedValue === 0 ? 0 : funcValueInput.value;
                });
            }

            const reverseSelect = document.getElementById(`S_reverse${i}`);
            if (reverseSelect && matchServer?.reverse !== undefined) {
                reverseSelect.value = matchServer.reverse;
            }
            const remoteIP = document.getElementById('S_remoteIP' + i);
            if(remoteIP){
                remoteIP.addEventListener('blur', () => this.getIp(i, "server"));
            }
            const enabled = document.getElementById('S_enabled' + i);
            if(enabled){
                enabled.addEventListener('change', () => this.enableToResetChannelID(i, enabled));
            }

        }
        setDisableWithRadio();
        this.getAllIp("server");
        this.setLocalChPort(this.state.modType, this.state.channelIDPort, this.state.server);
    }
    
    getAllIp = async(type) => {
        const payload = {
            ips:[]
        };
        if(type === "client") {
            for(let i = 0; i < 10; i++) {
                const clientIP = document.getElementById('C_remoteIP' + i).value;
                if(clientIP !== "") {
                    payload.ips.push({
                        ip: clientIP
                    });
                }
            }
        } else if(type === "server") {
            for(let i = 0; i < 10; i++) {
                const remoteIP = document.getElementById('S_remoteIP' + i).value;
                if(remoteIP !== "") {
                    payload.ips.push({
                        ip: remoteIP
                    });
                }
            }
        }
        if(payload.ips.length > 0) {
            const ioSearchResult = await Api.ipSearch(payload);
            if(type === "server") {
                this.getDeviceName(ioSearchResult, "server", "all", null, payload);
                
            } else if(type === "client") {
                this.getDeviceName(ioSearchResult, "client", "all");
            }
        } else {
            return;
        }
    }
    
    getIp = async(index, type) => {
        const remoteIP = document.getElementById('S_remoteIP' + index) ? document.getElementById('S_remoteIP' + index).value.trim() : null;
        const remoteChannelID = document.getElementById('S_remoteChannelID' + index) ? document.getElementById('S_remoteChannelID' + index) : null;
        const clientIP = document.getElementById('C_remoteIP' + index) ? document.getElementById('C_remoteIP' + index).value.trim() : null;

        try {
            const payload = {
                ips:[]
            };
            if(type === "server") {
                if(remoteIP !== "") {
                    payload.ips.push({
                        ip: remoteIP
                    });
                } else {
                    remoteChannelID.innerHTML = "";
                    this.state.remoteChPort[index] = null;
                    this.state[`remoteIP${index}`] = [];
                }
            } else if(type === "client") {
                if(clientIP !== "") {
                    payload.ips.push({
                        ip: clientIP
                    });
                } else {
                    this.state.localChPort[index] = null;
                }
            }
            if(payload.ips.length > 0) {
                const ioSearchResult = await Api.ipSearch(payload);
                if(type === "server") {
                    this.getDeviceName(ioSearchResult, "server", index, remoteIP, payload);
                } else if(type === "client") {
                    this.getDeviceName(ioSearchResult, "client", index, clientIP);
                }
            } else {
                return;
            }
        } catch (error) {
            ErrorUtility.handleError(error);
        }
    }
    
    getDeviceName = async(ioSearchResult, type, allOrSingle, remoteIP, payload) => {
        const remoteChannelID = allOrSingle !== "all" ? document.getElementById('S_remoteChannelID' + allOrSingle) : null;
        const customErrorProps = {
            data: {
                error: {
                message: "",
                }
            }
        };
        
        try {
            let reOrderArr = ioSearchResult;
            //當是All時，讓allServerIP的順序與ioSearchResult的順序一致
            let errorIPs = [];
            if(allOrSingle === "all" && type === "server") {
                reOrderArr = this.state.allServerIP
                    .map((ip, index) => {
                        const foundItem = ioSearchResult.find(item => item?.sysInfo?.network?.WAN?.wanIp === ip);
                        if (!foundItem && ip) {
                            errorIPs.push({
                                ip: this.state.allServerIP[index],
                                index: index
                            });
                            return null;
                        }
                        return foundItem;
                    })
            } else if(allOrSingle === "all" && type === "client") {
                reOrderArr = this.state.allClientIP
                    .map((ip, index) => {
                        const foundItem = ioSearchResult.find(item => item?.sysInfo?.network?.WAN?.wanIp === ip);
                        if (!foundItem && ip) {
                            errorIPs.push({
                                ip: this.state.allClientIP[index],
                                index: index
                            });
                            return null;
                        }
                        return foundItem;
                    })
            }

            if(allOrSingle !== "all") {
                if(reOrderArr[0].error) {
                    customErrorProps.data.error.message = "No device found at IP: " + remoteIP;
                    if(type === "server"){
                        remoteChannelID.innerHTML = "";
                    };
                    throw new CustomError(customErrorProps);
                }
            }
            const deviceName = reOrderArr.map(item => item ? item.sysInfo.device.deviceName : null);

            if(type === "server") {
                for(let i = 0; i < deviceName.length; i++) {
                    if (!deviceName[i]) {
                        continue;
                    }
                    switch (deviceName[i]) {
                        case "8AI":
                            if(this.state.localDeviceType === "AO") {
                                this.setRemoteChOption(i, "AI", 8, allOrSingle);
                            } else if(allOrSingle === "all") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + this.state.allServerIP[i];
                                throw new CustomError(customErrorProps);
                            } else if(typeof(allOrSingle) === "number") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + remoteIP;
                                remoteChannelID.innerHTML = "";
                                throw new CustomError(customErrorProps);
                            }
                            break;
                        case "8DI4RELAY":
                        case "8DI8DO":
                            if(this.state.localDeviceType === "DI" || this.state.localDeviceType === "DO" || this.state.localDeviceType === "DIDO") {
                                this.setRemoteChOption(i, "DI", 8, allOrSingle);
                            } else if(allOrSingle === "all") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + this.state.allServerIP[i];
                                throw new CustomError(customErrorProps);
                            } else if(typeof(allOrSingle) === "number") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + remoteIP;
                                remoteChannelID.innerHTML = "";
                                throw new CustomError(customErrorProps);
                            }
                            break;
                        case "16DI":
                            if(this.state.localDeviceType === "DO" || this.state.localDeviceType === "DIDO") {
                                this.setRemoteChOption(i, "DI", 16, allOrSingle);
                            } else if(allOrSingle === "all") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + this.state.allServerIP[i];
                                throw new CustomError(customErrorProps);
                            } else if(typeof(allOrSingle) === "number") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + remoteIP;
                                remoteChannelID.innerHTML = "";
                                throw new CustomError(customErrorProps);
                            }
                            break;
                        case "8AO":
                        case "16DO":
                            if(allOrSingle === "all") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + this.state.allServerIP[i];
                                throw new CustomError(customErrorProps);
                            } else if(typeof(allOrSingle) === "number") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + remoteIP;
                                remoteChannelID.innerHTML = "";
                                throw new CustomError(customErrorProps);
                            }
                        default:
                            break;
                    }
                }
                //最後處理，以免其他Starting CH不顯示
                if(allOrSingle === "all" && errorIPs.length > 0 && this.state.userRole === "admin") {
                    customErrorProps.data.error.message = `No device found at IP: ${errorIPs.map(item => item.ip).join(', ')}`;
                    throw new CustomError(customErrorProps);
                }
            } else if(type === "client") {
                for(let i = 0; i < deviceName.length; i++) {
                    if (!deviceName[i]) {
                        continue;
                    }
                    switch (deviceName[i]) {
                        case "8AI":
                        case "16DI":
                            if(allOrSingle === "all") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + this.state.allClientIP[i];
                                throw new CustomError(customErrorProps);
                            } else if(typeof(allOrSingle) === "number") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + remoteIP;
                                throw new CustomError(customErrorProps);
                            }
                            break;                      
                        case "8DI4RELAY":
                        case "8DI8DO":
                            if(allOrSingle === "all" && this.state.localDeviceType !== "DO" && this.state.localDeviceType !== "DI" && this.state.localDeviceType !== "DIDO") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + this.state.allClientIP[i];
                                throw new CustomError(customErrorProps);
                            } else if(typeof(allOrSingle) === "number" && this.state.localDeviceType !== "DO" && this.state.localDeviceType !== "DI" && this.state.localDeviceType !== "DIDO") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + remoteIP;
                                throw new CustomError(customErrorProps);
                            }
                            break;
                        case "16DO":
                            if(allOrSingle === "all" && this.state.localDeviceType !== "DI" && this.state.localDeviceType !== "DIDO") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + this.state.allClientIP[i];
                                throw new CustomError(customErrorProps);
                            } else if(typeof(allOrSingle) === "number" && this.state.localDeviceType !== "DI" && this.state.localDeviceType !== "DIDO") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + remoteIP;
                                throw new CustomError(customErrorProps);
                            }
                            break;
                        case "8AO":
                            if(allOrSingle === "all" && this.state.localDeviceType !== "AI") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + this.state.allClientIP[i];
                                throw new CustomError(customErrorProps);
                            } else if(typeof(allOrSingle) === "number" && this.state.localDeviceType !== "AI") {
                                customErrorProps.data.error.message = "Device type does not match at IP: " + remoteIP;
                                throw new CustomError(customErrorProps);
                            }
                            break;
                        default:
                            break;
                    }
                }
                if(allOrSingle === "all" && errorIPs.length > 0 && this.state.userRole === "admin") {
                    customErrorProps.data.error.message = `No device found at IP: ${errorIPs.map(item => item.ip).join(', ')}`;
                    throw new CustomError(customErrorProps);
                }
            }
            // console.log(type, allOrSingle, deviceName[0], this.state.modType);
            if(type === "server" && allOrSingle === "all" && this.state.modType === "8AO") {
                let payloadIndex = 0;
                for(let i = 0; i < deviceName.length; i++) {
                    if (!deviceName[i]) {
                        continue;
                    } else {
                        let getRemoteChMode = [];
                        const singleIpPayload = { ips: [payload.ips[payloadIndex]] };
                        payloadIndex++;
                        for (let attempt = 1; attempt <= 5; attempt++) {
                            try {
                                const response = await Api.ipSearchio(singleIpPayload);
                                getRemoteChMode = response[0]?.io?.ai;

                                if (getRemoteChMode) break;
                            } catch (error) {
                                customErrorProps.data.error.message = `No input data found at No.${i + 1}`;
                                throw new CustomError(customErrorProps);
                            }
                        }
                        this.state[`remoteIP${i}`] = getRemoteChMode.map(item => item.aiMode === 0 ? true : false);
                    }
                }
            }
            if(type === "server" && allOrSingle !== "all" && deviceName[0] === "8AI") {
                let getRemoteChMode = [];
                for (let attempt = 1; attempt <= 5; attempt++) {
                    try {
                        const response = await Api.ipSearchio(payload);
                        getRemoteChMode = response[0]?.io?.ai;
    
                        if (getRemoteChMode) break;
                    } catch (error) {
                        customErrorProps.data.error.message = `No input data found No.${i + 1}`;
                        throw new CustomError(customErrorProps);
                    }
                }
                this.state[`remoteIP${allOrSingle}`] = getRemoteChMode.map(item => item.aiMode === 0 ? true : false);
            }
            if(type === "server" && allOrSingle === "all" && this.state.modType === "8AO") {
                this.checkRemoteAndLocal();
            }
        } catch (error) {
            ErrorUtility.handleError(error);
        }
    }

    setRemoteChOption = (index, type, port, allOrSingle) => {
        let selectElement;

        if (allOrSingle === "all") {
            selectElement = document.getElementById('S_remoteChannelID' + index);
        } else {
            selectElement = document.getElementById('S_remoteChannelID' + allOrSingle);
        }
        if (selectElement && allOrSingle !== "all") {
            selectElement.innerHTML = "";
        }

        if(type === "AI" && this.state.localDeviceType === "AO") {
            for(let i = 0; i < 8; i++) {
                let option = document.createElement("option");
                option.text = `AI-0` + i;
                option.value = `AI-0` + i;
                if (selectElement) {
                    selectElement.add(option.cloneNode(true));
                    selectElement.value = this.state.serverBoard[index]?.remoteChannelID;
                }
            }
        } else if(type === "DI" && (this.state.localDeviceType === "DO" || this.state.localDeviceType === "DIDO")) {
            for(let i = 0; i < port; i++) {
                let option = document.createElement("option");
                if(i > 9) {
                    option.text = `DI-` + i;
                    option.value = `DI-` + i;
                }else {
                    option.text = `DI-0` + i;
                    option.value = `DI-0` + i;
                }
                if (selectElement) {
                    selectElement.add(option.cloneNode(true));
                    selectElement.value = this.state.serverBoard[index]?.remoteChannelID;
                }
            }
        }
        if(allOrSingle === "all") {
            this.state.remoteChPort[index] = port;
        } else if(allOrSingle !== "all") {
            this.state.remoteChPort[allOrSingle] = port;
        }
    }
    
    //邏輯E
    setLocalChPort = (modType, channelIDPort, server) => {
        if (modType === "8AO") {
            for(let i = 0; i < channelIDPort; i++) {
                
                let option = document.createElement("option");
                option.text = `AO-0` + i;
                option.value = `AO-0` + i;
                for (let j = 0; j < 10; j++) {
                    let selectElement = document.getElementById('S_channelID' + j);
                    const matchServer = server.find(item => item.index == j);
                    if (selectElement) {
                        selectElement.add(option.cloneNode(true));
                        selectElement.value = matchServer?.channelID
                    }
                }
            }
        } else if (modType === "8DI4RELAY" || modType === "8DI8DO" || modType === "16DO") {
            for(let i = 0; i < channelIDPort; i++) {
                let option = document.createElement("option");
                if(i > 9) {
                    option.text = `DO-` + i;
                    option.value = `DO-` + i;
                }else {
                    option.text = `DO-0` + i;
                    option.value = `DO-0` + i;
                }
                for(let j = 0; j < 10; j++) {
                    let selectElement = document.getElementById('S_channelID' + j);
                    const matchServer = server.find(item => item.index == j);
                    if (selectElement) {
                        selectElement.add(option.cloneNode(true));
                        selectElement.value = matchServer?.channelID
                    }
                }
            }
        }
    }

    checkChannelID = (index) => {
        const enabled = document.getElementById('S_enabled' + index).checked;
        const localCh = document.getElementById('S_channelID' + index).value;
        const localCount = document.getElementById('S_localCount' + index).value;
        const getNumber = Number(localCh.split('-')[1]);

        const customErrorProps = {
            data: {
                error: {
                message: "",
                }
            }
        };

        for(let i = 0; i < localCount; i++) {
            if(enabled === false) {
                continue;
            } else if (localCh !== "" && localCount > 0 && this.state.localChPort[getNumber + i] !== true) {
                this.state.localChPort[getNumber + i] = true;
                this.state[`saveLocalTorF${index}`].push(this.state.aoIsVorC[i + getNumber]);
            } else if (this.state.localChPort[getNumber + i] === true) {
                if(this.state.channelIDPort > 8){
                    customErrorProps.data.error.message = `Local CH DO-${getNumber + i} is already used.`;
                } else {
                    if(this.state.modType !== "8AO") {
                        customErrorProps.data.error.message = `Local CH DO-0${getNumber + i} is already used.`;
                    }else {
                        customErrorProps.data.error.message = `Local CH AO-0${getNumber + i} is already used.`;
                    }
                }
                for(let i = 0; i < this.state.channelIDPort; i++) {
                    this.state.localChPort.push(false)
                }
                throw new CustomError(customErrorProps);
            }
            if (this.state.localChPort[getNumber + i] === true && this.state.isDOorPulse[getNumber + i] === false ){
                if(this.state.channelIDPort > 8){
                    customErrorProps.data.error.message = `Local CH DO-${getNumber + i} is pulse mode.`;
                } else {
                    customErrorProps.data.error.message = `Local CH DO-0${getNumber + i} is pulse mode.`;
                }
                throw new CustomError(customErrorProps);
            } 
        }
    }

    checkRemoteAndLocalChMode = (index) => {
        const enabled = document.getElementById('S_enabled' + index).checked;
        const remoteCh = document.getElementById('S_remoteChannelID' + index).value;
        const getRemoteNumber = Number(remoteCh.split('-')[1]);
        const remoteCount = Number(document.getElementById('S_remoteCount' + index).value);       

        const localCh = document.getElementById('S_channelID' + index).value;
        const getNumber = Number(localCh.split('-')[1]);
        const localCount = Number(document.getElementById('S_localCount' + index).value);

        if(remoteCount !== 0 && getRemoteNumber + remoteCount <= 8){
            for(let i = 0; i < remoteCount; i++) {
                this.state[`saveRemoteTorF${index}`].push(this.state[`remoteIP${index}`][i + getRemoteNumber]);
            }
        }
        for(let i = 0; i < localCount; i++) {
            if(enabled === false) {
                continue;
            } else if (localCh !== "" && localCount > 0 && this.state.localChPort[getNumber + i] !== true) {
                this.state.localChPort[getNumber + i] = true;
                this.state[`saveLocalTorF${index}`].push(this.state.aoIsVorC[i + getNumber]);
            }
        }
    }
    checkRemoteCount = (index) => {
        const remoteCh = document.getElementById('S_remoteChannelID' + index).value;
        const getRemoteNumber = Number(remoteCh.split('-')[1]);
        const remoteCount = Number(document.getElementById('S_remoteCount' + index).value);
        
        const customErrorProps = {
            data: {
                error: {
                message: "",
                }
            }
        };
        
        if(remoteCount !== 0 && getRemoteNumber + remoteCount <= this.state.remoteChPort[index]){ 
            for(let i = 0; i < remoteCount; i++) {
                this.state[`saveRemoteTorF${index}`].push(this.state[`remoteIP${index}`][i + getRemoteNumber]);
            }
        } else if (getRemoteNumber + remoteCount > 8) {
            customErrorProps.data.error.message = `Remote CH Count at No.${index + 1} is invalid.`;
            throw new CustomError(customErrorProps);
        }
    }

    enableToResetChannelID = (index, enabled) => {
        const channelID = document.getElementById('S_channelID' + index);
        const localCount = document.getElementById('S_localCount' + index);
        if(enabled.checked === false) {
            channelID.value = "";
            localCount.value = 0;
        }        
    }
    
    dispose() {
        
    }
}