/**
 * For all modules
 */
class HomePage {
  constructor(props) {
    this.state = {
    };
    this.init();
    this.state.reload = setInterval(
      this.init,
      5000
    );
  }

  init = () => {
    switch (currentModuleType) {
      case MODULE_TYPE_CODE.MOD008:
        this.initAioStatus();
        break;
      case MODULE_TYPE_CODE.MOD108:
        this.init8AiStatus();
        this.init8AiTemp();
        break;
      case MODULE_TYPE_CODE.MOD208:
        this.init8AoStatus();
        break;
      case MODULE_TYPE_CODE.MOD012:
      case MODULE_TYPE_CODE.MOD016:
      case MODULE_TYPE_CODE.MOD016P:
      case MODULE_TYPE_CODE.MOD116:
      case MODULE_TYPE_CODE.MOD216:
        this.initDioStatus();
        break;
    }
    this.loadSysInfo();
  }

  /**
   * For module 8
   */
  initAioStatus = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    if (mainstat == null || loadstat == null) {
      return;
    }

    // Make sure we're displaying the status display
    mainstat.style.display = 'inline';
    loadstat.style.display = 'none';

    try {
      const analogInputs = (await Api.getAnalogInput()).io.ai;
      const analogOutputs = (await Api.getAnalogOutput()).io.ao;

      if (!(currentPage instanceof HomePage)) {
        return;
      }

      for (let i = 0; i < 4; i++) {
        const DAO_EN_elem = document.getElementById('DAO_EN' + i);
        const AO_elem = document.getElementById('AO' + i);
        const DAO_VAL_elem = document.getElementById('DAO_VAL' + i);
        const AI_elem = document.getElementById('AI' + i);
        const AIMA_elem = document.getElementById('AIMA' + i);
        const hAO_elem = document.getElementById('hAO' + i);
        const hDV_elem = document.getElementById('hDV' + i);
        const hAI_elem = document.getElementById('hAI' + i);

        const input = analogInputs.filter((e) => e.aiIndex == i)[0];
        const output = analogOutputs.filter((e) => e.aoIndex == i)[0];

        if (output?.aoDefaultEnable == 1) {
          setInnerHTML(DAO_EN_elem, "ON");
        } else {
          setInnerHTML(DAO_EN_elem, "OFF");
        }

        setInnerHTML(AO_elem, output?.aoValueScaled);
        setInnerHTML(DAO_VAL_elem, output?.aoDefaultValueScaled);
        setInnerHTML(AI_elem, input?.aiValueScaled?.toFixedNoRounding(4));
        setInnerHTML(AIMA_elem, input?.aiMode == 2 ? 'mA' : 'V');
        setInnerHTML(hAO_elem, "#" + output?.aoValueRaw?.toString(16));
        setInnerHTML(hDV_elem, "#" + output?.aoDefaultValueScaled?.toString(16));
        setInnerHTML(hAI_elem, "#" + input?.aiValueRaw?.toString(16));

      }
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  init8AiStatus = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    if (mainstat == null || loadstat == null) {
      return;
    }

    // Make sure we're displaying the status display
    mainstat.style.display = 'inline';
    loadstat.style.display = 'none';

    try {
      const analogInputs = (await Api.getAnalogInput()).io.ai;

      if (!(currentPage instanceof HomePage)) {
        return;
      }

      for (let i = 0; i < 8; i++) {
        const AI_elem = document.getElementById('AI' + i);
        const AIMA_elem = document.getElementById('AIMA' + i);
        const hAI_elem = document.getElementById('hAI' + i);

        const input = analogInputs.filter((e) => e.aiIndex == i)[0];


        setInnerHTML(AI_elem, input?.aiValueScaled?.toFixedNoRounding(3));
        setInnerHTML(AIMA_elem, input?.aiMode == 2 ? 'mA' : 'V');
        setInnerHTML(hAI_elem, "#" + input?.aiValueRaw?.toString(16));

      }
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  init8AiTemp = async () => {
    // Set the temperature display
    var showInternalTemp = document.getElementById('showInternalTemp');
    showInternalTemp.style.display = 'table-row';

    // Call the API to get the temperature
    try {
      const temp = (await Api.getAITemp()).aiInternalTemp;
      const tempElem = document.getElementById('internalTemp');
      setInnerHTML(tempElem, temp?.toFixedNoRounding(3));
    } catch (error) {
      console.error(error);
    }

  }
  init8AoStatus = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    if (mainstat == null || loadstat == null) {
      return;
    }

    // Make sure we're displaying the status display
    mainstat.style.display = 'inline';
    loadstat.style.display = 'none';

    try {
      const analogOutputs = (await Api.getAnalogOutput()).io.ao;

      if (!(currentPage instanceof HomePage)) {
        return;
      }

      for (let i = 0; i < 8; i++) {
        const aoValueScaled = document.getElementById('aoValueScaled_' + i);
        const aoValueRaw = document.getElementById('aoValueRaw_' + i);
        const aoMode = document.getElementById('aoMode_' + i);
        const aoDefaultEnable = document.getElementById('aoDefaultEnable_' + i);
        const aoDefaultValueScaled = document.getElementById('aoDefaultValueScaled_' + i);
        const aoDefaultMode = document.getElementById('aoDefaultMode_' + i);

        const output = analogOutputs.filter((e) => e.aoIndex == i)[0];

        if (output?.aoDefaultEnable == 1) {
          setInnerHTML(aoDefaultEnable, "ON");
        } else {
          setInnerHTML(aoDefaultEnable, "OFF");
        }

        if (output?.aoMode == 0) {
          setInnerHTML(aoValueScaled, (output?.aoValueScaled) + " V");
          setInnerHTML(aoMode, "Volt.");
        } else {
          setInnerHTML(aoValueScaled, (output?.aoValueScaled) + " mA");
          setInnerHTML(aoMode, "Curr.");
        }

        if (output?.aoDefaultMode == 0) {
          setInnerHTML(aoDefaultMode, "Volt.");
        } else {
          setInnerHTML(aoDefaultMode, "Curr.");
        }

        setInnerHTML(aoValueRaw, "#" + output?.aoValueRaw?.toString(16));
        setInnerHTML(aoDefaultValueScaled, output?.aoDefaultValueScaled);
      }
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  /**
   * For module 12, 16, 116, 216
   */
  initDioStatus = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    if (mainstat == null || loadstat == null) {
      return;
    }

    // Make sure we're displaying the status display
    mainstat.style.display = 'inline';
    loadstat.style.display = 'none';

    try {

      const digitalInputs = (await Api.getDigitalInput()).io.di;
      const digitalOutputs = (await Api.getDigitalOutput()).io.do;

      if (!(currentPage instanceof HomePage)) {
        return;
      }

      const board = [];

      digitalInputs.forEach((input) => {
        const { diIndex } = input;
        board[diIndex] = {};
        board[diIndex].input = input;
      });

      digitalOutputs.forEach((output) => {
        const { doIndex } = output;
        if (board[doIndex] === undefined) {
          board[doIndex] = {};
        }
        board[doIndex].output = output;
      });

      board.forEach((item, index) => {
        const { input, output } = item;
        let channel = output?.doIndex;
        if (channel === undefined) {
          channel = input?.diIndex;
        }

        const cells = [
          { name: "DO", value: output?.doStatus, },
          { name: "DI", value: input?.diStatus, },
          { name: "DDO_EN", value: output?.doDefaultEnable, },
          { name: "DDO_VAL", value: output?.doDefaultValue, },
          { name: "DIC_EN", value: input?.diCounterStatus, },
          { name: "DIC_OF", value: input?.diCounterOverflowFlag, },
          { name: "DIC_VAL", value: input?.diCounterValue, },
        ];

        cells.forEach((cell) => {
          if (cell.name === "DIC_VAL") {
            const cellElem = document.getElementById('DIC_VAL' + channel);
            setInnerHTML(cellElem, cell.value);
          } else {
            this.renderDIOStatusCell({
              index: channel,
              name: cell.name,
              value: cell.value,
            });
          }
        })
      });
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  /**
   * For module 12, 16, 116, 216
   */
  renderDIOStatusCell = ({ name, index, value }) => {
    const id = name + index;
    const cellElem = document.getElementById(id);
    const flag = 0 < (value);

    const fillCircleColor = name == "DIC_OF"
      ? "#FF0000"
      : "#00FF00";

    setCircle(cellElem, flag, {
      fillColor: fillCircleColor,
    });
  }

  loadSysInfo = async () => {
    try {
      await this._loadSysInfo();
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  _loadSysInfo = async () => {
    const mode__elem = document.getElementById("mode");
    const SN__elem = document.getElementById("SN");
    const version__elem = document.getElementById("version");
    const last_boot_time__elem = document.getElementById("last_boot_time");
    const Counter__elem = document.getElementById("Counter");
    const baud_rate__elem = document.getElementById("baud_rate");
    const stop__elem = document.getElementById("stop");
    const parity__elem = document.getElementById("parity");
    const mgen__elem = document.getElementById("mgen");
    const mghostif__elem = document.getElementById("mghostif");
    const config_mghostip__elem = document.getElementById("config_mghostip");
    const config_mac__elem = document.getElementById("config_mac");
    const config_dhcp__elem = document.getElementById("config_dhcp");
    const config_mbap__elem = document.getElementById("config_mbap");
    const config_ip__elem = document.getElementById("config_ip");
    const config_gw__elem = document.getElementById("config_gw");
    const config_submask__elem = document.getElementById("config_submask");
    const config_dns1__elem = document.getElementById("config_dns1");
    const config_dns2__elem = document.getElementById("config_dns2");
    const config_webport__elem = document.getElementById("config_webport");
    const config_tcpport__elem = document.getElementById("config_tcpport");
    const config_udpport__elem = document.getElementById("config_udpport");

    const sysInfo = (await Api.getSysInfo()).sysInfo;
    const {
      device, modbus_gateway, network, rtu,
    } = sysInfo;

    if (!(currentPage instanceof HomePage)) {
      return;
    }

    let lastBootTime = '';
    if (device?.deviceUpTime) {
      const now = new Date()
      lastBootTime = new Date(now - device.deviceUpTime * 1000);
      lastBootTime = lastBootTime.toDateString() + "\n" + lastBootTime.toTimeString();
    }

    let hostInterface = HOST_INTERFACE_TEXT[modbus_gateway?.mgHostInterface];
    if (hostInterface === undefined) {
      hostInterface = "UNKNOWN";
    }

    const baudRates = [
      1200,
      2400,
      4800,
      9600,
      14400,
      19200,
      38400,
      57600,
      115200,
    ];

    const textOfParityBit = {
      0: 'None',
      1: 'Odd',
      2: 'Even',
    };

    setInnerText(mode__elem, "-");
    setInnerText(SN__elem, "-");
    setInnerText(version__elem, device?.firmwareVersion);
    setInnerText(last_boot_time__elem, lastBootTime);
    setInnerText(Counter__elem, device?.rebootCounter);
    setInnerText(baud_rate__elem, baudRates[rtu?.baudRate]);
    setInnerText(stop__elem, rtu?.stopBit + ' stop bit');
    setInnerText(parity__elem, textOfParityBit[rtu?.parityBit]);
    setInnerText(mgen__elem, modbus_gateway?.mgModeEnable);
    setInnerText(mghostif__elem, hostInterface);
    setInnerText(config_mghostip__elem, "");
    setInnerText(config_mac__elem, network?.LAN?.lanMac);
    setInnerText(config_dhcp__elem, "");
    setInnerText(config_mbap__elem, "");
    setInnerText(config_ip__elem, network?.LAN?.lanIp);
    setInnerText(config_gw__elem, "");
    setInnerText(config_submask__elem, "");
    setInnerText(config_dns1__elem, "");
    setInnerText(config_dns2__elem, "");
    setInnerText(config_webport__elem, "");
    setInnerText(config_tcpport__elem, "");
    setInnerText(config_udpport__elem, "");
  }

  dispose() {
    const { reload } = this.state;
    if (reload) {
      clearInterval(reload);
    }
  }
}