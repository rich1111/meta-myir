/**
 * For module 8
 */
class Ai8CalibrationPage {
  constructor(props) {
    this.state = {
      board: [],
    };
    this.init();
  }

  init = async () => {
    this.initButtons();
    this.loadPage();
    this.init8AiTemp();
  }


  initButtons = () => {
    const offsetBtn = document.getElementById("offset");
    offsetBtn.addEventListener("click", async (e) => {
      e.preventDefault();

      try {
        const res = await Api.setAISystemOffsetCal(null);

        if (res.error?.code == 0) {
          DialogUtility.showSuccess({
            text: "Device has been sucessfully calibrated.",
          });
        } else {
          DialogUtility.showError({
            text: "Calibration error: Voltage input should be 0V.",
          });
        }
        this.loadPage();
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });

    const gainBtn = document.getElementById("gain");
    gainBtn.addEventListener("click", async (e) => {
      e.preventDefault();

      try {
        const res = await Api.setAISystemGainCal(null);
        if (res.error?.code == 0) {
          DialogUtility.showSuccess({
            text: "Device has been sucessfully calibrated.",
          });
        } else {
          DialogUtility.showError({
            text: "Calibration error: Voltage input should be 25V.",
          });
        }
        this.loadPage();
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });

    const internalBtn = document.getElementById("internal");
    internalBtn.addEventListener("click", async (e) => {
      e.preventDefault();

      try {
        const res = await Api.setAIInternalCal(null);

        if (res.error?.code == 0) {
          DialogUtility.showSuccess({
            text: "Device has been sucessfully calibrated.",
          });
        } else {
          DialogUtility.showError({
            text: "Internal Error",
          });
        }
        this.loadPage();
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });

    const tempCalibrateBtn = document.getElementById("tempCalibrate");
    tempCalibrateBtn.addEventListener("click", async (e) => {
      e.preventDefault();

      try {
        const temp = document.getElementById('internalTemp').value;
        // Check if temp is a number, if not, show error
        if (temp == null || temp == "" || isNaN(temp)) {
          DialogUtility.showError({
            text: "Invalid temperature",
          });
          return;
        }
        const tempFloat = parseFloat(temp);
        const json = {
          "aiInternalTemp": tempFloat
        }
        const res = await Api.setAITemp(json);

        if (res.error?.code == 0) {
          DialogUtility.showSuccess({
            text: "Temperature has been sucessfully calibrated.",
          });
        } else {
          DialogUtility.showError({
            text: "Internal Error",
          });
        }
        this.loadPage();
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });

  }


  loadPage = async () => {
    console.log("loadPage...");
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    try {

      // Make sure we're displaying the status display
      mainstat.style.display = 'inline';
      loadstat.style.display = 'none';

      const ai = (await Api.getAIOffsetGain());

      for (let i = 0; i < 8; i++) {
        const aiOffset = document.getElementById('aiOffset_' + i);
        const aiGain = document.getElementById('aiGain_' + i);

        const input = ai.filter((e) => e.aiIndex == i)[0];

        setInnerHTML(aiOffset, input?.aiOffset);
        setInnerHTML(aiGain, input?.aiGain);
      }
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  init8AiTemp = async () => {
    // Call the API to get the temperature
    try {
      const temp = (await Api.getAITemp()).aiInternalTemp;
      const tempElem = document.getElementById('internalTemp');
      setValue(tempElem, temp?.toFixedNoRounding(3));
    } catch (error) {
      console.error(error);
    }

  }

  dispose() {

  }
}
