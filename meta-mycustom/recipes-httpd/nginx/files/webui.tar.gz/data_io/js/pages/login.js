window.onload = () => {
    if (typeof currentPage?.dispose === "function") {
        currentPage.dispose();
    }
    getDeviceName();
    initButtons();
}
getDeviceName = async() => {
    const deviceName = (await Api.iosearch())?.sysInfo?.device?.deviceName;
    console.log("deviceName=", deviceName);
    sessionStorage.setItem("deviceName", deviceName);
    document.getElementById('deviceName').textContent = `Remote I/O - ${deviceName}`;
}

initButtons = () => {
    const login = document.getElementById('login');
    login.addEventListener("click", async (e) => {
        e.preventDefault();
        const customErrorProps = {
            data: {
                error: {
                    message: "",
                }
            }
        };

        try {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            if (username === "") {
                customErrorProps.data.error.message = "Please provide a Username!";
                throw new CustomError(customErrorProps);
            }
            if (password === "") {
                customErrorProps.data.error.message = "Please provide a Password!";
                throw new CustomError(customErrorProps);
            }
            const payload = {
                "username": username,
                "password": password
            }

            const res = await Api.login(payload);
            console.log("res=", res);
            if (res.code === 401) {
                await DialogUtility.showError({
                    title: 'Login Failed', text: res.message
                });
            } else {
                // Login success, save expire & token and redirect page
                sessionStorage.clear();
                sessionStorage.setItem("expire", res.expire);
                sessionStorage.setItem("token", res.token);
                sessionStorage.setItem("last-event", new Date().toISOString());
                sessionStorage.setItem("role", username);
                location.replace("./about");
            }
        } catch (error) {
            console.log(error);
            ErrorUtility.handleError(error);
        }

    });
}