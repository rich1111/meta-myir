
class CloudSettingPage {

    constructor(props) {
        this.state = {
            timer: null,
            rootCaFileName: null,
            certificateFileName: null,
            privateKeyFileName: null,
            enable: false
        };
        this.init();
        setDisableWithRadio();
    }

    init = async() => {
        const sparkplugDiv = document.querySelector('.tab.sparkplug');
        const awsDiv = document.querySelector('.tab.aws');
        const azureDiv = document.querySelector('.tab.azure');

        if (this.state.timer) {
            clearInterval(this.state.timer);
        }

        awsDiv.addEventListener('click', (e) => {
            e.preventDefault();
            this.initAws();
            clearInterval(this.state.timer);
        });

        awsDiv.click();

        azureDiv.addEventListener('click', (e) => {
            e.preventDefault();
            this.initAzure();
            clearInterval(this.state.timer);
        });

        sparkplugDiv.addEventListener('click', (e) => {
            e.preventDefault();
            this.initSparkplug();
            // Set a backend timer to reload connection status
            this.state.timer = setInterval(async () => {
                const config = await Api.getSparkplugConfig();
            }, 5000);
        });
    }

    //sparkplug js
    initSparkplug = async() => {

        const info = await Api.getSysInfo();
        this.setHostName(info.sysInfo.device.hostName);

        const config = await Api.getSparkplugConfig();
        this.setSparkplugConfig(config);

        const plSubmit = document.getElementById("plSubmit");
        if (plSubmit) {
            plSubmit.addEventListener('click', this.sparkplugSubmit);
            setDisableSingleOrButton(plSubmit);
        }

        // const disable = document.getElementById("disable");
        // if (disable) {
        //     disable.addEventListener('click', this.switchEnable);
        // }
        const enable = document.getElementById("enable");
        if (enable) {
            enable.addEventListener('click', this.switchEnable);
        }
        const scada = document.getElementById("scada");
        if (scada) {
            scada.addEventListener('click', this.switchEnable);
        }
    };

    setSparkplugConfig = (config) => {
        const connection = document.getElementById("connectionSkarkplugField");
        setInnerHTML(connection, config.connectedStatus ? 'Connected' : 'Disconnected' );
        const serverUrl = document.getElementById("serverUrl");
        serverUrl.value = config.serverUrl;
        const username = document.getElementById("username");
        username.value = config.username;
        const password = document.getElementById("password");
        password.value = config.password;
        const groupID = document.getElementById("groupID");
        groupID.value = config.groupID;
        const nodeID = document.getElementById("nodeID");
        nodeID.value = config.nodeID;
    
        if (config.enable === 1) {
            document.getElementById("sparkplugEnableCheck").checked = true;
        }
        const hostName = document.getElementById("hostName").innerHTML;
        if(config.username === config.groupID && config.nodeID === hostName) {
            document.getElementById("scada").checked = true;
            this.setSelected("scada");
        } else {
            document.getElementById("enable").checked = true;
            this.setSelected("enable");
        }
    }
    
    sparkplugSubmit = async (e) => {
        e.preventDefault();
        const customErrorProps = {
            data: {
                error: {
                message: "",
                }
            }
        };
    
        try {
            // Get the selected radio button value
            const eds = document.querySelector('input[name="eds"]:checked').value;
            const enable = document.getElementById("sparkplugEnableCheck");
            
            const payload = {
                enable: enable.checked ? 1 : 0,
                serverUrl: "",
                username: "",
                password: "",
                groupID: "",
                nodeID: ""
            };
        
            const serverUrl = document.getElementById("serverUrl").value;
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;
            const groupID = document.getElementById("groupID").value;
            const nodeID = document.getElementById("nodeID").value;
    
            if (eds === "enable") {
                // 1: Enabled; Check allowed values
                if (serverUrl === "") {
                customErrorProps.data.error.message = "Please set a Server URL!";
                throw new CustomError(customErrorProps);
                }
                if (groupID === "") {
                customErrorProps.data.error.message = "Please set a Group ID!";
                throw new CustomError(customErrorProps);
                }
                if (nodeID === "") {
                customErrorProps.data.error.message = "Please set a Node ID!";
                throw new CustomError(customErrorProps);
                }
                payload.groupID = groupID;
                payload.nodeID = nodeID;
            } else if(eds === "scada") {
                // 2: SCADA; Check allowed values
                if (serverUrl === "") {
                customErrorProps.data.error.message = "Please set a Server URL!";
                throw new CustomError(customErrorProps);
                }
                if (username === "") {
                customErrorProps.data.error.message = "Please set a User Name!";
                throw new CustomError(customErrorProps);
                }
                if (password === "") {
                customErrorProps.data.error.message = "Please set a Password!";
                throw new CustomError(customErrorProps);
                }
                payload.groupID = username;
                const hostName = document.getElementById("hostName").innerHTML;
                payload.nodeID = hostName;
            } else {
                payload.groupID = groupID;
                payload.nodeID = nodeID;
            }
            payload.serverUrl = serverUrl;
            payload.username = username;
            payload.password = password;
            const res = Api.setSparkplugConfig(payload);
            DialogUtility.showSuccess({ text: 'success' });
            // DialogUtility.confirm({ text: `System will ${enable.checked === false ? "disable" : "enable"} ${eds === "enable" ? "Private" : "AIoTera"}?` }).then(async (result) => {
            //     if (result.isConfirmed) {
            //     Api.setSparkplugConfig(payload);
            //     DialogUtility.showSuccess({
            //         text: 'success',
            //     });
            //     }
            // });
        } catch (error) {
            ErrorUtility.handleError(error);
        }
    }
    
    switchEnable = async (e) => {
        const select = e.srcElement.defaultValue;
    
        this.setSelected(select);
    }
    
    setHostName = (hostname) => {
        const hostName = document.getElementById("hostName");
        hostName.innerHTML = hostname;
    }
    
    setSelected(select) {
        const conn = document.getElementById("conn");
        const url = document.getElementById("url");
        const user = document.getElementById("user");
        const pass = document.getElementById("pass");
        const group = document.getElementById("group");
        const node = document.getElementById("node");
        // if(select==="disable") {
        //     conn.style.display="none";
        //     url.style.display="none";
        //     user.style.display="none";
        //     pass.style.display="none";
        //     group.style.display="none";
        //     node.style.display="none";
        // } else 
        if(select==="enable") {
            conn.style.display="block";
            url.style.display="block";
            user.style.display="block";
            pass.style.display="block";
            group.style.display="block";
            node.style.display="block";
        } else if(select==="scada") {
            conn.style.display="block";
            url.style.display="block";
            user.style.display="block";
            pass.style.display="block";
            group.style.display="none";
            node.style.display="none";
        }
    }

    //azure js
    initAzure = async() => {
        const azureEnableCheck = document.getElementById('azureEnableCheck');
        const azureHostInput = document.getElementById('azureHostInput');
        const azureSubmitButton = document.getElementById('azureSubmitButton');

        azureSubmitButton.addEventListener('click', this.azureSubmit);
        setDisableSingleOrButton(azureSubmitButton);
        // load data
        const azureIot = (await Api.getAzureConfigs()).sysInfo.azureiot;

        // update page
        const connectionStatusField = document.getElementById('connectionAzureField');
        setInnerHTML(connectionStatusField, azureIot.connectionStatus ? 'Connected' : 'Disconnected' ); // 1 for connected, 0 for disconnected
        setDomProperty(azureEnableCheck, "checked", azureIot.azureiotEnable ? true : false);
        setDomProperty(azureHostInput, "value", azureIot.deviceConnectionString);
    };

    azureSubmit = async(event) => {
        event.preventDefault();
        try {        
            const azureEnableCheck_elem = document.getElementById('azureEnableCheck');
            const azureHostInput_elem = document.getElementById('azureHostInput');
        
            const azureEnableCheck = azureEnableCheck_elem.checked ? 1 : 0;
            const connectionState = 1; // TODO: How to get?
            const azureHostInput = azureHostInput_elem.value;
    
            await Api.editAzureConfigs({
                // below inputs types: number (0 or 1)
                azureiotEnable: azureEnableCheck,
                connectionStatus: connectionState,
                // below inputs types: string
                deviceConnectionString: azureHostInput,
            });
    
            DialogUtility.showSuccess({
                text: 'success',
            });
        } catch (error) {
            ErrorUtility.handleError(error);
        }
    }
  
    //aws js
    initAws = async() => {
        const awsEnableCheck = document.getElementById('awsEnableCheck');
        const awsHostInput = document.getElementById('awsHostInput');
        const awsPortInput = document.getElementById('awsPortInput'); // port 固定為 8883 不需要設定
        const awsTopicInput = document.getElementById('awsTopicInput');
        const awsClientIdInput = document.getElementById('awsClientIdInput');
        const awsMyThingNameInput = document.getElementById('awsMyThingNameInput');
        const awsRootCaFileSelect = document.getElementById('awsRootCaFileSelect');
        const awsCertificateFileSelect = document.getElementById('awsCertificateFileSelect');
        const awsPrivateKeyFileSelect = document.getElementById('awsPrivateKeyFileSelect');
        const awsSubmitButton = document.getElementById('awsSubmitButton');

        const awsRootCaLastFileName = document.getElementById('awsRootCaLastFileName');
        const awsCertificateLastFileName = document.getElementById('awsCertificateLastFileName');
        const awsPrivateKeyLastFileName = document.getElementById('awsPrivateKeyLastFileName');

        awsRootCaFileSelect.onchange = this.uploadRootCaFile;
        awsCertificateFileSelect.onchange = this.uploadCertifiicateFile;
        awsPrivateKeyFileSelect.onchange = this.uploadPrivateKeyFile;

        awsSubmitButton.addEventListener('click', this.awsSubmit);
        setDisableSingleOrButton(awsSubmitButton);

        // load data
        const awsIot = (await Api.getAwsConfigs()).sysInfo.awsiot;

        // update page
        const connectionStatusField = document.getElementById('connectionAWSField');
        setInnerHTML(connectionStatusField, awsIot.connectionStatus ? 'Connected' : 'Disconnected' ); // 1 for connected, 0 for disconnected
        setDomProperty(awsEnableCheck, "checked", awsIot.awsiotEnable ? true : false);
        setDomProperty(awsHostInput, "value", awsIot.targetHost);
        setDomProperty(awsTopicInput, "value", awsIot.topic);
        setDomProperty(awsClientIdInput, "value", awsIot.clientID);
        setDomProperty(awsMyThingNameInput, "value", awsIot.thingName);

        setInnerHTML(awsRootCaLastFileName, `Last upload file name: ${awsIot.rootCAFile}`);
        setInnerHTML(awsCertificateLastFileName, `Last upload file name: ${awsIot.certificateFile}`);
        setInnerHTML(awsPrivateKeyLastFileName, `Last upload file name: ${awsIot.privateKeyFile}`);

        if(awsIot.rootCAFile)       { setStyle(awsRootCaLastFileName, 'display', 'block'); }
        if(awsIot.certificateFile)  { setStyle(awsCertificateLastFileName, 'display', 'block'); }
        if(awsIot.privateKeyFile)   { setStyle(awsPrivateKeyLastFileName, 'display', 'block'); }

        this.state.rootCaFileName = awsIot.rootCAFile;
        this.state.certificateFileName = awsIot.certificateFile;
        this.state.privateKeyFileName = awsIot.privateKeyFile;
    };

    uploadRootCaFile = async() => {
        try {
            const awsRootCaFileSelectSuccessText = document.getElementById('awsRootCaFileSelectSuccessText');
            const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');
        
            setInnerHTML(awsRootCaFileSelectErrorText, "");
            setInnerHTML(awsRootCaFileSelectSuccessText, "");
        
            const awsRootCaFileSelect = document.getElementById('awsRootCaFileSelect');
            const file = awsRootCaFileSelect.files[0];
            const res = await this._uploadFile(file);
            this.state.rootCaFileName = file.name;
        
            setInnerHTML(awsRootCaFileSelectSuccessText, "Upload File Success!");
        } catch(error) {
            const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');
            setInnerHTML(awsRootCaFileSelectErrorText, "Upload File Failed");
        }
    }
    
    uploadCertifiicateFile = async() => {
        try {
    
            const awsCertificateFileSelectSuccessText = document.getElementById('awsCertificateFileSelectSuccessText');
            const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');
        
            setInnerHTML(awsCertificateFileSelectErrorText, "");
            setInnerHTML(awsCertificateFileSelectSuccessText, "");
        
            const awsCertificateFileSelect = document.getElementById('awsCertificateFileSelect');
            const file = awsCertificateFileSelect.files[0];
            const res = await this._uploadFile(file);
            this.state.certificateFileName = file.name;
        
            setInnerHTML(awsCertificateFileSelectSuccessText, "Upload File Success!");
        } catch(error) {
            const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');
            setInnerHTML(awsCertificateFileSelectErrorText, "Upload File Failed");
        }
    }
    
    uploadPrivateKeyFile = async() => {
        try {
            const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
            const awsPrivateKeyFileSelectSuccessText = document.getElementById('awsPrivateKeyFileSelectSuccessText');
            setInnerHTML(awsPrivateKeyFileSelectErrorText, "");
            setInnerHTML(awsPrivateKeyFileSelectSuccessText, "");
        
            const awsPrivateKeyFileSelect = document.getElementById('awsPrivateKeyFileSelect');
            const file = awsPrivateKeyFileSelect.files[0];
            const res = await this._uploadFile(file);
            this.state.privateKeyFileName = file.name;
        
            setInnerHTML(awsPrivateKeyFileSelectSuccessText, "Upload File Success!");
        } catch(error) {
            const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
            setInnerHTML(awsPrivateKeyFileSelectErrorText, "Upload File Failed");
        }
    }
    
    _uploadFile = async(file) => {
        await Api.uploadFile(file, "upload");
    }
    
    awsSubmit = async(event) => {
        event.preventDefault();
        try {
            this.awsClearAllHints();
        
            const {
                rootCaFileName,
                certificateFileName,
                privateKeyFileName,
            } = this.state;
      
            const awsEnableCheck_elem = document.getElementById('awsEnableCheck');
            const awsHostInput_elem = document.getElementById('awsHostInput');
            //const awsPortInput_elem = document.getElementById('awsPortInput');
            const awsTopicInput_elem = document.getElementById('awsTopicInput');
            const awsClientIdInput_elem = document.getElementById('awsClientIdInput');
            const awsMyThingNameInput_elem = document.getElementById('awsMyThingNameInput');
            const awsRootCaFileSelect_elem = document.getElementById('awsRootCaFileSelect');
            const awsCertificateFileSelect_elem = document.getElementById('awsCertificateFileSelect');
            const awsPrivateKeyFileSelect_elem = document.getElementById('awsPrivateKeyFileSelect');
        
            const awsEnableCheck = awsEnableCheck_elem.checked ? 1 : 0;
            const connectionState = 1; // TODO: How to get?
            const awsHostInput = awsHostInput_elem.value;
            //const awsPortInput = awsPortInput_elem.value;
            const awsTopicInput = awsTopicInput_elem.value;
            const awsClientIdInput = awsClientIdInput_elem.value;
            const awsMyThingNameInput = awsMyThingNameInput_elem.value;
      
            await Api.editAwsConfigs({
                // below inputs types: number (0 or 1)
                awsiotEnable: awsEnableCheck,
                connectionStatus: connectionState,
                // below inputs types: string
                targetHost: awsHostInput,
                topic: awsTopicInput,
                clientID: awsClientIdInput,
                thingName: awsMyThingNameInput,
                rootCAFile: rootCaFileName,
                certificateFile: certificateFileName,
                privateKeyFile: privateKeyFileName,
            });
    
            DialogUtility.showSuccess({
                text: 'success',
            });
        } catch (error) {
            ErrorUtility.handleError(error);
        }
    }
    
    awsClearAllHints = () => {
        const awsRootCaFileSelectSuccessText = document.getElementById('awsRootCaFileSelectSuccessText');
        setInnerHTML(awsRootCaFileSelectSuccessText, "");
        const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');
        setInnerHTML(awsRootCaFileSelectErrorText, "");
    
        const awsCertificateFileSelectSuccessText = document.getElementById('awsCertificateFileSelectSuccessText');
        setInnerHTML(awsCertificateFileSelectSuccessText, "");
        const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');
        setInnerHTML(awsCertificateFileSelectErrorText, "");
        
        const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
        setInnerHTML(awsPrivateKeyFileSelectErrorText, "");
        const awsPrivateKeyFileSelectSuccessText = document.getElementById('awsPrivateKeyFileSelectSuccessText');
        setInnerHTML(awsPrivateKeyFileSelectSuccessText, "");
    }
    
    dispose() {
        this.awsClearAllHints();
        clearInterval(this.state.timer);
        const sparkplugDiv = document.querySelector('.tab.sparkplug');
        sparkplugDiv.removeEventListener('click', this.initSparkplug);
    }
}
