class DoPulsePage {
  constructor(props) {
    this.loadPage();
    this.initButtons();
  }

  doCount = 0;

  loadPage = async () => {
    try {
      var mainstat = document.getElementById('display');
      var loadstat = document.getElementById('loading');

      // Make sure we're displaying the status display
      if (mainstat != null && loadstat != null) {
        mainstat.style.display = 'inline';
        loadstat.style.display = 'none';
      }

      switch (currentModuleType) {
        case MODULE_TYPE_CODE.MOD016:
          // 8DI8DO
          this.doCount = 8;
          break;
        case MODULE_TYPE_CODE.MOD016P:
          // 8DI6DO2PWM
          this.doCount = 6;
          break;
        case MODULE_TYPE_CODE.MOD216:
          // 16DO
          this.doCount = 16;
          break;
      }
      this.hideUnusedDOs(this.doCount);

      const dos = (await Api.getDigitalOutput()).io.do;

      dos.forEach((po) => {
        var index = po.doIndex;


        const doPulseStatus = document.getElementById('doPulseStatus_' + index);
        const doPulseCount = document.getElementById('doPulseCount_' + index);
        const doPulseOnWidth = document.getElementById('doPulseOnWidth_' + index);
        const doPulseOffWidth = document.getElementById('doPulseOffWidth_' + index);

        setDomProperty(doPulseStatus, "checked", po?.doPulseStatus);
        setDomProperty(doPulseCount, "value", po?.doPulseCount);
        setDomProperty(doPulseOnWidth, "value", po?.doPulseOnWidth);
        setDomProperty(doPulseOffWidth, "value", po?.doPulseOffWidth);

      });

    } catch (error) {
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  hideUnusedDOs = (toHide) => {
    for (let i = toHide; i < 16; i++) {
      document.getElementById('row_' + i).style.display = "none";
    }
  }

  initButtons = () => {
    save.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };
      const payload = {
        io: {
          do: [
            // {
            //   "doIndex": 0,
            //   "doMode": 0,					      // 0: normal, 1: pulse mode
            //   "doPulseCount": 1,          // >= 0 times (0 = loop indefinately)
            //   "doPulseOnWidth": 100,			// int, > 0 ms, pulse on width 
            //   "doPulseOffWidth": 100,			// int, > 0 ms, pulse off width
            //   "doPulseStatus": 1,				  // 0: disable, 1: enable
            // }
          ]
        },
        slot: 0
      }

      try {
        for (let i = 0; i < this.doCount; i++) {
          const doPulseStatus = document.getElementById('doPulseStatus_' + i).checked ? 1 : 0;
          const doPulseCount = parseInt(document.getElementById('doPulseCount_' + i).value);
          const doPulseOnWidth = parseInt(document.getElementById('doPulseOnWidth_' + i).value);
          const doPulseOffWidth = parseInt(document.getElementById('doPulseOffWidth_' + i).value);
          // Check allowed values
          if (doPulseCount < 0) {
            customErrorProps.data.error.message = "Pulse Count cannot be a negative number!";
            throw new CustomError(customErrorProps);
          }
          if (doPulseOnWidth < 1) {
            customErrorProps.data.error.message = "Pulse-On Width should be 1 or above!";
            throw new CustomError(customErrorProps);
          }
          if (doPulseOffWidth < 1) {
            customErrorProps.data.error.message = "Pulse-Off Width should be 1 or above!";
            throw new CustomError(customErrorProps);
          }
          let doMode = 0;
          if (doPulseStatus === 1) doMode = 1;

          let entry = {
            "doIndex": i,
            "doMode": doMode,
            "doPulseCount": doPulseCount,
            "doPulseOnWidth": doPulseOnWidth,
            "setDomPropertydoPulseOffWidth": doPulseOffWidth,
            "doPulseStatus": doPulseStatus,
          }
          payload.io.do[i] = entry;
        }

        const res = await Api.editDigitalOutput(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

}