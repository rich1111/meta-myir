class RuleEnginePage {
    constructor() {
        this.init();
    }

    init() {
        console.log('RuleEnginePage');
    }
    
}