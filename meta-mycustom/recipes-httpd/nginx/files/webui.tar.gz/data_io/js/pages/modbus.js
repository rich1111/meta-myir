class ModbusPage {
  constructor(props) {
    this.state = {
      modType: ""
    };
    this.init();
  }

  init = () => {
    switch (currentModuleType) {
      case MODULE_TYPE_CODE.MOD008:
        this.state.modType = "4AI4AO";
        break;
      case MODULE_TYPE_CODE.MOD108:
        this.state.modType = "8AI";
        break;
      case MODULE_TYPE_CODE.MOD012:
        this.state.modType = "8DI4RELAY";
        break;
      case MODULE_TYPE_CODE.MOD016:
        this.state.modType = "8DI8DO";
        break;
      case MODULE_TYPE_CODE.MOD016P:
        this.state.modType = "8DI6DO2PWM";
        break;
      case MODULE_TYPE_CODE.MOD116:
        this.state.modType = "16DI";
        break;
      case MODULE_TYPE_CODE.MOD216:
        this.state.modType = "16DO";
        break;
    }
    // this.state.modType = "16DO"; // for testing

    this.initButtons();
    this.loadPage();
  }

  initButtons = () => {
    save.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const tcpPort = parseInt(document.getElementById('tcpPort').value);
        const slaveID = parseInt(document.getElementById('slaveID').value);

        // Check allowed values
        if (tcpPort < 0 || tcpPort > 65535) {
          customErrorProps.data.error.message = "TCP port must be between 0 and 65535";
          throw new CustomError(customErrorProps);
        }
        if (slaveID < 1 || slaveID > 247) {
          customErrorProps.data.error.message = "Slave ID must be between 1 and 247";
          throw new CustomError(customErrorProps);
        }
        const payload = {
          tcpPort: tcpPort,
          slaveID: slaveID,

          diCounterEnableBase: 256,
          diCounterResetBase: 264,
          diInputBase: 256,
          diCounterOverflowBase: 264,
          diCounterValueBase: 256,

          doOutputBase: 272,
          doDefaultEnableBase: 280,
          doDefaultValueBase: 288,

          aiInputRawBase: 0,
          aiInputEngBase: 0,

          aoDefaultEnableBase: 0,
          aoOutputRawBase: 0,
          aoDefaultOutputRawBase: 0,
          aoOutputEngBase: 0,
          aoDefaultOutputEngBase: 0
        }

        // Determine the type of device
        if (this.state.modType === "8DI4RELAY") {
          this.setParams_DI(customErrorProps, payload);
          this.setParams_DO(customErrorProps, payload);
        } else if (this.state.modType === "8DI8DO" || this.state.modType === "8DI6DO2PWM") {
          this.setParams_DI(customErrorProps, payload);
          this.setParams_DO(customErrorProps, payload);
        } else if (this.state.modType === "16DI") {
          this.setParams_DI(customErrorProps, payload);
        } else if (this.state.modType === "16DO") {
          this.setParams_DO(customErrorProps, payload);
        } else if (this.state.modType === "4AI4AO") {
          this.setParams_AI(customErrorProps, payload);
          this.setParams_AO(customErrorProps, payload);
        } else if (this.state.modType === "8AI") {
          this.setParams_AI(customErrorProps, payload);
        }

        const res = await Api.editModbusAddressAgent(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

  loadPage = async () => {
    try {
      const settings = await Api.getModbusAddressAgent();
      const tcpPort = document.getElementById('tcpPort');
      const slaveID = document.getElementById('slaveID');

      setDomProperty(tcpPort, "value", settings?.tcpPort);
      setDomProperty(slaveID, "value", settings?.slaveID);

      // Determine the type of device
      if (this.state.modType === "8DI4RELAY") {
        document.getElementById("di").style.display = "block";
        document.getElementById("do").style.display = "block";
        this.loadPage_DI(settings);
        this.loadPage_DO(settings);
      } else if (this.state.modType === "8DI8DO" || this.state.modType === "8DI6DO2PWM") {
        document.getElementById("di").style.display = "block";
        document.getElementById("do").style.display = "block";
        this.loadPage_DI(settings);
        this.loadPage_DO(settings);
      } else if (this.state.modType === "16DI") {
        document.getElementById("di").style.display = "block";
        this.loadPage_DI(settings);
      } else if (this.state.modType === "16DO") {
        document.getElementById("do").style.display = "block";
        this.loadPage_DO(settings);
      } else if (this.state.modType === "4AI4AO") {
        document.getElementById("ai").style.display = "block";
        document.getElementById("ao").style.display = "block";
        this.loadPage_AI(settings);
        this.loadPage_AO(settings);
      } else if (this.state.modType === "8AI") {
        document.getElementById("ai").style.display = "block";
        this.loadPage_AI(settings);
      }
    } catch (error) {
      console.error(error);
    }
  }

  // **********************************************************************************************
  // **************************************** DI ************************************************
  // **********************************************************************************************
  setParams_DI(customErrorProps, payload) {
    const diCounterEnableBase = parseInt(document.getElementById('diCounterEnableBase').value);
    const diCounterResetBase = parseInt(document.getElementById('diCounterResetBase').value);
    const diInputBase = parseInt(document.getElementById('diInputBase').value);
    const diCounterOverflowBase = parseInt(document.getElementById('diCounterOverflowBase').value);
    const diCounterValueBase = parseInt(document.getElementById('diCounterValueBase').value);

    // Check allowed values
    if (diCounterEnableBase < 0 || diCounterEnableBase > 65520) {
      customErrorProps.data.error.message = "DI CounterEnableBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (diCounterResetBase < 0 || diCounterResetBase > 65520) {
      customErrorProps.data.error.message = "DI CounterResetBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (diInputBase < 0 || diInputBase > 65520) {
      customErrorProps.data.error.message = "DI InputBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (diCounterOverflowBase < 0 || diCounterOverflowBase > 65520) {
      customErrorProps.data.error.message = "DI CounterOverflowBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (diCounterValueBase < 0 || diCounterValueBase > 65504) {
      customErrorProps.data.error.message = "DI CounterValueBase must be between 0 and 65504";
      throw new CustomError(customErrorProps);
    }

    // Set values
    payload.diCounterEnableBase = diCounterEnableBase;
    payload.diCounterResetBase = diCounterResetBase;
    payload.diInputBase = diInputBase;
    payload.diCounterOverflowBase = diCounterOverflowBase;
    payload.diCounterValueBase = diCounterValueBase;
  }
  //*****************************************************************************************
  loadPage_DI(settings) {
    const diCounterEnableBase = document.getElementById('diCounterEnableBase');
    const diCounterResetBase = document.getElementById('diCounterResetBase');
    const diInputBase = document.getElementById('diInputBase');
    const diCounterOverflowBase = document.getElementById('diCounterOverflowBase');
    const diCounterValueBase = document.getElementById('diCounterValueBase');

    setDomProperty(diCounterEnableBase, "value", settings?.diCounterEnableBase);
    setDomProperty(diCounterResetBase, "value", settings?.diCounterResetBase);
    setDomProperty(diInputBase, "value", settings?.diInputBase);
    setDomProperty(diCounterOverflowBase, "value", settings?.diCounterOverflowBase);
    setDomProperty(diCounterValueBase, "value", settings?.diCounterValueBase);
  }

  // **********************************************************************************************
  // **************************************** DO ************************************************
  // **********************************************************************************************
  setParams_DO(customErrorProps, payload) {
    const doOutputBase = parseInt(document.getElementById('doOutputBase').value);
    const doDefaultEnableBase = parseInt(document.getElementById('doDefaultEnableBase').value);
    const doDefaultValueBase = parseInt(document.getElementById('doDefaultValueBase').value);

    // Check allowed values
    if (doOutputBase < 0 || doOutputBase > 65520) {
      customErrorProps.data.error.message = "DO OutputBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (doDefaultEnableBase < 0 || doDefaultEnableBase > 65520) {
      customErrorProps.data.error.message = "DO DefaultEnableBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (doDefaultValueBase < 0 || doDefaultValueBase > 65520) {
      customErrorProps.data.error.message = "DO DefaultValueBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }

    // Set values
    payload.doOutputBase = doOutputBase;
    payload.doDefaultEnableBase = doDefaultEnableBase;
    payload.doDefaultValueBase = doDefaultValueBase;
  }
  //*****************************************************************************************
  loadPage_DO(settings) {
    const doOutputBase = document.getElementById('doOutputBase');
    const doDefaultEnableBase = document.getElementById('doDefaultEnableBase');
    const doDefaultValueBase = document.getElementById('doDefaultValueBase');

    setDomProperty(doOutputBase, "value", settings?.doOutputBase);
    setDomProperty(doDefaultEnableBase, "value", settings?.doDefaultEnableBase);
    setDomProperty(doDefaultValueBase, "value", settings?.doDefaultValueBase);
  }

  // **********************************************************************************************
  // ******************************************** AI **********************************************
  // **********************************************************************************************
  setParams_AI(customErrorProps, payload) {
    const aiInputRawBase = parseInt(document.getElementById('aiInputRawBase').value);
    const aiInputEngBase = parseInt(document.getElementById('aiInputEngBase').value);

    // Check allowed values
    if (aiInputRawBase < 0 || aiInputRawBase > 65520) {
      customErrorProps.data.error.message = "AI InputRawBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aiInputEngBase < 0 || aiInputEngBase > 65520) {
      customErrorProps.data.error.message = "AI InputEngBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }

    // Set values
    payload.aiInputRawBase = aiInputRawBase;
    payload.aiInputEngBase = aiInputEngBase;
  }
  //*****************************************************************************************
  loadPage_AI(settings) {
    const aiInputRawBase = document.getElementById('aiInputRawBase');
    const aiInputEngBase = document.getElementById('aiInputEngBase');

    setDomProperty(aiInputRawBase, "value", settings?.aiInputRawBase);
    setDomProperty(aiInputEngBase, "value", settings?.aiInputEngBase);
  }

  // **********************************************************************************************
  // ******************************************** AO **********************************************
  // **********************************************************************************************
  setParams_AO(customErrorProps, payload) {
    const aoDefaultEnableBase = parseInt(document.getElementById('aoDefaultEnableBase').value);
    const aoOutputRawBase = parseInt(document.getElementById('aoOutputRawBase').value);
    const aoDefaultOutputRawBase = parseInt(document.getElementById('aoDefaultOutputRawBase').value);
    const aoOutputEngBase = parseInt(document.getElementById('aoOutputEngBase').value);
    const aoDefaultOutputEngBase = parseInt(document.getElementById('aoDefaultOutputEngBase').value);

    // Check allowed values
    if (aoDefaultEnableBase < 0 || aoDefaultEnableBase > 65520) {
      customErrorProps.data.error.message = "AO DefaultEnableBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aoOutputRawBase < 0 || aoOutputRawBase > 65520) {
      customErrorProps.data.error.message = "AO OutputRawBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aoDefaultOutputRawBase < 0 || aoDefaultOutputRawBase > 65520) {
      customErrorProps.data.error.message = "AO DefaultOutputRawBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aoOutputEngBase < 0 || aoOutputEngBase > 65520) {
      customErrorProps.data.error.message = "AO OutputEngBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aoDefaultOutputEngBase < 0 || aoDefaultOutputEngBase > 65520) {
      customErrorProps.data.error.message = "AO DefaultOutputEngBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }

    // Set values
    payload.aoDefaultEnableBase = aoDefaultEnableBase;
    payload.aoOutputRawBase = aoOutputRawBase;
    payload.aoDefaultOutputRawBase = aoDefaultOutputRawBase;
    payload.aoOutputEngBase = aoOutputEngBase;
    payload.aoDefaultOutputEngBase = aoDefaultOutputEngBase;
  }
  //*****************************************************************************************
  loadPage_AO(settings) {
    const aoDefaultEnableBase = document.getElementById('aoDefaultEnableBase');
    const aoOutputRawBase = document.getElementById('aoOutputRawBase');
    const aoDefaultOutputRawBase = document.getElementById('aoDefaultOutputRawBase');
    const aoOutputEngBase = document.getElementById('aoOutputEngBase');
    const aoDefaultOutputEngBase = document.getElementById('aoDefaultOutputEngBase');

    setDomProperty(aoDefaultEnableBase, "value", settings?.aoDefaultEnableBase);
    setDomProperty(aoOutputRawBase, "value", settings?.aoOutputRawBase);
    setDomProperty(aoDefaultOutputRawBase, "value", settings?.aoDefaultOutputRawBase);
    setDomProperty(aoOutputEngBase, "value", settings?.aoOutputEngBase);
    setDomProperty(aoDefaultOutputEngBase, "value", settings?.aoDefaultOutputEngBase);
  }

  dispose() {

  }
}