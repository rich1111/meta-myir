/**
 * For module 8
 */
class AnalogPage {
  constructor(props) {
    this.state = {
      refereshTime: 1000,
      intervalId: undefined,
      board: [],
    };
    if (currentModuleType != MODULE_TYPE_CODE.MOD008) {
      return;
    }
    this.init();
  }

  init = async () => {
    this.initIntervalSelect();
    this.initButtons();
    this.loadPage();
  }

  initIntervalSelect = () => {
    const refreshSelect = document.getElementById("refresh");
    const {
      refereshTime,
    } = this.state;

    refreshSelect.addEventListener('click', this.onRefreshClick);
  }

  initButtons = () => {
    const saveButton = document.getElementById("AOSave");
    saveButton.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const payload = {
          "io": {
            "ao": [
              {
                "aoIndex": 0,
                "aoValueScaled": 2,
                "aoDefaultEnable": 0,
                "aoDefaultValueScaled": 200
              },
            ]
          },
          "slot": 0
        };

        for (let i = 0; i < 4; i++) {
          const AO0_elem = document.getElementById("AO" + i);
          const DAO_EN0_elem = document.getElementById("DAO_EN" + i);
          const DAO_VAL0_elem = document.getElementById("DAO_VAL" + i);

          if (
            AO0_elem == null ||
            DAO_EN0_elem == null ||
            DAO_VAL0_elem == null
          ) {
            continue;
          }

          const AO0_value = parseFloat(AO0_elem.value);
          const DAO_EN0_value = DAO_EN0_elem.checked ? 1 : 0;
          const DAO_VAL0_value = parseFloat(DAO_VAL0_elem.value);

          if (
            isNaN(AO0_value) ||
            isNaN(DAO_VAL0_value)
          ) {
            customErrorProps.data.error.message = "Please enter number";
            throw new CustomError(customErrorProps);
          }

          if (i < 2 && (AO0_value < 0 || AO0_value > 10)) {
            // 電壓
            customErrorProps.data.error.message = "Voltage must between 0 and 10";
            throw new CustomError(customErrorProps);
          } else if ((i > 1 && i < 4) && (AO0_value < 0 || AO0_value > 20)) {
            // 電流
            customErrorProps.data.error.message = "Current must between 0 and 10";
            throw new CustomError(customErrorProps);
          }

          payload.io.ao[i] = {
            "aoIndex": i,
            "aoValueScaled": AO0_value,
            "aoDefaultEnable": DAO_EN0_value,
            "aoDefaultValueScaled": DAO_VAL0_value,
          };
        }
        const res = await Api.editAnalogOutput(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

  onRefreshClick = (e) => {
    e.preventDefault();
    this.loadPage();
  }

  loadPage = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    try {
      const analogInputs = (await Api.getAnalogInput()).io.ai;
      const analogOutputs = (await Api.getAnalogOutput()).io.ao;

      if (mainstat == null || loadstat == null || !(currentPage instanceof AnalogPage)) {
        return;
      }

      // Make sure we're displaying the status display
      mainstat.style.display = 'inline';
      loadstat.style.display = 'none';

      for (let i = 0; i < 4; i++) {
        const DAO_EN_elem = document.getElementById('DAO_EN' + i);
        const AO_elem = document.getElementById('AO' + i);
        const DAO_VAL_elem = document.getElementById('DAO_VAL' + i);
        const AI_elem = document.getElementById('AI' + i);
        const AIMA_elem = document.getElementById('AIMA' + i);
        const hAO_elem = document.getElementById('hAO' + i);
        const hDV_elem = document.getElementById('hDV' + i);
        const hAI_elem = document.getElementById('hAI' + i);

        const input = analogInputs.filter((e) => e.aiIndex == i)[0];
        const output = analogOutputs.filter((e) => e.aoIndex == i)[0];

        if (output?.aoDefaultEnable == 1) {
          setDomProperty(DAO_EN_elem, "checked", true);
        } else {
          setDomProperty(DAO_EN_elem, "checked", false);
        }

        setDomProperty(AO_elem, "value", output?.aoValueScaled);
        setDomProperty(DAO_VAL_elem, "value", output?.aoDefaultValueScaled);
        setDomProperty(AI_elem, "innerHTML", input?.aiValueScaled?.toFixed(3));
        setDomProperty(AIMA_elem, "innerHTML", input?.aiMode == 2 ? 'mA' : 'V');
        setDomProperty(hAO_elem, "innerHTML", '#' + output?.aoValueRaw?.toString(16));
        setDomProperty(hDV_elem, "innerHTML", output?.aoDefaultValueScaled);
        setDomProperty(hAI_elem, "innerHTML", '#' + input?.aiValueRaw?.toString(16));

        const lastUpdateTimeElem = document.getElementById("lastUpdateTime");
        const now = (new Date()).toUTCString();
        setInnerText(lastUpdateTimeElem, now);
      }
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  dispose() {
    if (currentModuleType != MODULE_TYPE_CODE.MOD008) {
      return;
    }
    const refreshSelect = document.getElementById("refresh");
    refreshSelect.removeEventListener('click', this.onRefreshClick);
  }
}
