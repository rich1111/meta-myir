/**
 * For module 12, 16, 116
 */
class GatewayPage {
  constructor(props) {
    this.state = {
      modType: ""
    };
    this.init();
  }

  init = () => {

    this.initButtons();
    this.loadPage();
  }

  initButtons = () => {
    save.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const enableOPCUA = document.getElementById('enableOPCUA').checked ? 1 : 0;
        const enableNodeRed = document.getElementById('enableNodeRed').checked ? 1 : 0;
        const publishOnChange = document.getElementById('publishOnChange').checked ? 1 : 0;
        const mqttServerIP_1 = document.getElementById('mqttServerIP_1').value;
        const mqttPort_1 = parseInt(document.getElementById('mqttPort_1').value);
        const heartBeatInterval = parseInt(document.getElementById('heartBeatInterval').value);
        const payload = {
          mqttServerIP_1: mqttServerIP_1,
          mqttPort_1: mqttPort_1,
          enableOPCUA: enableOPCUA,
          enableNodeRed: enableNodeRed,
          publishOnChange: publishOnChange,
          heartBeatInterval: heartBeatInterval
        }

        const res = await Api.editMqttAgent(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

  loadPage = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    try {
      const settings = await Api.getMqttAgent();
      const mqttServerIP_1 = document.getElementById('mqttServerIP_1');
      const mqttPort_1 = document.getElementById('mqttPort_1');
      const enableOPCUA = document.getElementById('enableOPCUA');
      const enableNodeRed = document.getElementById('enableNodeRed');
      const publishOnChange = document.getElementById('publishOnChange');
      const heartBeatInterval = document.getElementById('heartBeatInterval');

      setDomProperty(mqttServerIP_1, "value", settings?.mqttServerIP_1);
      setDomProperty(mqttPort_1, "value", settings?.mqttPort_1);
      setDomProperty(enableOPCUA, "checked", settings?.enableOPCUA === 1 ? true : false);
      setDomProperty(enableNodeRed, "checked", settings?.enableNodeRed === 1 ? true : false);
      setDomProperty(publishOnChange, "checked", settings?.publishOnChange === 1 ? true : false);
      setDomProperty(heartBeatInterval, "value", settings?.heartBeatInterval);

      // Make sure we're displaying the status display
      mainstat.style.display = 'inline';

    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  dispose() {

  }
}
