/**
 * For all modules
 */
class RebootPage {
  constructor(props) {
  }

  dispose() {
  }
}