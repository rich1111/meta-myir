/**
 * For all modules
 */
class ReportPage {
  constructor(props) {
  }

  dispose() {
  }
}