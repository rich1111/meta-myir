/**
 * For module 16, 116, 216
 */
class DigitalPage {
  constructor(props) {
    this.state = {
      refereshTime: 1000,
      intervalId: undefined,
      board: [],

      initButtons: () => { },
    };

    this.init();
  }

  init = async () => {
    switch (currentModuleType) {
      case MODULE_TYPE_CODE.MOD008:
      case MODULE_TYPE_CODE.MOD012:
        return;
      case MODULE_TYPE_CODE.MOD116:
        break;
      case MODULE_TYPE_CODE.MOD016:
      case MODULE_TYPE_CODE.MOD016P:
      case MODULE_TYPE_CODE.MOD216:
        this.state.initButtons = this.initButtons;
        break;
    }

    const { initButtons, refereshTime } = this.state;
    initButtons();
    this.loadPage();

    this.state.intervalId = setInterval(
      this.loadPage, refereshTime
    );

    this.initIntervalSelect();
  }

  onRefreshTimeChange = (e) => {
    try {
      const value = parseInt(e.target.value);
      if (isNaN(value)) {
        throw Error();
      }

      this.state.refereshTime = value;

      const { intervalId } = this.state;
      if (intervalId) {
        clearInterval(intervalId);
      }

      this.state.intervalId = setInterval(
        this.loadPage,
        this.state.refereshTime
      );
    } catch (error) {
      console.error(error);
      DialogUtility.showError({
        title: "Change Time Error",
        text: "Changing freshing time failed, please retry",
      });
    }
  }

  initIntervalSelect = () => {
    const refreshSelect = document.getElementById("refresh");
    const {
      refereshTime,
    } = this.state;

    if (refreshSelect) {
      refreshSelect.value = refereshTime;
      refreshSelect.addEventListener('change', this.onRefreshTimeChange);
    }
  }

  /**
   * For module 16, 216
   */
  initButtons = () => {
    for (let i = 0; i < 16; i++) {
      const DO_button = document.getElementById(`DO${i}`);
      const DDO_EN_button = document.getElementById(`DDO_EN${i}`);
      const DDO_VAL_button = document.getElementById(`DDO_VAL${i}`);

      if (
        DO_button == null ||
        DDO_EN_button == null ||
        DDO_VAL_button == null
      ) {
        return;
      }

      DO_button.addEventListener('click',
        () => this.sendEditApi(i, "doStatus"),
      );

      DDO_EN_button.addEventListener('click',
        () => this.sendEditApi(i, "doDefaultEnable"),
      );

      DDO_VAL_button.addEventListener('click',
        () => this.sendEditApi(i, "doDefaultValue"),
      );
    }
  }

  /**
   * For module 16, 216
   */
  sendEditApi = (i, editFieldName) => {
    const payload = this.getEdittingDigitalOutputPayload(i);
    if (typeof payload[editFieldName] === "number") {
      payload[editFieldName] = 1 - payload[editFieldName];
      Api.editDigitalOutputByPort(payload);
    }
    console.log(payload);
  }

  /**
   * For module mode 16, 216
   * @param {*} index 
   */
  getEdittingDigitalOutputPayload = (index) => {
    const { board } = this.state
    const output = board[index]?.output;
    return {
      port: index,
      doStatus: output?.doStatus,
      doDefaultEnable: output?.doDefaultEnable,
      doDefaultValue: output?.doDefaultValue,
    };
  }

  /**
   * For module 16, 216
   */
  renderDIOStatusBoardCell = ({ name, index, value }) => {
    const id = name + index;
    const cell = document.getElementById(id);
    
    const flag = 0 < value;

    if (cell == null) {
      return;
    }

    cell.innerHTML = flag ? "ON" : "OFF";
    cell.style.color = flag ? "#00FF00" : "#000000";
  }

  loadPage = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    if (mainstat == null || loadstat == null) {
      return;
    }

    // Make sure we're displaying the status display
    mainstat.style.display = 'inline';
    loadstat.style.display = 'none';

    try {
      const digitalInputs = (await Api.getDigitalInput()).io.di;

      const digitalOutpus = (await Api.getDigitalOutput()).io.do;

      if (!(currentPage instanceof DigitalPage)) {
        return;
      }

      const { board } = this.state;

      digitalInputs.forEach((input) => {
        const { diIndex } = input;
        if (board[diIndex] === undefined) {
          board[diIndex] = {};
        }
        board[diIndex].input = input;
      });

      digitalOutpus.forEach((output) => {
        const { doIndex } = output;
        if (board[doIndex] === undefined) {
          board[doIndex] = {};
        }
        board[doIndex].output = output;
      });

      if (currentModuleType === MODULE_TYPE_CODE.MOD116) {
        this.MOD116_render(board);
      } else {
        this.render(board);
      }

      if (currentModuleType === MODULE_TYPE_CODE.MOD016P) {
        this.hideUnusedDOs();
      }

      const lastUpdateTimeElem = document.getElementById("lastUpdateTime");
      const now = (new Date()).toUTCString();
      setInnerText(lastUpdateTimeElem, now);

    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  /**
   * For module 16, 216
   * @param {*} board 
   */
  render = (board) => {
    board.forEach((item, index) => {
      const { input, output } = item;
      let channel = output?.doIndex;
      if (channel === undefined) {
        channel = input?.diIndex;
      }

      const cells = [
        {
          name: "DO",
          value: output?.doStatus,
        },
        {
          name: "DDO_EN",
          value: output?.doDefaultEnable,
        },
        {
          name: "DDO_VAL",
          value: output?.doDefaultValue,
        },
      ];

      if ((currentModuleType === MODULE_TYPE_CODE.MOD016) || (currentModuleType === MODULE_TYPE_CODE.MOD016P)) {
        cells.push({
          name: "DI",
          value: input?.diStatus
        });
      }

      cells.forEach((cell) => {
        if ((currentModuleType === MODULE_TYPE_CODE.MOD016 || currentModuleType === MODULE_TYPE_CODE.MOD016P) && cell.name === "DI") {
          const cellElem = document.getElementById(cell.name + channel);
          const flag = 0 < cell.value;
          setCircle(cellElem, flag);
        } else if (currentModuleType === MODULE_TYPE_CODE.MOD216 && cell.name === "DDO_EN") {
          const cellElem = document.getElementById(cell.name + channel);
          const flag = 0 < cell.value;

          if (cellElem != null) {
            cellElem.innerHTML = flag ? "Enable" : "Disable";
            cellElem.style.color = flag ? "#00FF00" : "#000000";
          }
        } else {
          this.renderDIOStatusBoardCell({
            index: channel,
            name: cell.name,
            value: cell.value,
          });
        }
      })
    });
  }

  hideUnusedDOs = () => {
    document.getElementById('doCh').innerHTML = "Digital Output Channels: 6";
    document.getElementById('DO6').style.display = "none";
    document.getElementById('DDO_EN6').style.display = "none";
    document.getElementById('DDO_VAL6').style.display = "none";
    document.getElementById('DO7').style.display = "none";
    document.getElementById('DDO_EN7').style.display = "none";
    document.getElementById('DDO_VAL7').style.display = "none";
  }

  MOD116_render = (board) => {
    board.forEach((item, index) => {
      const { input } = item;
      const channel = input?.diIndex;

      const cellElem = document.getElementById("DI" + channel);
      const flag = 0 < input.diStatus;

      setCircle(cellElem, flag);
    });
  }

  dispose() {
    const { intervalId } = this.state;
    if (intervalId) {
      clearInterval(intervalId);
    }
  }
}