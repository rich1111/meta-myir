/**
 * For All Modules
 */
class AzurePage {
  constructor(props) {
    this.init();
  }

  init = async() => {
    const azureEnableCheck = document.getElementById('azureEnableCheck');
    const azureHostInput = document.getElementById('azureHostInput');
    const azureSubmitButton = document.getElementById('azureSubmitButton');

    azureSubmitButton.addEventListener('click', this.submit);

    // load data
    const azureIot = (await Api.getAzureConfigs()).sysInfo.azureiot;

    // update page
    const connectionStatusField = document.getElementById('connectionStatusField');
    setInnerHTML(connectionStatusField, azureIot.connectionStatus ? 'Connected' : 'Disconnected' ); // 1 for connected, 0 for disconnected
    setDomProperty(azureEnableCheck, "checked", azureIot.azureiotEnable ? true : false);
    setDomProperty(azureHostInput, "value", azureIot.deviceConnectionString);
  }

  submit = async(event) => {
    event.preventDefault();
    try {
      this.clearAllHints();

      const azureEnableCheck_elem = document.getElementById('azureEnableCheck');
      const azureHostInput_elem = document.getElementById('azureHostInput');

      const azureEnableCheck = azureEnableCheck_elem.checked ? 1 : 0;
      const connectionState = 1; // TODO: How to get?
      const azureHostInput = azureHostInput_elem.value;

      await Api.editAzureConfigs({
        // below inputs types: number (0 or 1)
        azureiotEnable: azureEnableCheck,
        connectionStatus: connectionState,
        // below inputs types: string
        deviceConnectionString: azureHostInput,
      });

      DialogUtility.showSuccess({
        text: 'success',
      });
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  clearAllHints = () => {
  }

  dispose() {
    this.clearAllHints();
    console.log(this);

    const azureSubmitButton = document.getElementById('azureSubmitButton');
    azureSubmitButton.addEventListener('click', this.submit);
  }
}