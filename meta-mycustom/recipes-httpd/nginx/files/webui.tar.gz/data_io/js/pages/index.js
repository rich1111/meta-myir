window.onload = () => {
  if (typeof currentPage?.dispose === "function") {
    currentPage.dispose();
  }
  init();
}

let navModuleItem;
let navSelectModuleTypeDropdown;
let navSelectModuleTypeDropdown_label;

let navAboutItem;
let navNetworkSettingItem;
let navIoSettingItem;
let navProtocolSettingItem;
let navCloudSettingItem;
let navPeertoPeerItem;
let navLogoutItem;

init = async () => {
  try {
    await _init();
  } catch (error) {
    ErrorUtility.handleError(error, {
      title: "Initialization Failed",
      appendMsg: "\nPlease refresh page",
    });
    hidePageLoading();
  }
}

_init = async () => {
  // Check if logged in
  var token = sessionStorage.getItem("token");
  if (token == null || token === "") {
    console.log("redirect page");
    location.replace("./login.html");
  }
  mainContentElem = document.getElementById("main-content");
  mainPageLoadingHint = document.getElementById("page-loading-hint");

  initPageLoadings();
  showPageLoading();

  initApiUrl();
  await initModuleType();

  initBasePath();
  initNavBarItems();
  await initPageRoutes();
  // changeModuleType(currentModuleType);

  const path = getPathName();
  pushNamed(path);

  // const moduleNameElem = document.getElementById("module-name");
  // moduleNameElem.innerText = MODULE_TYPE_TEXT[currentModuleType];

  hidePageLoading();
}

initApiUrl = () => {
  const search = window.location.search;
  if (search.startsWith("?")) {
    const params = new URLSearchParams(search);
    const deviceIpOnSubNetwork = params.get("data_io_ip");

    // if device ip provided, repres
    if (!StringUtility.isNothingOrEmpty(deviceIpOnSubNetwork)) {
      baseApiUrlSuffix = `?data_io_ip=${deviceIpOnSubNetwork}`;
    }
  }
}

initPageLoadings = () => {
  let html = "";
  for (let i = 0; i < 100; i++) {
    html += "<i><b></b></i>";
  }
  const loadings = document.getElementsByClassName("spinner");
  for (const loading of loadings) {
    loading.innerHTML = html;
  }
}
initPageLoadingsForReboot = () => {
  const contentHint = document.getElementById("content-reboot-hint")
  const sidebar = document.getElementById("sidebar");
  sidebar.style.display = "none";
  const container = document.querySelector('.container-fluid');
  container.style.display = "none";
  // document.body.style.backgroundColor = "#eeeeee";
  contentHint.style.display = "";
}
removePageLoadingsForReboot = () => {
  const contentHint = document.getElementById("content-reboot-hint")
  const sidebar = document.getElementById("sidebar");
  sidebar.style.display = "";
  const container = document.querySelector('.container-fluid');
  container.style.display = "";
  // document.body.style.backgroundColor = "";
  contentHint.style.display = "none";
}

showPageLoading = () => {
  mainContentElem.style.display = "none"
  mainPageLoadingHint.style.display = "";
}

hidePageLoading = () => {
  mainContentElem.style.display = ""
  mainPageLoadingHint.style.display = "none";
}

initModuleType = async () => {
  try {
    const res = (await Api.getDevice()).sysInfo.device;
    const deviceName = res.deviceName;

    if (deviceName) {
      document.getElementById('deviceName').textContent = `Remote I/O - ${deviceName}`;
    }

    switch (deviceName) {
      case "4AI4AO":
        currentModuleType = MODULE_TYPE_CODE.MOD008;
        break;
      case "8AI":
        currentModuleType = MODULE_TYPE_CODE.MOD108;
        break;
      case "8AO":
        currentModuleType = MODULE_TYPE_CODE.MOD208;
        break;
      case "8DI4RELAY":
        currentModuleType = MODULE_TYPE_CODE.MOD012;
        break;
      case "8DI8DO":
        currentModuleType = MODULE_TYPE_CODE.MOD016;
        break;
      case "8DI6DO2PWM":
        currentModuleType = MODULE_TYPE_CODE.MOD016P;
        break;
      case "16DI":
        currentModuleType = MODULE_TYPE_CODE.MOD116;
        break;
      case "16DO":
        currentModuleType = MODULE_TYPE_CODE.MOD216;
        break;
      default:
        currentModuleType = MODULE_TYPE_CODE.UNKNOWN;
    }
  } catch (error) {
    ErrorUtility.handleError(error);
  }
}

initBasePath = () => {
  // basePath = window.location.href;
  // const suffixPaths = [
  //   "/index.html", "/index.htm", "/"
  // ];
  // for (let suffixPath of suffixPaths) {
  //   if (basePath.endsWith(suffixPath)) {
  //     basePath = basePath.substring(0, basePath.length - suffixPath.length);
  //     break;
  //   }
  // }
  basePath = `${window.location.origin}/data_io`; 
  baseMidllePath = "data_io";
}

initNavBarItems = () => {
  navModuleItem = document.getElementById("navModuleItem");
  navSelectModuleTypeDropdown = document.getElementById("navSelectModuleTypeDropdown");
  navSelectModuleTypeDropdown_label = document.getElementById("navSelectModuleTypeDropdown_label");

  navAboutItem = document.getElementById("navAboutItem");
  navIoSettingItem = document.getElementById("navIoSettingItem");
  navNetworkSettingItem = document.getElementById("navNetworkSettingItem");
  navCloudSettingItem = document.getElementById("navCloudSettingItem");
  navProtocolSettingItem = document.getElementById("navProtocolSettingItem");
  navPeertoPeerItem = document.getElementById("navPeertoPeerItem");
  navLogoutItem = document.getElementById("navLogoutItem");

  Object.entries(MODULE_TYPE_TEXT).forEach((item, i) => {
    const value = item[0];
    const displayName = item[1];

    const option = document.createElement("a");
    option.id = ``;
    option.innerText = displayName;
    // option.onclick = (e) => {
    //   e.preventDefault();
    //   changeModuleType(value);
    // }

    navSelectModuleTypeDropdown.appendChild(option);
  });

  // navHomeItem.addEventListener("click", (event) => pushNamed("/", { event }));
  // navRelayItem.addEventListener("click", (event) => pushNamed("/relay", { event }));
  // navDigitalItem.addEventListener("click", (event) => pushNamed("/digital", { event })); 1
  // navDi16StatusItem.addEventListener("click", (event) => pushNamed("/di16status", { event }));
  // navDo16StatusItem.addEventListener("click", (event) => pushNamed("/digital_MOD-16DO", { event }));
  // navDoPulseItem.addEventListener("click", (event) => pushNamed("/dopulse", { event }));
  // navPwmItem.addEventListener("click", (event) => pushNamed("/pwm", { event }));
  // navAnalogItem.addEventListener("click", (event) => pushNamed("/analog", { event }));
  // navAo8Item.addEventListener("click", (event) => pushNamed("/ao8", { event }));
  // navAi4Ao4TuningItem.addEventListener("click", (event) => pushNamed("/ai4ao4tuning", { event }));
  // navAi8CalibrationItem.addEventListener("click", (event) => pushNamed("/ai8calibration", { event }));
  // navGatewayItem.addEventListener("click", (event) => pushNamed("/gateway", { event }));
  // navConfigItem.addEventListener("click", (event) => pushNamed("/config", { event }));

  navAboutItem.addEventListener("click", (event) => pushNamed("/about", { event }));
  navIoSettingItem.addEventListener("click", (event) => pushNamed("/iosetting", { event }));
  navNetworkSettingItem.addEventListener("click", (event) => pushNamed("/networksetting", { event }));
  navCloudSettingItem.addEventListener("click", (event) => pushNamed("/cloudsetting", { event }));
  navProtocolSettingItem.addEventListener("click", (event) => pushNamed("/protocolsetting", { event }));
  // navRuleEngineItem.addEventListener("click", (event) => pushNamed("/ruleengine", { event }));
  navPeertoPeerItem.addEventListener("click", (event) => pushNamed("/peertopeer", { event }));

  navLogoutItem.addEventListener("click", async (e) => {
    DialogUtility.confirm({ text: "Logout of system!" }).then((result) => {
      if (result.isConfirmed) {
        sessionStorage.clear();
        location.replace("./login.html");
      }
    });
  });
}

initPageRoutes = async () => {
  /**
   * M008 __ MOD-4AI+4AO
   * M108 __ MOD-8AI
   * M012 __ MOD-8DI+4RLY
   * M016 __ MOD-8DI+8DO
   * M116 __ MOD-16DI
   * M216 __ MOD-16DO
   */
  routePages = [
    // {
    //   route: "/home_4AI+4AO",
    //   htmlPath: "/home_MOD-4AI+4AO.htm",
    //   pageContet: "",
    //   constructor: HomePage,
    // },
    // {
    //   route: "/home_8AI",
    //   htmlPath: "/home_MOD-8AI.htm",
    //   pageContet: "",
    //   constructor: HomePage,
    // },
    // {
    //   route: "/home_8AO",
    //   htmlPath: "/home_MOD-8AO.htm",
    //   pageContet: "",
    //   constructor: HomePage,
    // },
    // {
    //   route: "/home_8DI+4RLY",
    //   htmlPath: "/home_MOD-8DI+4RLY.htm",
    //   pageContet: "",
    //   constructor: HomePage,
    // },
    // {
    //   route: "/home_8DI+8DO",
    //   htmlPath: "/home_MOD-8DI+8DO.htm",
    //   pageContet: "",
    //   constructor: HomePage,
    // },
    // {
    //   route: "/home_8DI+6DO+2PWM",
    //   htmlPath: "/home_MOD-8DI+6DO+2PWM.htm",
    //   pageContet: "",
    //   constructor: HomePage,
    // },
    // {
    //   route: "/home_16DI",
    //   htmlPath: "/home_MOD-16DI.htm",
    //   pageContet: "",
    //   constructor: HomePage,
    // },
    // {
    //   route: "/home_16DO",
    //   htmlPath: "/home_MOD-16DO.htm",
    //   pageContet: "",
    //   constructor: HomePage,
    // },
    // __all__
    {
      route: "/about",
      htmlPath: "/about.htm",
      pageContet: "",
      constructor: AboutPage,
    },
    {
      route: "/networksetting",
      htmlPath: "/networkSetting.htm",
      pageContet: "",
      constructor: NetworkPage,
    },
    {
      route: "/iosetting",
      htmlPath: "/ioSetting.htm",
      pageContet: "",
      constructor: IOSettingsPage,
    },
    // __all__
    {
      route: "/protocolsetting",
      htmlPath: "/protocolSetting.htm",
      pageContet: "",
      constructor: ProtocolSettingPage,
    },
    // __all__
    {
      route: "/cloudsetting",
      htmlPath: "/cloudSetting.htm",
      pageContet: "",
      constructor: CloudSettingPage,
    },
    // __all__
    {
      route: "/peertopeer",
      htmlPath: "/peer.htm",
      pageContet: "",
      constructor: PeerToPeerPage,
    },
    // __all__
    // {
    //   route: "/gateway",
    //   htmlPath: "/gateway.htm",
    //   pageContet: "",
    //   constructor: GatewayPage,
    // },
    // {
    //   route: "/config",
    //   htmlPath: "/config.htm",
    //   pageContet: "",
    //   constructor: ConfigPage,
    // },
    // D M012 M016 M116 M216
    // {
    //   route: "/dopulse",
    //   htmlPath: "/dopulse.htm",
    //   pageContet: "",
    //   constructor: DoPulsePage,
    // },
    // {
    //   route: "/pwm",
    //   htmlPath: "/pwm.htm",
    //   pageContet: "",
    //   constructor: PwmPage,
    // },
    // D M016 M116 M216
    // {
    //   route: "/digital",
    //   htmlPath: "/digital.htm",
    //   pageContet: "",
    //   constructor: DigitalPage,
    // },
    // {
    //   route: "/di16status",
    //   htmlPath: "/di16status.htm",
    //   pageContet: "",
    //   constructor: Di16StatusPage,
    // },
    // {
    //   route: "/digital_MOD-16DI",
    //   htmlPath: "/digital_MOD-16DI.htm",
    //   pageContet: "",
    //   constructor: DigitalPage,
    // },
    // {
    //   route: "/digital_MOD-16DO",
    //   htmlPath: "/digital_MOD-16DO.htm",
    //   pageContet: "",
    //   constructor: DigitalPage,
    // },
    // // D M008
    // {
    //   route: "/reboot",
    //   htmlPath: "/reboot.htm",
    //   pageContet: "",
    //   constructor: RebootPage,
    // },
    // // D M008
    // {
    //   route: "/report",
    //   htmlPath: "/report.htm",
    //   pageContet: "",
    //   constructor: ReportPage,
    // },
    // // M008
    // {
    //   route: "/analog",
    //   htmlPath: "/analog.htm",
    //   pageContet: "",
    //   constructor: AnalogPage,
    // },
    // // M008
    // {
    //   route: "/ai4ao4tuning",
    //   htmlPath: "/ai4ao4Tuning.htm",
    //   pageContet: "",
    //   constructor: Ai4Ao4TuningPage,
    // },
    // // M108
    // {
    //   route: "/ai8calibration",
    //   htmlPath: "/ai8Calibration.htm",
    //   pageContet: "",
    //   constructor: Ai8CalibrationPage,
    // },
    // {
    //   route: "/ao8",
    //   htmlPath: "/ao8.htm",
    //   pageContet: "",
    //   constructor: Ao8Page,
    // },
    // // M012
    // {
    //   route: "/relay",
    //   htmlPath: "/relay.htm",
    //   pageContet: "",
    //   constructor: RelayPage,
    // },
  ];

  // let pageContents = [];
  // await Promise
  //   .all(
  //     routePages
  //       .map((e) => xmlGet(basePath + "/" + e.htmlPath))
  //       .map(reflect)
  //   )
  //   .then(function(results){
  //     pageContents = results;
  //   });

  for (let i = 0; i < routePages.length; i++) {
    const page = routePages[i];
    const key = page.htmlPath.substr(1);
    const content = pageHtmlContents[key];
    if (!content) {
      continue;
    }
    routes[page.route] = {
      pageContent: content,
      constructor: page.constructor,
    };
  }
}

window.onpopstate = () => {
  replacePageContent();
}
document.addEventListener("DOMContentLoaded", function() {
  const menuItems = document.querySelectorAll('#sidebarMenu > li');
  const pathnames = ['0', '/about', '/networksetting', '/iosetting', '/protocolsetting', '/cloudsetting', '/peertopeer'];

  const applyActiveClassByPath = () => {
    const currentPath = window.location.pathname;  // 獲取當前的 URL 路徑
    menuItems.forEach(item => item.classList.remove('active'));  // 清除所有的 active 樣式
    menuItems.forEach((item, index) => {
      // 根據 pathnames 陣列來判斷當前路徑對應的選單
      if (currentPath.includes(pathnames[index])) {
        item.classList.add('active');
        localStorage.setItem('selectedMenuIndex', index);  // 更新 localStorage
      }
    });
  };

  // 頁面載入時應用正確的樣式
  applyActiveClassByPath();

  // 點擊選單時應用 active 樣式並更新 localStorage
  menuItems.forEach((item, index) => {
    item.addEventListener('click', function() {
      menuItems.forEach(el => el.classList.remove('active'));
      this.classList.add('active');
      localStorage.setItem('selectedMenuIndex', index);
    });
  });

  // 監聽 popstate 事件（上一頁、下一頁）
  window.addEventListener('popstate', function() {
    applyActiveClassByPath();
  });
});

function syncSidebarHeight() {
  const sidebar = document.getElementById('sidebar');
  const content = document.getElementById('content');

  // 將 sidebar 高度設定為 content 的高度
  sidebar.style.height = `${content.scrollHeight}px`;
}

// 在載入與窗口變化時同步高度
window.addEventListener('load', syncSidebarHeight);
window.addEventListener('resize', syncSidebarHeight);
window.addEventListener('scroll', syncSidebarHeight);

// Add to Number no rounding when changing to string
Number.prototype.toFixedNoRounding = function (n) {
  const reg = new RegExp("^-?\\d+(?:\\.\\d{0," + n + "})?", "g")
  const a = this.toString().match(reg)[0];
  const dot = a.indexOf(".");
  if (dot === -1) { // integer, insert decimal dot and pad up zeros
    return a + "." + "0".repeat(n);
  }
  const b = n - (a.length - dot) + 1;
  return b > 0 ? (a + "0".repeat(b)) : a;
}
