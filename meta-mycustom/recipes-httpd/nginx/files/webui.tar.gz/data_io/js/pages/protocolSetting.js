class ProtocolSettingPage {
  constructor(props) {
    this.state = {
      modType: "",
      outputCH: 0,
      enable: false,
      role: sessionStorage.getItem('role'),
      mqttConfigs: {},
      rootCaFileName: "",
      clientCertFileName: "",
      clientKeyFileName: "",
    };
    this.initializeModType();
    this.init();
  }

  initializeModType = () => {
    switch (currentModuleType) {     
      case MODULE_TYPE_CODE.MOD012:
        this.state.modType = "8DI4RELAY";
        this.state.outputCH = 4;
        break;
      case MODULE_TYPE_CODE.MOD016:
        this.state.modType = "8DI8DO";
        this.state.outputCH = 8;
        break;
      case MODULE_TYPE_CODE.MOD108:
        this.state.modType = "8AI";
        break;
      case MODULE_TYPE_CODE.MOD116:
        this.state.modType = "16DI";
        break;
      case MODULE_TYPE_CODE.MOD208:
        this.state.modType = "8AO";
        break;
      case MODULE_TYPE_CODE.MOD216:
        this.state.modType = "16DO";
        break;
    }
  }

  init = () => {
    const modbusDiv = document.querySelector('.tab.modbus');
    const powerlinkDiv = document.querySelector('.tab.powerlink');
    const snmpDiv = document.querySelector('.tab.snmp');
    const opcuaDiv = document.querySelector('.tab.opcua');
    const mqttDiv = document.querySelector('.tab.mqtt');
    
    modbusDiv.addEventListener('click', async (e) => {
      e.preventDefault();
      this.loadModbusPage();
    });
    modbusDiv.click();
    
    powerlinkDiv.addEventListener('click', async (e) => {
      e.preventDefault();
      this.initPowerlink();
    });

    if(this.state.modType === "8AO") {
      snmpDiv.style.display = 'none';
    } else {
      snmpDiv.addEventListener('click', async (e) => {
        e.preventDefault();
        this.loadSnmpPage();
      });
    }

    opcuaDiv.addEventListener('click', async (e) => {
      e.preventDefault();
      this.loadOpcuaPage();
    });

    mqttDiv.addEventListener('click', async (e) => {
      e.preventDefault();
      this.loadMqttconPage();
    });

    if (!(currentPage instanceof ProtocolSettingPage)) {
      return;
    }
  }
  //modbus
  loadModbusPage = async () => {
    let mainstat = document.getElementById('displayModbus');
    let loadstat = document.getElementById('loadingModbus');

    try {
      const settings = await Api.getModbusAddressAgent();
      mainstat.style.display = 'block';
      loadstat.style.display = 'none';

      const tcpPort = document.getElementById('tcpPort');
      const slaveID = document.getElementById('slaveID');
      setDomProperty(tcpPort, "value", settings?.tcpPort);
      setDomProperty(slaveID, "value", settings?.slaveID);
      setDisableSingleOrButton(tcpPort);
      setDisableSingleOrButton(slaveID);
  
      // Determine the type of device
      if (this.state.modType === "8DI4RELAY") {
        document.getElementById("di").style.display = "table";
        // document.getElementById("doDefaultValueBaseDefault").innerHTML = 280;
        // document.getElementById("doDefaultEnableBaseDefault").innerHTML = 276;
        document.getElementById("do").style.display = "table";
        this.loadPage_DI(settings);
        this.loadPage_DO(settings);
      } else if (this.state.modType === "8DI8DO") {
        document.getElementById("di").style.display = "table";
        document.getElementById("do").style.display = "table";
        this.loadPage_DI(settings);
        this.loadPage_DO(settings);
      } else if (this.state.modType === "16DI") {
        // document.getElementById("diCounterResetBaseDefault").innerHTML = 272;
        // document.getElementById("diCounterOverflowBaseDefault").innerHTML = 272;
        document.getElementById("di").style.display = "table";
        this.loadPage_DI(settings);
      } else if (this.state.modType === "16DO") {
        // document.getElementById("doOutputBaseDefault").innerHTML = 256;
        // document.getElementById("doDefaultEnableBaseDefault").innerHTML = 272;
        document.getElementById("do").style.display = "table";
        this.loadPage_DO(settings);
      } else if (this.state.modType === "8AI") {
        document.getElementById("ai").style.display = "table";
        this.loadPage_AI(settings);
      } else if (this.state.modType === "8AO") {
        document.getElementById("ao").style.display = "table";
        this.loadPage_AO(settings);
      }

      const modbusSave = document.getElementById('modbusSave');
      modbusSave.addEventListener('click', this.initModbusButton);
      setDisableSingleOrButton(modbusSave);
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
          return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  initModbusButton = async() => {

      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const tcpPort = parseInt(document.getElementById('tcpPort').value);
        const slaveID = parseInt(document.getElementById('slaveID').value);

        // Check allowed values
        if (tcpPort < 0 || tcpPort > 65535) {
          customErrorProps.data.error.message = "TCP port must be between 0 and 65535";
          throw new CustomError(customErrorProps);
        }
        if (slaveID < 1 || slaveID > 247) {
          customErrorProps.data.error.message = "Slave ID must be between 1 and 247";
          throw new CustomError(customErrorProps);
        }
        const payload = {
          tcpPort: tcpPort,
          slaveID: slaveID,
  
          diCounterEnableBase: 256,
          diCounterResetBase: 264,
          diInputBase: 256,
          diCounterOverflowBase: 264,
          diCounterValueBase: 256,
  
          doOutputBase: 272,
          doDefaultEnableBase: 280,
          doDefaultValueBase: 288,
  
          aiInputRawBase: 0,
          aiInputEngBase: 0,
  
          aoDefaultEnableBase: 0,
          aoOutputRawBase: 0,
          aoDefaultOutputRawBase: 0,
          aoOutputEngBase: 0,
          aoDefaultOutputEngBase: 0
        }

        // Determine the type of device
        if (this.state.modType === "8DI4RELAY") {
          this.setParams_DI(customErrorProps, payload);
          this.setParams_DO(customErrorProps, payload);
        } else if (this.state.modType === "8DI8DO") {
          this.setParams_DI(customErrorProps, payload);
          this.setParams_DO(customErrorProps, payload);
        } else if (this.state.modType === "16DI") {
          this.setParams_DI(customErrorProps, payload);
        } else if (this.state.modType === "16DO") {
          this.setParams_DO(customErrorProps, payload);
        } else if (this.state.modType === "8AI") {
          this.setParams_AI(customErrorProps, payload);
        } else if (this.state.modType === "8AO") {
          this.setParams_DO(customErrorProps, payload);
        }
        // else if (this.state.modType === "4AI4AO" || this.state.modType === "8DI6DO2PWM") {
        //   this.setParams_AI(customErrorProps, payload);
        //   this.setParams_AO(customErrorProps, payload);
        // }

        const res = await Api.editModbusAddressAgent(payload);
    
        DialogUtility.showSuccess({
          text: res.error?.message,
        });
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    // });
  }

  setParams_DI(customErrorProps, payload) {
    const diCounterEnableBase = parseInt(document.getElementById('diCounterEnableBase').value);
    const diCounterResetBase = parseInt(document.getElementById('diCounterResetBase').value);
    const diInputBase = parseInt(document.getElementById('diInputBase').value);
    const diCounterOverflowBase = parseInt(document.getElementById('diCounterOverflowBase').value);
    const diCounterValueBase = parseInt(document.getElementById('diCounterValueBase').value);

    // Check allowed values
    if (diCounterEnableBase < 0 || diCounterEnableBase > 65520) {
      customErrorProps.data.error.message = "DI CounterEnableBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (diCounterResetBase < 0 || diCounterResetBase > 65520) {
      customErrorProps.data.error.message = "DI CounterResetBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (diInputBase < 0 || diInputBase > 65520) {
      customErrorProps.data.error.message = "DI InputBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (diCounterOverflowBase < 0 || diCounterOverflowBase > 65520) {
      customErrorProps.data.error.message = "DI CounterOverflowBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (diCounterValueBase < 0 || diCounterValueBase > 65504) {
      customErrorProps.data.error.message = "DI CounterValueBase must be between 0 and 65504";
      throw new CustomError(customErrorProps);
    }

    // Set values
    payload.diCounterEnableBase = diCounterEnableBase;
    payload.diCounterResetBase = diCounterResetBase;
    payload.diInputBase = diInputBase;
    payload.diCounterOverflowBase = diCounterOverflowBase;
    payload.diCounterValueBase = diCounterValueBase;
  }
  loadPage_DI(settings) {
    const diCounterEnableBase = document.getElementById('diCounterEnableBase');
    const diCounterResetBase = document.getElementById('diCounterResetBase');
    const diInputBase = document.getElementById('diInputBase');
    const diCounterOverflowBase = document.getElementById('diCounterOverflowBase');
    const diCounterValueBase = document.getElementById('diCounterValueBase');

    setDomProperty(diCounterEnableBase, "value", settings?.diCounterEnableBase);
    setDomProperty(diCounterResetBase, "value", settings?.diCounterResetBase);
    setDomProperty(diInputBase, "value", settings?.diInputBase);
    setDomProperty(diCounterOverflowBase, "value", settings?.diCounterOverflowBase);
    setDomProperty(diCounterValueBase, "value", settings?.diCounterValueBase);
    setDisableSingleOrButton(diCounterEnableBase);
    setDisableSingleOrButton(diCounterResetBase);
    setDisableSingleOrButton(diInputBase);
    setDisableSingleOrButton(diCounterOverflowBase);
    setDisableSingleOrButton(diCounterValueBase);
  }

  setParams_DO(customErrorProps, payload) {
    const doOutputBase = parseInt(document.getElementById('doOutputBase').value);
    const doDefaultEnableBase = parseInt(document.getElementById('doDefaultEnableBase').value);
    const doDefaultValueBase = parseInt(document.getElementById('doDefaultValueBase').value);

    // Check allowed values
    if (doOutputBase < 0 || doOutputBase > 65520) {
      customErrorProps.data.error.message = "DO OutputBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (doDefaultEnableBase < 0 || doDefaultEnableBase > 65520) {
      customErrorProps.data.error.message = "DO DefaultEnableBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (doDefaultValueBase < 0 || doDefaultValueBase > 65520) {
      customErrorProps.data.error.message = "DO DefaultValueBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }

    // Set values
    payload.doOutputBase = doOutputBase;
    payload.doDefaultEnableBase = doDefaultEnableBase;
    payload.doDefaultValueBase = doDefaultValueBase;
  }
  loadPage_DO(settings) {
    const doOutputBase = document.getElementById('doOutputBase');
    const doDefaultEnableBase = document.getElementById('doDefaultEnableBase');
    const doDefaultValueBase = document.getElementById('doDefaultValueBase');

    setDomProperty(doOutputBase, "value", settings?.doOutputBase);
    setDomProperty(doDefaultEnableBase, "value", settings?.doDefaultEnableBase);
    setDomProperty(doDefaultValueBase, "value", settings?.doDefaultValueBase);

    setDisableSingleOrButton(doOutputBase);
    setDisableSingleOrButton(doDefaultEnableBase);
    setDisableSingleOrButton(doDefaultValueBase);
  }

  setParams_AI(customErrorProps, payload) {
    const aiInputRawBase = parseInt(document.getElementById('aiInputRawBase').value);
    const aiInputEngBase = parseInt(document.getElementById('aiInputEngBase').value);

    // Check allowed values
    if (aiInputRawBase < 0 || aiInputRawBase > 65520) {
      customErrorProps.data.error.message = "AI InputRawBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aiInputEngBase < 0 || aiInputEngBase > 65520) {
      customErrorProps.data.error.message = "AI InputEngBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }

    // Set values
    payload.aiInputRawBase = aiInputRawBase;
    payload.aiInputEngBase = aiInputEngBase;
  }
  loadPage_AI(settings) {
    const aiInputRawBase = document.getElementById('aiInputRawBase');
    const aiInputEngBase = document.getElementById('aiInputEngBase');

    setDomProperty(aiInputRawBase, "value", settings?.aiInputRawBase);
    setDomProperty(aiInputEngBase, "value", settings?.aiInputEngBase);
  }

  setParams_AO(customErrorProps, payload) {
    const aoDefaultEnableBase = parseInt(document.getElementById('aoDefaultEnableBase').value);
    const aoOutputRawBase = parseInt(document.getElementById('aoOutputRawBase').value);
    const aoDefaultOutputRawBase = parseInt(document.getElementById('aoDefaultOutputRawBase').value);
    const aoOutputEngBase = parseInt(document.getElementById('aoOutputEngBase').value);
    const aoDefaultOutputEngBase = parseInt(document.getElementById('aoDefaultOutputEngBase').value);

    // Check allowed values
    if (aoDefaultEnableBase < 0 || aoDefaultEnableBase > 65520) {
      customErrorProps.data.error.message = "AO DefaultEnableBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aoOutputRawBase < 0 || aoOutputRawBase > 65520) {
      customErrorProps.data.error.message = "AO OutputRawBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aoDefaultOutputRawBase < 0 || aoDefaultOutputRawBase > 65520) {
      customErrorProps.data.error.message = "AO DefaultOutputRawBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aoOutputEngBase < 0 || aoOutputEngBase > 65520) {
      customErrorProps.data.error.message = "AO OutputEngBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }
    if (aoDefaultOutputEngBase < 0 || aoDefaultOutputEngBase > 65520) {
      customErrorProps.data.error.message = "AO DefaultOutputEngBase must be between 0 and 65520";
      throw new CustomError(customErrorProps);
    }

    // Set values
    payload.aoDefaultEnableBase = aoDefaultEnableBase;
    payload.aoOutputRawBase = aoOutputRawBase;
    payload.aoDefaultOutputRawBase = aoDefaultOutputRawBase;
    payload.aoOutputEngBase = aoOutputEngBase;
    payload.aoDefaultOutputEngBase = aoDefaultOutputEngBase;
  }
  loadPage_AO(settings) {
    const aoDefaultEnableBase = document.getElementById('aoDefaultEnableBase');
    const aoOutputRawBase = document.getElementById('aoOutputRawBase');
    const aoDefaultOutputRawBase = document.getElementById('aoDefaultOutputRawBase');
    const aoOutputEngBase = document.getElementById('aoOutputEngBase');
    const aoDefaultOutputEngBase = document.getElementById('aoDefaultOutputEngBase');

    setDomProperty(aoDefaultEnableBase, "value", settings?.aoDefaultEnableBase);
    setDomProperty(aoOutputRawBase, "value", settings?.aoOutputRawBase);
    setDomProperty(aoDefaultOutputRawBase, "value", settings?.aoDefaultOutputRawBase);
    setDomProperty(aoOutputEngBase, "value", settings?.aoOutputEngBase);
    setDomProperty(aoDefaultOutputEngBase, "value", settings?.aoDefaultOutputEngBase);
  }

  //powerlink
  initPowerlink = async() => {
    const config = await Api.getPowerlinkConfig();
    this.setPowerlinkConfig(config);

    const plSubmit = document.getElementById("plSubmit");
    if (plSubmit) {
      plSubmit.addEventListener('click', this.submitPowerlink);
      setDisableSingleOrButton(plSubmit);
    }

    const disable = document.getElementById("powerlinkDisable");
    if (disable) {
      disable.addEventListener('click', this.switchEnable);
      setDisableSingleOrButton(disable);
    }
    const enable = document.getElementById("powerlinkEnable");
    if (enable) {
      enable.addEventListener('click', this.switchEnable);
      setDisableSingleOrButton(enable);
    }
  }

  setPowerlinkConfig = (config) => {
    this.setEnable(config.eplEnable);
    const nodeID = document.getElementById("nodeID");
    setDisableSingleOrButton(nodeID);
    nodeID.value = config.eplNodeID;
  }
    
  submitPowerlink = async (e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
        error: {
        message: "",
        }
      }
    };
  
    try {
      const enable = this.state.enable;
      const payload = {
        eplEnable: 0,
        eplNodeID: 1
      };
      if (enable) {
        const nodeID = parseInt(document.getElementById("nodeID").value);
        // Check allowed values
        
        if (nodeID < 1 || nodeID > 239) {
            customErrorProps.data.error.message = "Node ID must be between 1 and 239 (including)";
            throw new CustomError(customErrorProps);
        }
        payload.eplEnable = 1;
        payload.eplNodeID = nodeID;
      }
      DialogUtility.confirm({ text: `System will ${enable ? "enable" : "disable"} Sparkplug?` }).then(async (result) => {
        if (result.isConfirmed) {
          const res = await Api.setPowerlinkConfig(payload);
          DialogUtility.showSuccess({
            text: res.error?.message,
          });
        }
      });
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }
    
  switchEnable = async (e) => {
    const enable = parseInt(e.srcElement.defaultValue);
    this.setEnable(enable);
  }
    
  setEnable(selected) {
    if (selected === 0) {
        document.getElementById("powerlinkDisable").checked = true;
    } else if (selected === 1) {
        document.getElementById("powerlinkEnable").checked = true;
    }
    const disable = selected === 0 ? true : false;
    // Set whether DHCP in state
    this.state = { enable: !disable };
    const nodeID = document.getElementById("nodeID");

    nodeID.disabled = disable;
  }
  //snmp
  loadSnmpPage = async () => {
    let mainstat = document.getElementById('displaySnmp');
    let loadstat = document.getElementById('loadingSnmp');
    const { modType } = this.state;

    try {
      if (!modType) {
        this.initializeModType();
      }
      const settings = await Api.getSnmpTrapAgent(); 
      mainstat.style.display = 'block';
      loadstat.style.display = 'none';
      const snmpAgentEnable = document.getElementById('snmpAgentEnable');
      const snmpServer1 = document.getElementById('snmpServer1');
      const snmpServer2 = document.getElementById('snmpServer2');
      const communityName = document.getElementById('communityName');
  
      setDomProperty(snmpAgentEnable, "checked", settings?.snmpAgentEnable === 1 ? true : false);
      setDomProperty(snmpServer1, "value", settings?.snmpServer1);
      setDomProperty(snmpServer2, "value", settings?.snmpServer2);
      setDomProperty(communityName, "value", settings?.communityName);

      setDisableSingleOrButton(snmpAgentEnable);
      setDisableSingleOrButton(snmpServer1);
      setDisableSingleOrButton(snmpServer2);
      setDisableSingleOrButton(communityName);
      
      // Make sure we're displaying the status display
      // Determine the type of device
      if (modType === "8DI4RELAY") {
        this.loadPage_8DI4RELAY(settings, "snmpv2");
      } else if (modType === "8DI8DO") { 
        this.loadPage_8DI8DO(settings, "snmpv2");
      } else if (modType === "16DI") {
        this.loadPage_16DI(settings, "snmpv2");
      } else if (modType === "16DO") {
        this.loadPage_16DO(settings, "snmpv2");
      } else if (modType === "8AI") {
        this.loadPage_8AI(settings, "snmpv2");
      } 
      // else if (this.state.modType === "8AO") {
      //   this.loadPage_8AO(settings);
      // } 8AO不支持此，之後寫若8AO登入要移除此頁面
      //  else if (this.state.modType === "8DI6DO2PWM") {
      //     this.loadPage_8DI6DO2PWM(settings);
      // }

      const navSnmpTab = document.getElementById('nav-snmpv2-tab');
      navSnmpTab.addEventListener('click', this.loadSnmpPage);
      const snmpSave = document.getElementById('snmpSave');
      snmpSave.addEventListener('click', this.initSnmpButton);      

      const navSnmpv3Tab = document.getElementById('nav-snmpv3-tab');
      navSnmpv3Tab.addEventListener('click', this.loadSnmpv3Page);
      const snmpv3Save = document.getElementById('snmpv3Save');
      snmpv3Save.addEventListener('click', this.initSnmpv3Button);
      setDisableSingleOrButton(snmpSave);
      setDisableSingleOrButton(snmpv3Save);
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
          return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  initSnmpButton = async() => {
    const { modType } = this.state;
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };

    try {
      const snmpAgentEnable = document.getElementById('snmpAgentEnable').checked ? 1 : 0;
      const snmpServer1 = document.getElementById('snmpServer1').value;
      const snmpServer2 = document.getElementById('snmpServer2').value;
      const communityName = document.getElementById('communityName').value;
      const payload = {
        aiGreater: [],
        aiLess: [],
        communityName: communityName,
        di: [
          {
            diIndex: 0,
            diEnable: 1,
            diSpecificID: 0
          }
        ],
        do: [
          {
            doIndex: 0,
            doEnable: 1,
            doSpecificID: 8
          }
        ],
        snmpAgentEnable: snmpAgentEnable,
        snmpServer1: snmpServer1,
        snmpServer2: snmpServer2,
      }
      
      // Determine the type of device
      if (modType === "8DI4RELAY") {
        this.setParams_8DI4RELAY(customErrorProps, payload, "snmpv2");
      } else if (modType === "8DI8DO") {
        this.setParams_8DI8DO(customErrorProps, payload, "snmpv2");
      } else if (modType === "16DI") {
        this.setParams_16DI(customErrorProps, payload, "snmpv2");
      } else if (modType === "16DO") {
        this.setParams_16DO(customErrorProps, payload, "snmpv2");
      } else if (modType === "8AI") {
        this.setParams_8AI(customErrorProps, payload, "snmpv2");
      }
      // else if (this.state.modType === "8DI6DO2PWM") {
      //     this.setParams_8DI6DO2PWM(customErrorProps, payload);
      // } 
      
      const res = await Api.editSnmpTrapAgent(payload);

      DialogUtility.showSuccess({
        text: res.error?.message,
      });
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  initSnmpv3Button = async() => {
    const { modType } = this.state;
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };

    try {
      const snmpAgentEnable = document.getElementById('snmpv3AgentEnable').checked ? 1 : 0;
      
      const snmpv3Server1 = document.getElementById('snmpv3Server1').value;
      const snmpv3port1 = parseInt(document.getElementById('snmpv3port1').value);
      const userName1 = document.getElementById('userName1').value;
      const authProtocol1 = parseInt(document.getElementById('authProtocol1').value);
      const authPassphrase1 = document.getElementById('authPassphrase1').value;
      const authPriv1 = parseInt(document.getElementById('authPriv1').value);
      const privacyProtocol1 = parseInt(document.getElementById('privacyProtocol1').value);
      const privacyPassphrase1 = document.getElementById('privacyPassphrase1').value;

      const snmpv3Server2 = document.getElementById('snmpv3Server2').value;
      const snmpv3port2 = parseInt(document.getElementById('snmpv3port2').value);
      const userName2 = document.getElementById('userName2').value;
      const authProtocol2 = parseInt(document.getElementById('authProtocol2').value);
      const authPassphrase2 = document.getElementById('authPassphrase2').value;
      const authPriv2 = parseInt(document.getElementById('authPriv2').value);
      const privacyProtocol2 = parseInt(document.getElementById('privacyProtocol2').value);
      const privacyPassphrase2 = document.getElementById('privacyPassphrase2').value;

      if(snmpv3Server1 !== "" && (snmpv3port1 === "" || userName1 === "" || authPassphrase1 === "" || privacyPassphrase1 === "")){
        customErrorProps.data.error.message = "All fields in No.1 must be filled in";
        throw new CustomError(customErrorProps);
      } else if(snmpv3Server2 !== "" && (snmpv3port2 === "" || userName2 === "" || authPassphrase2 === "" || privacyPassphrase2 === "")){
        customErrorProps.data.error.message = "All fields in No.2 must be filled in";
        throw new CustomError(customErrorProps);
      }

      const payload = {
        aiGreater: [],
        aiLess: [],
        di: [
          {
            diIndex: 0,
            diEnable: 1,
          }
        ],
        do: [
          {
            doIndex: 0,
            doEnable: 1,
          }
        ],
        snmpAgentEnable: snmpAgentEnable,
        snmpServer1: {
          ip: snmpv3Server1,
          port: snmpv3port1,
          userName: userName1,
          authProtocol: authProtocol1,
          authPassphrase: authPassphrase1,
          authPriv: authPriv1,
          privacyProtocol: privacyProtocol1,
          privacyPassphrase: privacyPassphrase1,
        },
        snmpServer2: {
          ip: snmpv3Server2,
          port: snmpv3port2,
          userName: userName2,
          authProtocol: authProtocol2,
          authPassphrase: authPassphrase2,
          authPriv: authPriv2,
          privacyProtocol: privacyProtocol2,
          privacyPassphrase: privacyPassphrase2,
        },
      }
      
      if (modType === "8DI4RELAY"){
        this.setParams_8DI4RELAY(customErrorProps, payload, "snmpv3");
      } else if (modType === "8DI8DO"){
        this.setParams_8DI8DO(customErrorProps, payload, "snmpv3");
      } else if (modType === "16DI"){
        this.setParams_16DI(customErrorProps, payload, "snmpv3");
      } else if (modType === "16DO"){
        this.setParams_16DO(customErrorProps, payload, "snmpv3");
      } else if (modType === "8AI"){
        this.setParams_8AI(customErrorProps, payload, "snmpv3");
      }
      
      const res = await Api.editSnmpV3TrapAgent(payload);
      DialogUtility.showSuccess({
        text: res.error?.message,
      });
      this.loadSnmpv3Page();
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  loadSnmpv3Page = async () => {
    let mainstat = document.getElementById('displaySnmpv3');
    let loadstat = document.getElementById('loadingSnmpv3');
    const { modType } = this.state;
    try {
      if (!modType) {
        this.initializeModType();
      }
      const settings = await Api.getSnmpV3TrapAgent();
      const { snmpServer1, snmpServer2 } = settings;
      mainstat.style.display = 'block';
      loadstat.style.display = 'none';
      
      if(settings){
        const authPrivOption = `
          <option value="0">NoAuthNoPriv</option>
          <option value="1">AuthNoPriv</option>
          <option value="3">AuthPriv</option>
        `;
        const authProtocolOption = `
          <option value="1">NoAuth</option>
          <option value="2">MD5</option>
          <option value="3">SHA</option>
          <option value="4">SHA224</option>
          <option value="5">SHA256</option>
          <option value="6">SHA384</option>
          <option value="7">SHA512</option>
        `;
        const privacyProtocolOption = `
          <option value="1">NoPriv</option>
          <option value="2">DES</option>
          <option value="3">AES</option>
          <option value="4">AES192</option>
          <option value="5">AES256</option>
          <option value="6">AES192C</option>
          <option value="7">AES256C</option>
        `;
        document.getElementById('authPriv1').innerHTML = authPrivOption;
        document.getElementById('authPriv2').innerHTML = authPrivOption;
        document.getElementById('authProtocol1').innerHTML = authProtocolOption;
        document.getElementById('authProtocol2').innerHTML = authProtocolOption;
        document.getElementById('privacyProtocol1').innerHTML = privacyProtocolOption;
        document.getElementById('privacyProtocol2').innerHTML = privacyProtocolOption;
      };
      const snmpAgentEnable = document.getElementById('snmpv3AgentEnable');
      setDomProperty(snmpAgentEnable, "checked", settings?.snmpAgentEnable === 1 ? true : false);
      setDisableSingleOrButton(snmpAgentEnable);

      setValue(document.getElementById('snmpv3Server1'), snmpServer1.ip);
      setValue(document.getElementById('snmpv3port1'), snmpServer1.port);
      setValue(document.getElementById('userName1'), snmpServer1.userName);
      setValue(document.getElementById('bottomUserName1'), snmpServer1.userName);
      setValue(document.getElementById('authProtocol1'), snmpServer1.authProtocol);
      setValue(document.getElementById('authPassphrase1'), snmpServer1.authPassphrase);
      setValue(document.getElementById('authPriv1'), snmpServer1.authPriv);
      setValue(document.getElementById('privacyProtocol1'), snmpServer1.privacyProtocol);
      setValue(document.getElementById('privacyPassphrase1'), snmpServer1.privacyPassphrase);
      setValue(document.getElementById('snmpv3Server2'), snmpServer2.ip);
      setValue(document.getElementById('snmpv3port2'), snmpServer2.port);
      setValue(document.getElementById('userName2'), snmpServer2.userName);
      setValue(document.getElementById('bottomUserName2'), snmpServer2.userName);
      setValue(document.getElementById('authProtocol2'), snmpServer2.authProtocol);
      setValue(document.getElementById('authPassphrase2'), snmpServer2.authPassphrase);
      setValue(document.getElementById('authPriv2'), snmpServer2.authPriv);
      setValue(document.getElementById('privacyProtocol2'), snmpServer2.privacyProtocol);
      setValue(document.getElementById('privacyPassphrase2'), snmpServer2.privacyPassphrase);

      setDisableSingleOrButton(document.getElementById('snmpv3Server1'));
      setDisableSingleOrButton(document.getElementById('snmpv3port1'));
      setDisableSingleOrButton(document.getElementById('userName1'));
      setDisableSingleOrButton(document.getElementById('authProtocol1'));
      setDisableSingleOrButton(document.getElementById('authPassphrase1'));
      setDisableSingleOrButton(document.getElementById('authPriv1'));
      setDisableSingleOrButton(document.getElementById('privacyProtocol1'));
      setDisableSingleOrButton(document.getElementById('privacyPassphrase1'));
      setDisableSingleOrButton(document.getElementById('snmpv3Server2'));
      setDisableSingleOrButton(document.getElementById('snmpv3port2'));
      setDisableSingleOrButton(document.getElementById('userName2'));
      setDisableSingleOrButton(document.getElementById('authProtocol2'));
      setDisableSingleOrButton(document.getElementById('authPassphrase2'));
      setDisableSingleOrButton(document.getElementById('authPriv2'));
      setDisableSingleOrButton(document.getElementById('privacyProtocol2'));
      setDisableSingleOrButton(document.getElementById('privacyPassphrase2'));

      if (modType === "8DI4RELAY"){
        this.loadPage_8DI4RELAY(settings, "snmpv3");
      } else if (modType === "8DI8DO"){
        this.loadPage_8DI8DO(settings, "snmpv3");
      } else if (modType === "16DI"){
        this.loadPage_16DI(settings, "snmpv3");
      } else if (modType === "16DO"){
        this.loadPage_16DO(settings, "snmpv3");
      } else if (modType === "8AI"){
        this.loadPage_8AI(settings, "snmpv3");
      }
    } catch (error) {
      ErrorUtility.handleError(error);
      if(mainstat == null || loadstat == null){
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  loadPage_8DI4RELAY(settings, snmpVersion) {
    // Set descriptions
    // document.getElementById('headDesc').innerHTML = '8DI4RELAY Trap Settings';
    snmpVersion === "snmpv2" ? document.getElementById('channel_a').innerHTML = 'Channel' : document.getElementById('channel_a_v3').innerHTML = 'Channel';
    snmpVersion === "snmpv2" ? document.getElementById('channel_b').innerHTML = 'Channel' : document.getElementById('channel_b_v3').innerHTML = 'Channel';

    const dis = settings.di;
    const dos = settings.do;
    for (let i = 0; i < 8; i++) {
      // Set all DI's
      snmpVersion === "snmpv2" ? document.getElementById('no_' + i).innerHTML = 'DI-0' + (i) : document.getElementById('no_' + i + '_v3').innerHTML = 'DI-0' + (i);
      let diEnable;
      snmpVersion === "snmpv2" ? diEnable = document.getElementById('enable_' + i) : diEnable = document.getElementById('enable_' + i + '_v3');
      // const diEnable = document.getElementById('enable_' + i);
      const di = dis.find(e => e.diIndex == i);
      setDomProperty(diEnable, "checked", di?.diEnable === 1 ? true : false);
      setDisableSingleOrButton(diEnable);
      if(snmpVersion === "snmpv2"){
        const diSpecificID = document.getElementById('sid_' + i);
        setDomProperty(diSpecificID, "value", di?.diSpecificID);
        setDisableSingleOrButton(diSpecificID);
      }
    }
    for (let i = 0; i < 4; i++) {
      // Set all Relay (DO's)
      snmpVersion === "snmpv2" ? document.getElementById('no_' + (i + 8)).innerHTML = 'Relay-0' + (i) : document.getElementById('no_' + (i + 8) + '_v3').innerHTML = 'Relay-0' + (i);
      // document.getElementById('no_' + (i + 8)).innerHTML = 'Relay-0' + (i);
      let doEnable;
      snmpVersion === "snmpv2" ? doEnable = document.getElementById('enable_' + (i + 8)) : doEnable = document.getElementById('enable_' + (i + 8) + '_v3');
      // const doEnable = document.getElementById('enable_' + (i + 8));
      const ds = dos.find(e => e.doIndex == i); // Note: cannot use reserved keyword "do"
      setDomProperty(doEnable, "checked", ds?.doEnable === 1 ? true : false); 
      setDisableSingleOrButton(doEnable);
      if(snmpVersion === "snmpv2"){    
        const doSpecificID = document.getElementById('sid_' + (i + 8));
        setDomProperty(doSpecificID, "value", ds?.doSpecificID);
        setDisableSingleOrButton(doSpecificID);
      }
    }
    // Hide last 4 checkbox & inputs
    for (let i = 0; i < 4; i++) {
      const doEnable = snmpVersion === "snmpv2" ? document.getElementById('enable_' + (i + 12)) : document.getElementById('enable_' + (i + 12) + '_v3');
      doEnable.style.display = "none";
      if(snmpVersion === "snmpv2"){
        const doSpecificID = snmpVersion === "snmpv2" ? document.getElementById('sid_' + (i + 12)) : document.getElementById('sid_' + (i + 12) + '_v3');
        doSpecificID.style.display = "none";
      }
    }
  }
  setParams_8DI4RELAY(customErrorProps, payload, snmpVersion) {
    // Set DI's
    for (let i = 0; i < 8; i++) {
      const diEnable = snmpVersion === "snmpv2" ? document.getElementById('enable_' + i) : document.getElementById('enable_' + i + '_v3');
      // const diEnable = document.getElementById('enable_' + i).checked ? 1 : 0;

      payload.di[i] = {
        "diIndex": i,
        "diEnable": diEnable.checked ? 1 : 0,
      }

      if(snmpVersion === "snmpv2"){
        const diSpecificID = parseInt(document.getElementById('sid_' + i).value);
        if (diSpecificID < 0 || diSpecificID > 20) {
          customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
          throw new CustomError(customErrorProps);
        } else {
          payload.di[i].diSpecificID = diSpecificID;
        }
      }
    }
    // Set Relay (DO's)
    for (let i = 0; i < 4; i++) {
      const doEnable = snmpVersion === "snmpv2" ? document.getElementById('enable_' + (i + 8)) : document.getElementById('enable_' + (i + 8) + '_v3');
      // const doEnable = document.getElementById('enable_' + (i + 8)).checked ? 1 : 0;

      payload.do[i] = {
        "diIndex": i,
        "diEnable": doEnable.checked ? 1 : 0,
      }

      if(snmpVersion === "snmpv2"){
        const doSpecificID = parseInt(document.getElementById('sid_' + (i + 8)).value);

        if (doSpecificID < 0 || doSpecificID > 20) {
          customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
          throw new CustomError(customErrorProps);
        } else {
          payload.do[i].doSpecificID = doSpecificID;
        }
      }
    }
  }

  // setParams_8DI6DO2PWM(customErrorProps, payload) {
  //     // Set DI's
  //     for (let i = 0; i < 8; i++) {
  //       const diEnable = document.getElementById('enable_' + i).checked ? 1 : 0;
  //       const diSpecificID = parseInt(document.getElementById('sid_' + i).value);
  //       if (diSpecificID < 0 || diSpecificID > 20) {
  //         customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
  //         throw new CustomError(customErrorProps);
  //       }
  //       payload.di[i] = {
  //         "diIndex": i,
  //         "diEnable": diEnable,
  //         "diSpecificID": diSpecificID
  //       };
  //     }
  //     // Set DO's
  //     for (let i = 0; i < 6; i++) {
  //       const doEnable = document.getElementById('enable_' + (i + 8)).checked ? 1 : 0;
  //       const doSpecificID = parseInt(document.getElementById('sid_' + (i + 8)).value);
  //       if (doSpecificID < 0 || doSpecificID > 20) {
  //         customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
  //         throw new CustomError(customErrorProps);
  //       }
  //       payload.do[i] = {
  //         "doIndex": i,
  //         "doEnable": doEnable,
  //         "doSpecificID": doSpecificID
  //       };
  //     }
  // }
  // loadPage_8DI6DO2PWM(settings) {
  //     // Set descriptions
  //     document.getElementById('headDesc').innerHTML = '8DI6DO2PWM Trap Settings';
  //     document.getElementById('channel_a').innerHTML = 'Channel';
  //     document.getElementById('channel_b').innerHTML = 'Channel';
  
  //     const dis = settings.di;
  //     const dos = settings.do;
  //     for (let i = 0; i < 8; i++) {
  //       // Set all DI's
  //       document.getElementById('no_' + i).innerHTML = '' + (i + 1);
  //       const diEnable = document.getElementById('enable_' + i);
  //       const diSpecificID = document.getElementById('sid_' + i);
  //       const di = dis.find(e => e.diIndex == i);
  //       setDomProperty(diEnable, "checked", di?.diEnable === 1 ? true : false);
  //       setDomProperty(diSpecificID, "value", di?.diSpecificID);
  //     }
  //     for (let i = 0; i < 6; i++) {
  //       // Set all DO's
  //       document.getElementById('no_' + (i + 8)).innerHTML = '' + (i + 1);
  //       const doEnable = document.getElementById('enable_' + (i + 8));
  //       const doSpecificID = document.getElementById('sid_' + (i + 8));
  //       const ds = dos.find(e => e.doIndex == i); // Note: cannot use reserved keyword "do"
  //       setDomProperty(doEnable, "checked", ds?.doEnable === 1 ? true : false);
  //       setDomProperty(doSpecificID, "value", ds?.doSpecificID);
  //     }
  //     // Hide last 2 checkbox & inputs (2PWM)
  //     for (let i = 0; i < 2; i++) {
  //       const doEnable = document.getElementById('enable_' + (i + 14));
  //       const doSpecificID = document.getElementById('sid_' + (i + 14));
  //       doEnable.style.display = "none";
  //       doSpecificID.style.display = "none";
  //     }
  // }

  loadPage_8DI8DO(settings, snmpVersion) {
    // Set descriptions
    // document.getElementById('headDesc').innerHTML = '8DI8DO Trap Settings';
    snmpVersion === "snmpv2" ?document.getElementById('channel_a').innerHTML = 'Channel' : document.getElementById('channel_a_v3').innerHTML = 'Channel';
    snmpVersion === "snmpv2" ?document.getElementById('channel_b').innerHTML = 'Channel' : document.getElementById('channel_b_v3').innerHTML = 'Channel';
    
    const dis = settings.di;
    const dos = settings.do;
    for (let i = 0; i < 8; i++) {
      // Set all DI's
      snmpVersion === "snmpv2" ? document.getElementById('no_' + i).innerHTML = 'DI-0' + (i) : document.getElementById('no_' + i + '_v3').innerHTML = 'DI-0' + (i);
      let diEnable;
      snmpVersion === "snmpv2" ? diEnable = document.getElementById('enable_' + i) : diEnable = document.getElementById('enable_' + i + '_v3');
      const di = dis.find(e => e.diIndex == i);
      setDomProperty(diEnable, "checked", di?.diEnable === 1 ? true : false);
      setDisableSingleOrButton(diEnable);
      if(snmpVersion === "snmpv2"){
        const diSpecificID = document.getElementById('sid_' + i);
        setDomProperty(diSpecificID, "value", di?.diSpecificID);
        setDisableSingleOrButton(diSpecificID);
      }
    }
    for (let i = 0; i < 8; i++) {
      // Set all DO's
      snmpVersion === "snmpv2" ? document.getElementById('no_' + (i + 8)).innerHTML = 'DO-0' + (i) : document.getElementById('no_' + (i + 8) + '_v3').innerHTML = 'DO-0' + (i);
      let doEnable;
      snmpVersion === "snmpv2" ? doEnable = document.getElementById('enable_' + (i + 8)) : doEnable = document.getElementById('enable_' + (i + 8) + '_v3');
      const ds = dos.find(e => e.doIndex == i); // Note: cannot use reserved keyword "do"
      setDomProperty(doEnable, "checked", ds?.doEnable === 1 ? true : false);   
      setDisableSingleOrButton(doEnable);   
      if(snmpVersion === "snmpv2"){
        const doSpecificID = document.getElementById('sid_' + (i + 8));
        setDomProperty(doSpecificID, "value", ds?.doSpecificID);
        setDisableSingleOrButton(doSpecificID);
      }
    }
  }
  setParams_8DI8DO(customErrorProps, payload, snmpVersion) {
    // Set DI's
    for (let i = 0; i < 8; i++) {
      const diEnable = snmpVersion === "snmpv2" ? document.getElementById('enable_' + i) : document.getElementById('enable_' + i + '_v3');

      payload.di[i] = {
        "diIndex": i,
        "diEnable": diEnable.checked ? 1 : 0,
      };

      if(snmpVersion === "snmpv2"){
        const diSpecificID = parseInt(document.getElementById('sid_' + i).value);
        if (diSpecificID < 0 || diSpecificID > 20) {
          customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
          throw new CustomError(customErrorProps);
        } else {
          payload.di[i].diSpecificID = diSpecificID;
        }
      }
    }
    // Set DO's
    for (let i = 0; i < 8; i++) {
      const doEnable = snmpVersion === "snmpv2" ? document.getElementById('enable_' + (i + 8)) : document.getElementById('enable_' + (i + 8) + '_v3');
      
      payload.do[i] = {
        "doIndex": i,
        "doEnable": doEnable.checked ? 1 : 0,
      };

      if(snmpVersion === "snmpv2"){
        const doSpecificID = parseInt(document.getElementById('sid_' + (i + 8)).value);
        if (doSpecificID < 0 || doSpecificID > 20) {
          customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
          throw new CustomError(customErrorProps);
        } else {
          payload.do[i].doSpecificID = doSpecificID;
        }
      }
    }
  }

  loadPage_16DI(settings, snmpVersion) {
    // Set descriptions
    // document.getElementById('headDesc').innerHTML = '16DI Trap Settings';
    snmpVersion === "snmpv2" ?document.getElementById('channel_a').innerHTML = 'Channel' : document.getElementById('channel_a_v3').innerHTML = 'Channel';
    snmpVersion === "snmpv2" ?document.getElementById('channel_b').innerHTML = 'Channel' : document.getElementById('channel_b_v3').innerHTML = 'Channel';

    const dis = settings.di;
    for (let i = 0; i < 16; i++) {
      // Set all DI's
      if (snmpVersion === "snmpv2") {
        document.getElementById('no_' + i).innerHTML = i < 10 ? 'DI-0' + i : 'DI-' + i;
      } else {
        document.getElementById('no_' + i + '_v3').innerHTML = i < 10 ? 'DI-0' + i : 'DI-' + i;
      }
      let diEnable;
      snmpVersion === "snmpv2" ? diEnable = document.getElementById('enable_' + i) : diEnable = document.getElementById('enable_' + i + '_v3');
      const di = dis.find(e => e.diIndex == i);
      setDomProperty(diEnable, "checked", di?.diEnable === 1 ? true : false);
      setDisableSingleOrButton(diEnable);
      if (snmpVersion === "snmpv2"){
        const diSpecificID = document.getElementById('sid_' + i);
        setDomProperty(diSpecificID, "value", di?.diSpecificID);
        setDisableSingleOrButton(diSpecificID);
      }
    }
  }
  setParams_16DI(customErrorProps, payload, snmpVersion) {
    // Set DI's
    for (let i = 0; i < 16; i++) {
      const diEnable = snmpVersion === "snmpv2" ? document.getElementById('enable_' + i) : document.getElementById('enable_' + i + '_v3');

      payload.di[i] = {
        "diIndex": i,
        "diEnable": diEnable.checked ? 1 : 0,
      };

      if(snmpVersion === "snmpv2"){
        const diSpecificID = parseInt(document.getElementById('sid_' + i).value);
        if (diSpecificID < 0 || diSpecificID > 20) {
          customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
          throw new CustomError(customErrorProps);
        } else {
          payload.di[i].diSpecificID = diSpecificID;
        }
      }
    }
    // Remove the DO's
    delete payload.do;
  }

  loadPage_16DO(settings, snmpVersion) {
    // Set descriptions
    // document.getElementById('headDesc').innerHTML = '16DO Trap Settings';
    snmpVersion === "snmpv2" ?document.getElementById('channel_a').innerHTML = 'Channel' : document.getElementById('channel_a_v3').innerHTML = 'Channel';
    snmpVersion === "snmpv2" ?document.getElementById('channel_b').innerHTML = 'Channel' : document.getElementById('channel_b_v3').innerHTML = 'Channel';

    const dos = settings.do;
    for (let i = 0; i < 16; i++) {
      // Set all DO's
      if(snmpVersion === "snmpv2"){
        document.getElementById('no_' + i).innerHTML = i < 10 ? 'DO-0' + i : 'DO-' + i;
      } else {
        document.getElementById('no_' + i + '_v3').innerHTML = i < 10 ? 'DO-0' + i : 'DO-' + i;
      }
      let doEnable;
      snmpVersion === "snmpv2" ? doEnable = document.getElementById('enable_' + i) : doEnable = document.getElementById('enable_' + i + '_v3');
      const ds = dos.find(e => e.doIndex == i);
      setDomProperty(doEnable, "checked", ds?.doEnable === 1 ? true : false);
      setDisableSingleOrButton(doEnable);
      if(snmpVersion === "snmpv2"){
        const doSpecificID = document.getElementById('sid_' + i);
        setDomProperty(doSpecificID, "value", ds?.doSpecificID);
        setDisableSingleOrButton(doSpecificID);
      }
    }
  }
  setParams_16DO(customErrorProps, payload, snmpVersion) {
    // Set DO's
    for (let i = 0; i < 16; i++) {
      const doEnable = snmpVersion === "snmpv2" ? document.getElementById('enable_' + i) : document.getElementById('enable_' + i + '_v3');

      payload.do[i] = {
        "doIndex": i,
        "doEnable": doEnable.checked ? 1 : 0,
      };

      if(snmpVersion === "snmpv2"){
        const doSpecificID = parseInt(document.getElementById('sid_' + i).value);
        if (doSpecificID < 0 || doSpecificID > 20) {
          customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
          throw new CustomError(customErrorProps);
        } else {
          payload.do[i].doSpecificID = doSpecificID;
        }
      }
    }
    // Remove the DI's
    delete payload.di;
  }

  loadPage_8AI(settings, snmpVersion) {
    const snmpThead = snmpVersion === "snmpv2" ? document.getElementById('snmpThead') : document.getElementById('snmpv3Thead');
    const snmpTbody = snmpVersion === "snmpv2" ? document.getElementById('snmpTbody') : document.getElementById('snmpv3Tbody');;

    const aiGreater = settings.aiGreater;
    const aiLess = settings.aiLess;

    snmpThead.innerHTML = `
    <tr> 
      <th width="50px">
        <div id="channel_a">Channel</div>
      </th>
      <th width=${snmpVersion === "snmpv2" ? "11%" : "15%"}>Greater <br>Enable</th>
      <th width=${snmpVersion === "snmpv2" ? "13.5%" : "17%"}>Greater <br>Hysteresis</th>
      <th width=${snmpVersion === "snmpv2" ? "11%" : "15.5%"}>Greater <br>Value</th>
      ${snmpVersion === "snmpv2" ? `<th width="13.5%">Greater <br>Specific ID</th>` : ""}
      <th width=${snmpVersion === "snmpv2" ? "9%" : "13%"}>Less <br>Enable</th>
      <th width=${snmpVersion === "snmpv2" ? "11.5%" : "16%"}>Less <br>Hysteresis</th>
      <th width=${snmpVersion === "snmpv2" ? "9%" : "13%"}>Less <br>Value</th>
      ${snmpVersion === "snmpv2" ? `<th width="12.5%">Less <br>Specific ID</th>` : ""}
    </tr>`;

    snmpTbody.innerHTML = "";
    for(let i = 0; i < 8; i++) {
      const ai = aiGreater.find(e => e.aiIndex == i);
      const ai2 = aiLess.find(e => e.aiIndex == i);
      snmpTbody.innerHTML += `
        <tr>
          <td class="font-style">AI-0${i}</td>
          <td class="icon-style"><input type="checkbox" id="greaterEnable_${i}" ${ai?.aiEnable === 1 ? "checked" : ""} ></td>
          <td class="font-style"><input type="number" style="width:50px;" id="greaterHysteresis_${i}" value="${ai?.aiHysteresis}" ></td>
          <td class="font-style"><input type="number" style="width:50px;" id="greaterValue_${i}" value="${ai?.aiValue}" ></td>
          ${snmpVersion === "snmpv2" ? `<td class="font-style"><input type="number" style="width:50px;" id="greaterSpecificID_${i}" value="${ai?.aiSpecificID}" ></td>` : ""}
          <td class="icon-style"><input type="checkbox" id="lessEnable_${i}" ${ai2?.aiEnable === 1 ? "checked" : ""} ></td>
          <td class="font-style"><input type="number" style="width:50px;" id="lessHysteresis_${i}" value="${ai2?.aiHysteresis}" ></td>
          <td class="font-style"><input type="number" style="width:50px;" id="lessValue_${i}" value="${ai2?.aiValue}" ></td>
          ${snmpVersion === "snmpv2" ? `<td class="font-style"><input type="number" style="width:50px;" id="lessSpecificID_${i}" value="${ai2?.aiSpecificID}" ></td>` : ""}
        </tr>
      `;
    }
  }
  setParams_8AI(customErrorProps, payload, snmpVersion) {
    for(let i = 0; i < 8; i++) {
      const greaterEnable = document.getElementById('greaterEnable_' + i).checked ? 1 : 0;
      const greaterHysteresis = parseInt(document.getElementById('greaterHysteresis_' + i).value);
      const greaterValue = parseInt(document.getElementById('greaterValue_' + i).value);
      const lessEnable = document.getElementById('lessEnable_' + i).checked ? 1 : 0;
      const lessHysteresis = parseInt(document.getElementById('lessHysteresis_' + i).value);
      const lessValue = parseInt(document.getElementById('lessValue_' + i).value);
      
      payload.aiGreater[i] = {
        "aiIndex": i,
        "aiEnable": greaterEnable,
        "aiHysteresis": greaterHysteresis,
        "aiValue": greaterValue
      };
      payload.aiLess[i] = {
        "aiIndex": i,
        "aiEnable": lessEnable,
        "aiHysteresis": lessHysteresis,
        "aiValue": lessValue
      };
      if(greaterHysteresis < -10 || greaterHysteresis > 10 || lessHysteresis < -10 || lessHysteresis > 10){
        customErrorProps.data.error.message = "Hysteresis must be between 0 and 10";
        throw new CustomError(customErrorProps);
      }
      if(greaterValue < -10 || greaterValue > 10 || lessValue < -10 || lessValue > 10){
        customErrorProps.data.error.message = "Value must be between 0 and 10";
        throw new CustomError(customErrorProps);
      }
      if(snmpVersion === "snmpv2"){
        const greaterSpecificID = parseInt(document.getElementById('greaterSpecificID_' + i).value);
        const lessSpecificID = parseInt(document.getElementById('lessSpecificID_' + i).value);
        if(greaterSpecificID < 0 || greaterSpecificID > 20 || lessSpecificID < 0 || lessSpecificID > 20){
          customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
          throw new CustomError(customErrorProps);
        } else {
          payload.aiGreater[i].aiSpecificID = greaterSpecificID;
          payload.aiLess[i].aiSpecificID = lessSpecificID;
        }
      }
    }
    delete payload.di;
    delete payload.do;
  }

  // OPC UA
  loadOpcuaPage = async () => {
    const getOpcua = await Api.getOpcuaAgent();
    this.setOpcuaConfig(getOpcua);

    const opcuaSubmit = document.getElementById('opcuaSubmit');
    if(opcuaSubmit){
      opcuaSubmit.addEventListener('click', this.opcuaSubmit);
      setDisableSingleOrButton(opcuaSubmit);
    }
    const selectLoginType = document.getElementById('selectLoginType');
    if(selectLoginType){
      selectLoginType.addEventListener('change', this.switchOption);
      setDisableSingleOrButton(selectLoginType);
    }
    const download = document.getElementById('download');
    if(download){
      download.addEventListener('click', this.downloadCert, { once: true });
      
    }
  };

  setOpcuaConfig = (config) => {
    setValue(document.getElementById('username'), config.username);
    setValue(document.getElementById('password'), config.password);
     
    if(config.option === 0){
      document.getElementById('selectLoginType').selectedIndex = 0;
      // document.getElementById('anonymous').checked = true;
      this.setSelected(0);
    } else if (config.option === 1){
      document.getElementById('selectLoginType').selectedIndex = 1;
      // document.getElementById('named').checked = true;
      this.setSelected(1);
    } else if (config.option === 2){
      document.getElementById('selectLoginType').selectedIndex = 2;
      // document.getElementById('certificate').checked = true;
      this.setSelected(2);
    }
  }
  
  downloadCert = async() => {
    if(this.state.role !== "admin"){
      return;
    }
    const downloadCert = await Api.downloadCertFile();
    const certFileUrl = URL.createObjectURL(downloadCert);
    const a = document.createElement("a");
    a.href = certFileUrl;
    a.download = "server_cert.der";
    a.click();
    URL.revokeObjectURL(certFileUrl);

    const downloadKey = await Api.downloadKeyFile();
    const keyFileUrl = URL.createObjectURL(downloadKey);
    const a2 = document.createElement("a");
    a2.href = keyFileUrl;
    a2.download = "server_key.pem";
    a2.click();
    URL.revokeObjectURL(keyFileUrl);
  }

  switchOption = (e) => {
    const opcuaOption = parseInt(e.target.value);
    this.setSelected(opcuaOption);
  }

  setSelected = (opcuaOption) =>{
    const user = document.getElementById('user');
    const pass = document.getElementById('pass');
    const down = document.getElementById('down');

    if(opcuaOption === 0){
      user.style.display = "none";
      pass.style.display = "none";
      down.style.display = "none";
    } else if (opcuaOption === 1){
      user.style.display = "block";
      pass.style.display = "block";
      down.style.display = "none";
    } else if (opcuaOption === 2){
      user.style.display = "none";
      pass.style.display = "none";
      down.style.display = "block";
    }
  }

  opcuaSubmit = async(e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
        error: {
          message: ""
        }
      }
    };

    try {
      const selectLoginType = parseInt(document.getElementById('selectLoginType').value);
      // const opcuaOption = parseInt(document.querySelector('input[name="opcuaOption"]:checked').value);
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      if(selectLoginType === 1 && (username === "" || password === "")){
        customErrorProps.data.error.message = "Username and Password must be filled in";
        throw new CustomError(customErrorProps);
      }

      const payload = {
        option: selectLoginType,
        user: selectLoginType === 1 ? username : "",
        pass: selectLoginType === 1 ? password : "",
      }

      const res = await Api.editOpcuaAgent(payload);

      if(selectLoginType === 2) {

        const download = document.getElementById('download');
        download.addEventListener('click', async () => {
          const downloadCert = await Api.downloadCertFile();
          const certFileUrl = URL.createObjectURL(downloadCert);
          const a = document.createElement("a");
          a.href = certFileUrl;
          a.download = "server_cert.der";
          a.click();
          URL.revokeObjectURL(certFileUrl);

          const downloadKey = await Api.downloadKeyFile();
          const keyFileUrl = URL.createObjectURL(downloadKey);
          const a2 = document.createElement("a");
          a2.href = keyFileUrl;
          a2.download = "server_key.pem";
          a2.click();
          URL.revokeObjectURL(keyFileUrl);
        }, { once: true });
      }

      DialogUtility.showSuccess({
        text: res.error?.message,
      });

      this.loadOpcuaPage();
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  //mqtt
  loadMqttconPage = async () => {
    let mainstat = document.getElementById('displayMqttcon');
    let loadstat = document.getElementById('loadingMqttcon');
    try {
      const mqttConfigs = await Api.getMqttConfigs();
      console.log(mqttConfigs);
      this.state.mqttConfigs = mqttConfigs;
      mainstat.style.display = "block";
      loadstat.style.display = "none";
      const sslTlsInput = document.getElementById('sslTlsInput');
      const brokerIPInput = document.getElementById('brokerIPInput');
      const brokerPortInput = document.getElementById('brokerPortInput');
      const keepAliveInput = document.getElementById('keepAliveInput');
      const willTopicInput = document.getElementById('willTopicInput');
      const willMessageInput = document.getElementById('willMessageInput');
      const anonymousLoginInput = document.getElementById('anonymousLoginInput');
      const usernameInput = document.getElementById('usernameInput');
      const passwordInput = document.getElementById('passwordInput');

      setDomProperty(sslTlsInput, "checked", mqttConfigs.sslTls === 1 ? true : false);
      setDomProperty(brokerIPInput, "value", mqttConfigs.brokerIP);
      setDomProperty(brokerPortInput, "value", mqttConfigs.brokerPort);
      setDomProperty(keepAliveInput, "value", mqttConfigs.keepAlive);
      setDomProperty(willTopicInput, "value", mqttConfigs.willTopic);
      setDomProperty(willMessageInput, "value", mqttConfigs.willMessage);
      setDomProperty(anonymousLoginInput, "checked", mqttConfigs.anonymous === 1 ? true : false);
      setDomProperty(usernameInput, "value", mqttConfigs.username);
      setDomProperty(passwordInput, "value", mqttConfigs.password);
      setDisableSingleOrButton(sslTlsInput);
      setDisableSingleOrButton(brokerIPInput);
      setDisableSingleOrButton(brokerPortInput);
      setDisableSingleOrButton(keepAliveInput);
      setDisableSingleOrButton(willTopicInput);
      setDisableSingleOrButton(willMessageInput);
      setDisableSingleOrButton(anonymousLoginInput);
      
      if(mqttConfigs.anonymous === 1){
        usernameInput.disabled = true;
        passwordInput.disabled = true;
        setDisableSingleOrButton(usernameInput);
        setDisableSingleOrButton(passwordInput);
      } else {
        usernameInput.disabled = false;
        passwordInput.disabled = false;
        setDisableSingleOrButton(usernameInput);
        setDisableSingleOrButton(passwordInput);
      }

      anonymousLoginInput.addEventListener('change', () => {
        if(anonymousLoginInput.checked){
          usernameInput.disabled = true;
          passwordInput.disabled = true;
        } else {
          usernameInput.disabled = false;
          passwordInput.disabled = false;
        }
      });

      const navMqttconTab = document.getElementById('nav-mqttcon-tab');
      navMqttconTab.addEventListener('click', this.loadMqttconPage);
      const mqttconSubmitButton = document.getElementById('mqttconSubmitButton');
      mqttconSubmitButton.addEventListener('click', this.mqttconSubmit);
      setDisableSingleOrButton(mqttconSubmitButton);

      const navMqttcliTab = document.getElementById('nav-mqttcli-tab');
      navMqttcliTab.addEventListener('click', () => this.loadMqttcliPage(this.state.mqttConfigs));
    } catch (error) {
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  };

  loadMqttcliPage = async (mqttConfigs) => {
    let mainstat = document.getElementById('displayMqttcli');
    let loadstat = document.getElementById('loadingMqttcli');
    try {      
      if(mqttConfigs){
        mainstat.style.display = "block";
        loadstat.style.display = "none";
        
        const scanRatesInput = document.getElementById('scanRatesInput');
        const deadBandInput = document.getElementById('deadBandInput');

        const jsonFormatInput = document.getElementById('jsonFormatInput');
        const publishTopicInput = document.getElementById('publishTopicInput');
        const selectPublishQos = document.getElementById('selectPublishQos');
        const subscribeTopicInput = document.getElementById('subscribeTopicInput');
        const selectSubscribeQos = document.getElementById('selectSubscribeQos');
        const retainInput = document.getElementById('retainInput');
        const selectAuthentication = document.getElementById('selectAuthentication');
        setDomProperty(scanRatesInput, "value", mqttConfigs.scanRate);
        setDomProperty(deadBandInput, "value", mqttConfigs.deadBand);
        setDomProperty(jsonFormatInput, "checked", mqttConfigs.allJson === 1 ? true : false);
        setDomProperty(publishTopicInput, "value", mqttConfigs.allPubSUb.publishTopic);
        setDomProperty(selectPublishQos, "value", mqttConfigs.allPubSUb.publishQos);
        setDomProperty(subscribeTopicInput, "value", mqttConfigs.allPubSUb.subscribeTopic);
        setDomProperty(selectSubscribeQos, "value", mqttConfigs.allPubSUb.subscribeQos);
        setDomProperty(retainInput, "checked", mqttConfigs.allPubSUb.retained === 1 ? true : false);
        setDomProperty(selectAuthentication, "value", mqttConfigs.oneTwoWayAuth);
        setDisableSingleOrButton(scanRatesInput);
        setDisableSingleOrButton(deadBandInput);
        setDisableSingleOrButton(jsonFormatInput);
        setDisableSingleOrButton(publishTopicInput);
        setDisableSingleOrButton(selectPublishQos);
        setDisableSingleOrButton(subscribeTopicInput);
        setDisableSingleOrButton(selectSubscribeQos);
        setDisableSingleOrButton(retainInput);
        setDisableSingleOrButton(selectAuthentication);
        setDisableSingleOrButton(document.getElementById('awsRootCaFileBtn'));
        setDisableSingleOrButton(document.getElementById('awsCertificateFileBtn'));
        setDisableSingleOrButton(document.getElementById('awsPrivateKeyFileBtn'));

        const awsRootCaFileSelect = document.getElementById('awsRootCaFileSelect');
        const awsCertificateFileSelect = document.getElementById('awsCertificateFileSelect');
        const awsPrivateKeyFileSelect = document.getElementById('awsPrivateKeyFileSelect');
        const mqttcliSubmitButton = document.getElementById('mqttcliSubmitButton');
        const awsRootCaLastFileName = document.getElementById('awsRootCaLastFileName');
        const awsCertificateLastFileName = document.getElementById('awsCertificateLastFileName');
        const awsPrivateKeyLastFileName = document.getElementById('awsPrivateKeyLastFileName');

        awsRootCaFileSelect.onchange = this.uploadRootCaFile;
        awsCertificateFileSelect.onchange = this.uploadCertifiicateFile;
        awsPrivateKeyFileSelect.onchange = this.uploadPrivateKeyFile;

        const mqttcliTable = document.getElementById('mqttcliTable');
        const pubtopic = document.getElementById('pubtopic');
        const pubqos = document.getElementById('pubqos');
        const subtopic = document.getElementById('subtopic');
        const subqos = document.getElementById('subqos');
        const retain = document.getElementById('retain');

        this.initMqttcliTable(mqttConfigs.channelsPubSub);
        if(mqttConfigs.allJson === 0){
          mqttcliTable.style.display = 'block';
          pubtopic.style.display = 'none';
          pubqos.style.display = 'none';
          subtopic.style.display = 'none';
          subqos.style.display = 'none';
          retain.style.display = 'none';
        } else {
          mqttcliTable.style.display = 'none';
          pubtopic.style.display = 'block';
          pubqos.style.display = 'block';
          subtopic.style.display = 'block';
          subqos.style.display = 'block';
          retain.style.display = 'block';
        };

        jsonFormatInput.addEventListener('change', () => {
          if(jsonFormatInput.checked){
            mqttcliTable.style.display = 'none';
            pubtopic.style.display = 'block';
            pubqos.style.display = 'block';
            subtopic.style.display = 'block';
            subqos.style.display = 'block';
            retain.style.display = 'block';
          } else {
            mqttcliTable.style.display = 'block';
            pubtopic.style.display = 'none';
            pubqos.style.display = 'none';
            subtopic.style.display = 'none';
            subqos.style.display = 'none';
            retain.style.display = 'none';
          }
        });

        mqttcliSubmitButton.addEventListener('click', this.mqttcliSubmit);
        setDisableSingleOrButton(mqttcliSubmitButton);
        
        // update page

        setInnerHTML(awsRootCaLastFileName, `Last upload file name: ${mqttConfigs.rootCAFile}`);
        setInnerHTML(awsCertificateLastFileName, `Last upload file name: ${mqttConfigs.certificateFile}`);
        setInnerHTML(awsPrivateKeyLastFileName, `Last upload file name: ${mqttConfigs.privateKeyFile}`);

        if(mqttConfigs.rootCAFile)       { setStyle(awsRootCaLastFileName, 'display', 'block'); }
        if(mqttConfigs.certificateFile)  { setStyle(awsCertificateLastFileName, 'display', 'block'); }
        if(mqttConfigs.privateKeyFile)   { setStyle(awsPrivateKeyLastFileName, 'display', 'block'); }

        this.state.rootCaFileName = mqttConfigs.rootCAFile;
        this.state.certificateFileName = mqttConfigs.certificateFile;
        this.state.privateKeyFileName = mqttConfigs.privateKeyFile;

      };
    } catch (error) {
      ErrorUtility.handleError(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  };

  initMqttcliTable = (channelsPubSub) => {
    const mqttcliTbody = document.getElementById('mqttcliTbody');
    mqttcliTbody.innerHTML = "";
    if(this.state.modType === "16DI" || this.state.modType === "16DO"){
      for(let i = 0; i < 16; i++){
        const channel = this.state.modType === "16DI" 
        ? channelsPubSub?.di.find(item => item.index === i) 
        : channelsPubSub?.do.find(item => item.index === i);

        const row = document.createElement('tr');
        row.innerHTML += `
          <tr>
            <td class="font-style channel">${this.state.modType === "16DI" ? (i < 10 ? 'DI-0' + i : 'DI-' + i) : (i < 10 ? 'DO-0' + i : 'DO-' + i)}</td>
            <td class="font-style"><input type="text" id="pubTopic_${i}" value="${channel?.publishTopic}" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}></td>
            <td class="font-style">
              <select id="pubQos_${i}" style="width: 60px;" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}>
                <option value="0" ${channel?.publishQos === 0 ? "selected" : ""}>0</option>
                <option value="1" ${channel?.publishQos === 1 ? "selected" : ""}>1</option>
                <option value="2" ${channel?.publishQos === 2 ? "selected" : ""}>2</option>
              </select>
            </td>
            <td class="font-style"><input type="text" id="subTopic_${i}" value="${channel?.subscribeTopic}" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}></td>
            <td class="font-style">
              <select id="subQos_${i}" style="width: 60px;" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}>
                <option value="0" ${channel?.subscribeQos === 0 ? "selected" : ""}>0</option>
                <option value="1" ${channel?.subscribeQos === 1 ? "selected" : ""}>1</option>
                <option value="2" ${channel?.subscribeQos === 2 ? "selected" : ""}>2</option>
              </select>
            </td>
            <td class="icon-style"><input type="checkbox" id="retain_${i}" ${channel?.retained === 1 ? "checked" : ""} ${this.state.role === "admin" ? "" : "disabled"}></td>
          </tr>
        `;
        mqttcliTbody.appendChild(row);
      }
    } else if(this.state.modType === "8DI8DO" || this.state.modType === "8DI4RELAY"){
      for(let i = 0; i < 8; i++){
        const channel = channelsPubSub?.di.find(item => item.index === i);
        const row = document.createElement('tr');
        row.innerHTML += `
          <tr>
            <td class="font-style channel">${'DI-0' + i }</td>
            <td class="font-style"><input type="text" id="pubTopic_${i}" value="${channel?.publishTopic}" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}></td>
            <td class="font-style"> 
              <select id="pubQos_${i}" style="width: 60px;" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}>
                <option value="0" ${channel?.publishQos === 0 ? "selected" : ""}>0</option>
                <option value="1" ${channel?.publishQos === 1 ? "selected" : ""}>1</option>
                <option value="2" ${channel?.publishQos === 2 ? "selected" : ""}>2</option>
              </select>
            </td> 
            <td class="font-style"><input type="text" id="subTopic_${i}" value="${channel?.subscribeTopic}" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}></td>
            <td class="font-style">
              <select id="subQos_${i}" style="width: 60px;" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}>
                <option value="0" ${channel?.subscribeQos === 0 ? "selected" : ""}>0</option>
                <option value="1" ${channel?.subscribeQos === 1 ? "selected" : ""}>1</option>
                <option value="2" ${channel?.subscribeQos === 2 ? "selected" : ""}>2</option>
              </select>
            </td>
            <td class="icon-style"><input type="checkbox" id="retain_${i}" ${channel?.retained === 1 ? "checked" : ""} ${this.state.role === "admin" ? "" : "disabled"}></td>
          </tr>
        `;
        mqttcliTbody.appendChild(row);
      }
      for(let i = 0; i < this.state.outputCH; i++){
        const channel = channelsPubSub?.do.find(item => item.index === i);
        const row = document.createElement('tr');
        row.innerHTML += `
          <tr>
            <td class="font-style channel">${this.state.modType === "8DI8DO" ? 'DO-0' + i : 'Relay-0' + i}</td>
            <td class="font-style"><input type="text" id="pubTopic_${i + 8}" value="${channel?.publishTopic}" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}></td>
            <td class="font-style">
              <select id="pubQos_${i + 8}" style="width: 60px;" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}>
                <option value="0" ${channel?.publishQos === 0 ? "selected" : ""}>0</option>
                <option value="1" ${channel?.publishQos === 1 ? "selected" : ""}>1</option>
                <option value="2" ${channel?.publishQos === 2 ? "selected" : ""}>2</option>
              </select>
            </td>
            <td class="font-style"><input type="text" id="subTopic_${i + 8}" value="${channel?.subscribeTopic}" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}></td>
            <td class="font-style">
              <select id="subQos_${i + 8}" style="width: 60px;" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}>
                <option value="0" ${channel?.subscribeQos === 0 ? "selected" : ""}>0</option>
                <option value="1" ${channel?.subscribeQos === 1 ? "selected" : ""}>1</option>
                <option value="2" ${channel?.subscribeQos === 2 ? "selected" : ""}>2</option>
              </select>
            </td>
            <td class="icon-style"><input type="checkbox" id="retain_${i + 8}" ${channel?.retained === 1 ? "checked" : ""} ${this.state.role === "admin" ? "" : "disabled"}></td>
          </tr>
        `;
        mqttcliTbody.appendChild(row);
      }

    } else if(this.state.modType === "8AI" || this.state.modType === "8AO"){
      for(let i = 0; i < 8; i++){
        const channel = channelsPubSub?.ai.find(item => item.index === i);
        const row = document.createElement('tr');
        row.innerHTML += `
          <tr>
            <td class="font-style channel">${this.state.modType === "8AI" ? 'AI-0' + i : 'AO-0' + i}</td>
            <td class="font-style"><input type="text" id="pubTopic_${i}" value="${channel?.publishTopic}" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}></td>
            <td class="font-style">
              <select id="pubQos_${i}" style="width: 60px;" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}>
                <option value="0" ${channel?.publishQos === 0 ? "selected" : ""}>0</option>
                <option value="1" ${channel?.publishQos === 1 ? "selected" : ""}>1</option>
                <option value="2" ${channel?.publishQos === 2 ? "selected" : ""}>2</option>
              </select>
            </td>
            <td class="font-style"><input type="text" id="subTopic_${i}" value="${channel?.subscribeTopic}" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}></td>
            <td class="font-style">
              <select id="subQos_${i}" style="width: 60px;" style="width: 250px;" ${this.state.role === "admin" ? "" : "disabled"}>
                <option value="0" ${channel?.subscribeQos === 0 ? "selected" : ""}>0</option>
                <option value="1" ${channel?.subscribeQos === 1 ? "selected" : ""}>1</option>
                <option value="2" ${channel?.subscribeQos === 2 ? "selected" : ""}>2</option>
              </select>
            </td>
            <td class="icon-style"><input type="checkbox" id="retain_${i}" ${channel?.retained === 1 ? "checked" : ""} ${this.state.role === "admin" ? "" : "disabled"}></td>
          </tr>
        `;
        mqttcliTbody.appendChild(row);
      }
    }

  };

  mqttconSubmit = async(e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };
    try {
      const brokerIPInput = document.getElementById('brokerIPInput');
      const brokerPortInput = document.getElementById('brokerPortInput');
      const keepAliveInput = document.getElementById('keepAliveInput');
      const willTopicInput = document.getElementById('willTopicInput');
      const willMessageInput = document.getElementById('willMessageInput');
      const anonymousLoginInput = document.getElementById('anonymousLoginInput');
      const usernameInput = document.getElementById('usernameInput');
      const passwordInput = document.getElementById('passwordInput');
      
      if(!brokerIPInput.value || !brokerPortInput.value || !keepAliveInput.value){
        customErrorProps.data.error.message = "Broker IP, Broker Port, and Keep Alive must be filled in";
        throw new CustomError(customErrorProps);
      }
      if(!anonymousLoginInput.checked && (usernameInput.value === "" || passwordInput.value === "")){
        customErrorProps.data.error.message = "Username and Password must be empty";
        throw new CustomError(customErrorProps);
      }

      let payload = this.state.mqttConfigs;
      payload.sslTls = document.getElementById('sslTlsInput').checked ? 1 : 0;
      payload.brokerIP = brokerIPInput.value;
      payload.brokerPort = parseInt(brokerPortInput.value);
      payload.keepAlive = parseInt(keepAliveInput.value);
      payload.willTopic = willTopicInput.value;
      payload.willMessage = willMessageInput.value;
      payload.anonymous = anonymousLoginInput.checked ? 1 : 0;
      payload.username = anonymousLoginInput.checked ? "" : usernameInput.value;
      payload.password = anonymousLoginInput.checked ? "" : passwordInput.value;
      console.log(payload);
      const res = await Api.editMqttConfigs(payload);
      if(res?.error){
        customErrorProps.data.error.message = res.error;
        throw new CustomError(customErrorProps);
      } else {
        DialogUtility.showSuccess({
          text: 'success',
        });
        this.loadMqttconPage();
      }
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  uploadRootCaFile = async() => {
    try {
      const awsRootCaFileSelectSuccessText = document.getElementById('awsRootCaFileSelectSuccessText');
      const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');
  
      setInnerHTML(awsRootCaFileSelectErrorText, "");
      setInnerHTML(awsRootCaFileSelectSuccessText, "");
  
      const awsRootCaFileSelect = document.getElementById('awsRootCaFileSelect');
      const file = awsRootCaFileSelect.files[0];
      const res = await this._uploadFile(file);
      this.state.rootCaFileName = file.name;
  
      setInnerHTML(awsRootCaFileSelectSuccessText, "Upload File Success!");
    } catch(error) {
      const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');
      setInnerHTML(awsRootCaFileSelectErrorText, "Upload File Failed");
    }
  }

  uploadCertifiicateFile = async() => {
    try {
      const awsCertificateFileSelectSuccessText = document.getElementById('awsCertificateFileSelectSuccessText');
      const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');
  
      setInnerHTML(awsCertificateFileSelectErrorText, "");
      setInnerHTML(awsCertificateFileSelectSuccessText, "");
  
      const awsCertificateFileSelect = document.getElementById('awsCertificateFileSelect');
      const file = awsCertificateFileSelect.files[0];
      const res = await this._uploadFile(file);
      this.state.certificateFileName = file.name;
  
      setInnerHTML(awsCertificateFileSelectSuccessText, "Upload File Success!");
    } catch(error) {
      const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');
      setInnerHTML(awsCertificateFileSelectErrorText, "Upload File Failed");
    }
  }

  uploadPrivateKeyFile = async() => {
    try {
      const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
      const awsPrivateKeyFileSelectSuccessText = document.getElementById('awsPrivateKeyFileSelectSuccessText');
      setInnerHTML(awsPrivateKeyFileSelectErrorText, "");
      setInnerHTML(awsPrivateKeyFileSelectSuccessText, "");
  
      const awsPrivateKeyFileSelect = document.getElementById('awsPrivateKeyFileSelect');
      const file = awsPrivateKeyFileSelect.files[0];
      const res = await this._uploadFile(file);
      this.state.privateKeyFileName = file.name;
  
      setInnerHTML(awsPrivateKeyFileSelectSuccessText, "Upload File Success!");
    } catch(error) {
      const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
      setInnerHTML(awsPrivateKeyFileSelectErrorText, "Upload File Failed");
    }
  }

  _uploadFile = async(file) => {
    await Api.uploadFile(file, "upload");
  }

  mqttcliSubmit = async(e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };
    try {
      this.mqttClearAllHints();
  
      const {
        rootCaFileName,
        certificateFileName,
        privateKeyFileName,
      } = this.state;

      const scanRatesInput = document.getElementById('scanRatesInput');
      const deadBandInput = document.getElementById('deadBandInput');
      const jsonFormatInput = document.getElementById('jsonFormatInput');
      const publishTopicInput = document.getElementById('publishTopicInput');
      const selectPublishQos = document.getElementById('selectPublishQos');
      const subscribeTopicInput = document.getElementById('subscribeTopicInput');
      const selectSubscribeQos = document.getElementById('selectSubscribeQos');
      const retainInput = document.getElementById('retainInput');
      const sslTlsInput = document.getElementById('sslTlsInput');
      const selectAuthentication = document.getElementById('selectAuthentication');

      // const awsRootCaFileSelect_elem = document.getElementById('awsRootCaFileSelect');
      // const awsCertificateFileSelect_elem = document.getElementById('awsCertificateFileSelect');
      // const awsPrivateKeyFileSelect_elem = document.getElementById('awsPrivateKeyFileSelect');

      if(!scanRatesInput.value || !deadBandInput.value){
        customErrorProps.data.error.message = "Scan Rates and Dead Band must be filled in";
        throw new CustomError(customErrorProps);
      }
      if(sslTlsInput.checked && (!rootCaFileName || !certificateFileName || !privateKeyFileName)){
        customErrorProps.data.error.message = "In SSL/TLS mode, Root CA, Certificate, and Private Key must be uploaded";
        throw new CustomError(customErrorProps);
      }
      
      let payload = this.state.mqttConfigs;
      payload.scanRate = parseInt(scanRatesInput.value);
      payload.deadBand = parseInt(deadBandInput.value);
      payload.allJson = jsonFormatInput.checked ? 1 : 0;
      payload.channelsPubSub.di = [];
      payload.channelsPubSub.do = [];
      payload.channelsPubSub.ai = [];
      payload.channelsPubSub.ao = [];
      if(jsonFormatInput.checked){
        payload.allPubSUb.publishTopic = publishTopicInput.value;
        payload.allPubSUb.publishQos = parseInt(selectPublishQos.value);
        payload.allPubSUb.subscribeTopic = subscribeTopicInput.value;
        payload.allPubSUb.subscribeQos = parseInt(selectSubscribeQos.value);
        payload.allPubSUb.retained = retainInput.checked ? 1 : 0;
      } else if(!jsonFormatInput.checked && this.state.modType === "16DI" || this.state.modType === "16DO"){
        for(let i = 0; i < 16; i++){
          const pubTopic = document.getElementById(`pubTopic_${i}`).value;
          const pubQos = parseInt(document.getElementById(`pubQos_${i}`).value);
          const subTopic = document.getElementById(`subTopic_${i}`).value;
          const subQos = parseInt(document.getElementById(`subQos_${i}`).value);
          const retain = document.getElementById(`retain_${i}`).checked ? 1 : 0;
          this.state.modType === "16DI" 
          ?
            payload.channelsPubSub.di.push({
              index: i,
              publishTopic: pubTopic,
              publishQos: pubQos,
              subscribeTopic: subTopic,
              subscribeQos: subQos,
              retained: retain,
            })
          :
            payload.channelsPubSub.do.push({
              index: i,
              publishTopic: pubTopic,
              publishQos: pubQos,
              subscribeTopic: subTopic,
              subscribeQos: subQos,
              retained: retain,
            });
        }
      } else if(!jsonFormatInput.checked && this.state.modType === "8DI8DO" || this.state.modType === "8DI4RELAY"){
        for(let i = 0; i < 8; i++){
          const pubTopic = document.getElementById(`pubTopic_${i}`).value;
          const pubQos = parseInt(document.getElementById(`pubQos_${i}`).value);
          const subTopic = document.getElementById(`subTopic_${i}`).value;
          const subQos = parseInt(document.getElementById(`subQos_${i}`).value);
          const retain = document.getElementById(`retain_${i}`).checked ? 1 : 0;
          payload.channelsPubSub.di.push({
            index: i,
            publishTopic: pubTopic,
            publishQos: pubQos,
            subscribeTopic: subTopic,
            subscribeQos: subQos,
            retained: retain,
          });
        }
        for(let i = 0; i < this.state.outputCH; i++){
          const pubTopic = document.getElementById(`pubTopic_${i + 8}`).value;
          const pubQos = parseInt(document.getElementById(`pubQos_${i + 8}`).value);
          const subTopic = document.getElementById(`subTopic_${i + 8}`).value;
          const subQos = parseInt(document.getElementById(`subQos_${i + 8}`).value);
          const retain = document.getElementById(`retain_${i + 8}`).checked ? 1 : 0;
          payload.channelsPubSub.do.push({
            index: i,
            publishTopic: pubTopic,
            publishQos: pubQos,
            subscribeTopic: subTopic,
            subscribeQos: subQos,
            retained: retain,
          });
        }
      } else if(!jsonFormatInput.checked && this.state.modType === "8AI" || this.state.modType === "8AO"){
        for(let i = 0; i < 8; i++){
          const pubTopic = document.getElementById(`pubTopic_${i}`).value;
          const pubQos = parseInt(document.getElementById(`pubQos_${i}`).value);
          const subTopic = document.getElementById(`subTopic_${i}`).value;
          const subQos = parseInt(document.getElementById(`subQos_${i}`).value);
          const retain = document.getElementById(`retain_${i}`).checked ? 1 : 0;
          this.state.modType === "8AI" 
          ? 
            payload.channelsPubSub.ai.push({
              index: i,
              publishTopic: pubTopic,
              publishQos: pubQos,
              subscribeTopic: subTopic,
              subscribeQos: subQos,
              retained: retain,
            })
          :
            payload.channelsPubSub.ao.push({
              index: i,
              publishTopic: pubTopic,
              publishQos: pubQos,
              subscribeTopic: subTopic,
              subscribeQos: subQos,
              retained: retain,
            });
        }
      }
      payload.oneTwoWayAuth = parseInt(selectAuthentication.value);
      payload.rootCAFile = rootCaFileName;
      payload.certificateFile = certificateFileName;
      payload.privateKeyFile = privateKeyFileName;
      console.log(payload);
      const res = await Api.editMqttConfigs(payload);
      if(res?.error){
        customErrorProps.data.error.message = res.error;
        throw new CustomError(customErrorProps);
      } else {
        DialogUtility.showSuccess({
            text: 'success',
        });
        this.loadMqttconPage();
      }
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  mqttClearAllHints = () => {
    const awsRootCaFileSelectSuccessText = document.getElementById('awsRootCaFileSelectSuccessText');
    setInnerHTML(awsRootCaFileSelectSuccessText, "");
    const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');
    setInnerHTML(awsRootCaFileSelectErrorText, "");

    const awsCertificateFileSelectSuccessText = document.getElementById('awsCertificateFileSelectSuccessText');
    setInnerHTML(awsCertificateFileSelectSuccessText, "");
    const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');
    setInnerHTML(awsCertificateFileSelectErrorText, "");
    
    const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
    setInnerHTML(awsPrivateKeyFileSelectErrorText, "");
    const awsPrivateKeyFileSelectSuccessText = document.getElementById('awsPrivateKeyFileSelectSuccessText');
    setInnerHTML(awsPrivateKeyFileSelectSuccessText, "");
  }

  dispose(){
    const plSubmit = document.getElementById("plSubmit");
    plSubmit.removeEventListener('click', this.plSubmit);
    const mqttconSubmitButton = document.getElementById('mqttconSubmitButton');
    mqttconSubmitButton.removeEventListener('click', this.mqttconSubmit);
    const mqttcliSubmitButton = document.getElementById('mqttcliSubmitButton');
    mqttcliSubmitButton.removeEventListener('click', this.mqttcliSubmit);
    this.mqttClearAllHints();
  }
}
