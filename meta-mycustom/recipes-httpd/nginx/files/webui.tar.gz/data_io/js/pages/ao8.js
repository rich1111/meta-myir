/**
 * For module 8
 */
class Ao8Page {
  constructor(props) {
    this.state = {
      refereshTime: 1000,
      intervalId: undefined,
      board: [],
    };

    this.init();
  }

  init = async () => {
    this.initIntervalSelect();
    this.initButtons();
    this.loadPage();
  }

  initIntervalSelect = () => {
    const refreshSelect = document.getElementById("refresh");
    const {
      refereshTime,
    } = this.state;

    refreshSelect.addEventListener('click', this.onRefreshClick);
  }

  initButtons = () => {
    const saveButton = document.getElementById("AOSave");
    saveButton.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const payload = {
          "io": {
            "ao": [
              {
                "aoIndex": 0,
                "aoMode": 0,
                "aoValueScaled": 0,
                "aoDefaultEnable": 0,
                "aoDefaultMode": 0,
                "aoDefaultValueScaled": 0
              },
            ]
          },
          "slot": 0
        };

        for (let i = 0; i < 8; i++) {
          const aoMode = document.getElementById('aoMode_' + i);
          const aoValueScaled = document.getElementById('aoValueScaled_' + i);

          const aoDefaultMode = document.getElementById('aoDefaultMode_' + i);
          const aoDefaultEnable = document.getElementById('aoDefaultEnable_' + i);
          const aoDefaultValueScaled = document.getElementById('aoDefaultValueScaled_' + i);

          if (
            aoValueScaled == null ||
            aoDefaultValueScaled == null
          ) {
            continue;
          }

          const aoModeValue = parseInt(aoMode.value)
          const aoValueScaledValue = parseFloat(aoValueScaled.value);

          const aoDefaultModeValue = parseInt(aoDefaultMode.value)
          const aoDefaultEnableValue = aoDefaultEnable.checked ? 1 : 0;
          const aoDefaultValueScaledValue = parseFloat(aoDefaultValueScaled.value);

          if (
            isNaN(aoValueScaledValue) ||
            isNaN(aoDefaultValueScaledValue)
          ) {
            customErrorProps.data.error.message = `Please enter valid number for Channel ${i + 1}`;
            throw new CustomError(customErrorProps);
          }

          // If aoModeValue is 0, then it's voltage, otherwise it's current
          if (aoModeValue == 0 && (aoValueScaledValue < 0 || aoValueScaledValue > 10 || aoDefaultValueScaledValue < 0 || aoDefaultValueScaledValue > 10)) {
            // 電壓
            customErrorProps.data.error.message = `Voltage for Channel ${i + 1} must between 0 and 10`;
            throw new CustomError(customErrorProps);
          } else if (aoModeValue == 2 && (aoValueScaledValue < 0 || aoValueScaledValue > 20 || aoDefaultValueScaledValue < 0 || aoDefaultValueScaledValue > 20)) {
            // 電流
            customErrorProps.data.error.message = `Current for Channel ${i + 1} must between 0 and 20`;
            throw new CustomError(customErrorProps);
          }

          payload.io.ao[i] = {
            "aoIndex": i,
            "aoMode": aoModeValue,
            "aoValueScaled": aoValueScaledValue,
            "aoDefaultEnable": aoDefaultEnableValue,
            "aoDefaultMode": aoDefaultModeValue,
            "aoDefaultValueScaled": aoDefaultValueScaledValue,
          };
        }
        const res = await Api.editAnalogOutput(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
        this.loadPage();
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

  onRefreshClick = (e) => {
    e.preventDefault();
    this.loadPage();
  }

  loadPage = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    try {
      const analogOutputs = (await Api.getAnalogOutput()).io.ao;

      if (mainstat == null || loadstat == null) {
        return;
      }

      // Make sure we're displaying the status display
      mainstat.style.display = 'inline';
      loadstat.style.display = 'none';

      for (let i = 0; i < 8; i++) {
        const aoValueScaled = document.getElementById('aoValueScaled_' + i);
        const aoValueRaw = document.getElementById('aoValueRaw_' + i);
        const aoMode = document.getElementById('aoMode_' + i);
        const aoModeShow = document.getElementById('aoModeShow_' + i);
        const aoDefaultEnable = document.getElementById('aoDefaultEnable_' + i);
        const aoDefaultValueScaled = document.getElementById('aoDefaultValueScaled_' + i);
        const aoDefaultMode = document.getElementById('aoDefaultMode_' + i);

        const output = analogOutputs.filter((e) => e.aoIndex == i)[0];

        aoMode.value = output?.aoMode;
        setInnerHTML(aoValueRaw, "#" + output?.aoValueRaw?.toString(16));
        aoValueScaled.value = output?.aoValueScaled;
        aoDefaultMode.value = output?.aoDefaultMode;
        aoDefaultValueScaled.value = output?.aoDefaultValueScaled;
        if (output?.aoMode == 0) {
          setInnerHTML(aoModeShow, "V");
        } else {
          setInnerHTML(aoModeShow, "mA");
        }
        if (output?.aoDefaultEnable == 1) {
          setDomProperty(aoDefaultEnable, "checked", true);
        } else {
          setDomProperty(aoDefaultEnable, "checked", false);
        }
      }
      const lastUpdateTime = document.getElementById("lastUpdateTime");
      const now = (new Date()).toUTCString();
      setInnerText(lastUpdateTime, now);
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  dispose() {
    const refreshSelect = document.getElementById("refresh");
    refreshSelect.removeEventListener('click', this.onRefreshClick);
  }
}
