/**
 * For All Modules
 */
class AwsPage {
  constructor(props) {
    this.state = {
      rootCaFileName: null,
      certificateFileName: null,
      privateKeyFileName: null,
    };
    this.init();
  }

  init = async() => {
    const awsEnableCheck = document.getElementById('awsEnableCheck');
    const awsHostInput = document.getElementById('awsHostInput');
    //const awsPortInput = document.getElementById('awsPortInput'); // port 固定為 8883 不需要設定
    const awsTopicInput = document.getElementById('awsTopicInput');
    const awsClientIdInput = document.getElementById('awsClientIdInput');
    const awsMyThingNameInput = document.getElementById('awsMyThingNameInput');
    const awsRootCaFileSelect = document.getElementById('awsRootCaFileSelect');
    const awsCertificateFileSelect = document.getElementById('awsCertificateFileSelect');
    const awsPrivateKeyFileSelect = document.getElementById('awsPrivateKeyFileSelect');
    const awsSubmitButton = document.getElementById('awsSubmitButton');

    const awsRootCaLastFileName = document.getElementById('awsRootCaLastFileName');
    const awsCertificateLastFileName = document.getElementById('awsCertificateLastFileName');
    const awsPrivateKeyLastFileName = document.getElementById('awsPrivateKeyLastFileName');

    awsRootCaFileSelect.onchange = this.uploadRootCaFile;
    awsCertificateFileSelect.onchange = this.uploadCertifiicateFile;
    awsPrivateKeyFileSelect.onchange = this.uploadPrivateKeyFile;

    awsSubmitButton.addEventListener('click', this.submit);

    // load data
    const awsIot = (await Api.getAwsConfigs()).sysInfo.awsiot;

    // update page
    const connectionStatusField = document.getElementById('connectionStatusField');
    setInnerHTML(connectionStatusField, awsIot.connectionStatus ? 'Connected' : 'Disconnected' ); // 1 for connected, 0 for disconnected
    setDomProperty(awsEnableCheck, "checked", awsIot.awsiotEnable ? true : false);
    setDomProperty(awsHostInput, "value", awsIot.targetHost);
    setDomProperty(awsTopicInput, "value", awsIot.topic);
    setDomProperty(awsClientIdInput, "value", awsIot.clientID);
    setDomProperty(awsMyThingNameInput, "value", awsIot.thingName);

    setInnerHTML(awsRootCaLastFileName, `Last upload file name: ${awsIot.rootCAFile}`);
    setInnerHTML(awsCertificateLastFileName, `Last upload file name: ${awsIot.certificateFile}`);
    setInnerHTML(awsPrivateKeyLastFileName, `Last upload file name: ${awsIot.privateKeyFile}`);

    if(awsIot.rootCAFile)       { setStyle(awsRootCaLastFileName, 'display', 'block'); }
    if(awsIot.certificateFile)  { setStyle(awsCertificateLastFileName, 'display', 'block'); }
    if(awsIot.privateKeyFile)   { setStyle(awsPrivateKeyLastFileName, 'display', 'block'); }

    this.state.rootCaFileName = awsIot.rootCAFile;
    this.state.certificateFileName = awsIot.certificateFile;
    this.state.privateKeyFileName = awsIot.privateKeyFile;
  }

  uploadRootCaFile = async() => {
    try {
      const awsRootCaFileSelectSuccessText = document.getElementById('awsRootCaFileSelectSuccessText');
      const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');

      setInnerHTML(awsRootCaFileSelectErrorText, "");
      setInnerHTML(awsRootCaFileSelectSuccessText, "");

      const awsRootCaFileSelect = document.getElementById('awsRootCaFileSelect');
      console.log(awsRootCaFileSelect);
      const file = awsRootCaFileSelect.files[0];
      const res = await this._uploadFile(file);
      this.state.rootCaFileName = file.name;

      setInnerHTML(awsRootCaFileSelectSuccessText, "Upload File Success!");
    } catch(error) {
      const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');
      setInnerHTML(awsRootCaFileSelectErrorText, "Upload File Failed");
    }
  }

  uploadCertifiicateFile = async() => {
    try {

      const awsCertificateFileSelectSuccessText = document.getElementById('awsCertificateFileSelectSuccessText');
      const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');

      setInnerHTML(awsCertificateFileSelectErrorText, "");
      setInnerHTML(awsCertificateFileSelectSuccessText, "");

      const awsCertificateFileSelect = document.getElementById('awsCertificateFileSelect');
      const file = awsCertificateFileSelect.files[0];
      const res = await this._uploadFile(file);
      this.state.certificateFileName = file.name;

      setInnerHTML(awsCertificateFileSelectSuccessText, "Upload File Success!");
    } catch(error) {
      const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');
      setInnerHTML(awsCertificateFileSelectErrorText, "Upload File Failed");
    }
  }

  uploadPrivateKeyFile = async() => {
    try {
      const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
      const awsPrivateKeyFileSelectSuccessText = document.getElementById('awsPrivateKeyFileSelectSuccessText');
      setInnerHTML(awsPrivateKeyFileSelectErrorText, "");
      setInnerHTML(awsPrivateKeyFileSelectSuccessText, "");

      const awsPrivateKeyFileSelect = document.getElementById('awsPrivateKeyFileSelect');
      const file = awsPrivateKeyFileSelect.files[0];
      const res = await this._uploadFile(file);
      this.state.privateKeyFileName = file.name;

      setInnerHTML(awsPrivateKeyFileSelectSuccessText, "Upload File Success!");
    } catch(error) {
      const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
      setInnerHTML(awsPrivateKeyFileSelectErrorText, "Upload File Failed");
    }
  }

  _uploadFile = async(file) => {
    await Api.uploadFile(file);
  }

  submit = async(event) => {
    event.preventDefault();
    try {
      this.clearAllHints();

      const {
        rootCaFileName,
        certificateFileName,
        privateKeyFileName,
      } = this.state;
  
      const awsEnableCheck_elem = document.getElementById('awsEnableCheck');
      const awsHostInput_elem = document.getElementById('awsHostInput');
      //const awsPortInput_elem = document.getElementById('awsPortInput');
      const awsTopicInput_elem = document.getElementById('awsTopicInput');
      const awsClientIdInput_elem = document.getElementById('awsClientIdInput');
      const awsMyThingNameInput_elem = document.getElementById('awsMyThingNameInput');
      const awsRootCaFileSelect_elem = document.getElementById('awsRootCaFileSelect');
      const awsCertificateFileSelect_elem = document.getElementById('awsCertificateFileSelect');
      const awsPrivateKeyFileSelect_elem = document.getElementById('awsPrivateKeyFileSelect');
  
      const awsEnableCheck = awsEnableCheck_elem.checked ? 1 : 0;
      const connectionState = 1; // TODO: How to get?
      const awsHostInput = awsHostInput_elem.value;
      //const awsPortInput = awsPortInput_elem.value;
      const awsTopicInput = awsTopicInput_elem.value;
      const awsClientIdInput = awsClientIdInput_elem.value;
      const awsMyThingNameInput = awsMyThingNameInput_elem.value;
  
      await Api.editAwsConfigs({
        // below inputs types: number (0 or 1)
        awsiotEnable: awsEnableCheck,
        connectionStatus: connectionState,
        // below inputs types: string
        targetHost: awsHostInput,
        topic: awsTopicInput,
        clientID: awsClientIdInput,
        thingName: awsMyThingNameInput,
        rootCAFile: rootCaFileName,
        certificateFile: certificateFileName,
        privateKeyFile: privateKeyFileName,
      });

      DialogUtility.showSuccess({
        text: 'success',
      });
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  clearAllHints = () => {
    const awsRootCaFileSelectSuccessText = document.getElementById('awsRootCaFileSelectSuccessText');
    setInnerHTML(awsRootCaFileSelectSuccessText, "");
    const awsRootCaFileSelectErrorText = document.getElementById('awsRootCaFileSelectErrorText');
    setInnerHTML(awsRootCaFileSelectErrorText, "");

    const awsCertificateFileSelectSuccessText = document.getElementById('awsCertificateFileSelectSuccessText');
    setInnerHTML(awsCertificateFileSelectSuccessText, "");
    const awsCertificateFileSelectErrorText = document.getElementById('awsCertificateFileSelectErrorText');
    setInnerHTML(awsCertificateFileSelectErrorText, "");
    
    const awsPrivateKeyFileSelectErrorText = document.getElementById('awsPrivateKeyFileSelectErrorText');
    setInnerHTML(awsPrivateKeyFileSelectErrorText, "");
    const awsPrivateKeyFileSelectSuccessText = document.getElementById('awsPrivateKeyFileSelectSuccessText');
    setInnerHTML(awsPrivateKeyFileSelectSuccessText, "");
  }

  dispose() {
    this.clearAllHints();
    console.log(this);

    const awsSubmitButton = document.getElementById('awsSubmitButton');
    awsSubmitButton.addEventListener('click', this.submit);
  }
}