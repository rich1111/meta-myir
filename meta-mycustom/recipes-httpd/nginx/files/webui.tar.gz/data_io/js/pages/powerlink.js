class PowerlinkPage {
  constructor(props) {
    this.state = {
      enable: false
    };
    this.init();
  }

  init = async () => {
    const config = await Api.getPowerlinkConfig();
    this.setPowerlinkConfig(config);

    const plSubmit = document.getElementById("plSubmit");
    if (plSubmit) {
      plSubmit.addEventListener('click', this.submitPowerlink);
    }

    const disable = document.getElementById("disable");
    if (disable) {
      disable.addEventListener('click', this.switchEnable);
    }
    const enable = document.getElementById("enable");
    if (enable) {
      enable.addEventListener('click', this.switchEnable);
    }
  }

  setPowerlinkConfig = (config) => {
    this.setEnable(config.eplEnable);
    const nodeID = document.getElementById("nodeID");
    nodeID.value = config.eplNodeID;
  }

  submitPowerlink = async (e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };

    try {
      const enable = this.state.enable;
      const payload = {
        eplEnable: 0,
        eplNodeID: 1
      };
      if (enable) {
        const nodeID = parseInt(document.getElementById("nodeID").value);
        // Check allowed values
        if (nodeID < 1 || nodeID > 239) {
          customErrorProps.data.error.message = "Node ID must be between 1 and 239 (including)";
          throw new CustomError(customErrorProps);
        }
        payload.eplEnable = 1;
        payload.eplNodeID = nodeID;
      }

      DialogUtility.confirm({ text: `System will ${enable ? "enable" : "disable"} Sparkplug?` }).then(async (result) => {
        if (result.isConfirmed) {
          const res = await Api.setPowerlinkConfig(payload);
          DialogUtility.showSuccess({});
        }
      });
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  switchEnable = async (e) => {
    const enable = parseInt(e.srcElement.defaultValue);
    this.setEnable(enable);
  }

  setEnable(selected) {
    if (selected === 0) {
      document.getElementById("disable").checked = true;
    } else if (selected === 1) {
      document.getElementById("enable").checked = true;
    }
    const disable = selected === 0 ? true : false;
    // Set whether DHCP in state
    this.state = { enable: !disable };
    const nodeID = document.getElementById("nodeID");

    nodeID.disabled = disable;
  }

  dispose() {
    const plSubmit = document.getElementById("plSubmit");
    plSubmit.removeEventListener('click', this.plSubmit);
  }

}