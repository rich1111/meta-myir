/**
 * For module 12, 16, 116
 */
class DicounterPage {
  constructor(props) {
    this.state = {
      diBoard: [],
      doBoard: [],
      intervalId: undefined,
      refreshTime: 1000,
    };

    if (currentModuleType !== MODULE_TYPE_CODE.MOD116) {
      let lastEigthDigitalInputs = document.getElementsByClassName("last-eight-digital-input");
      for (let e of lastEigthDigitalInputs) {
        e.style.display = "none";
      }
    }

    switch(currentModuleType) {
      case MODULE_TYPE_CODE.MOD008:
      case MODULE_TYPE_CODE.MOD216:
        return;
      case MODULE_TYPE_CODE.MOD012:
      case MODULE_TYPE_CODE.MOD016:
      case MODULE_TYPE_CODE.MOD116:
        break;
    }

    this.init();
  }

  init = () => {
    this.initButtons();
    this.initIntervalSelect();

    this.state.intervalId = setInterval(
      this.loadPage,
      this.state.refreshTime,
    );
  }

  initButtons = () => {
    for (let i = 0; i < 8; i++) {
      const DIC_RST_button = document.getElementById(`DIC_RST${i}`);
      const DIC_EN_checkBox = document.getElementById(`DIC_EN${i}`);
      const DO_DFV_button = document.getElementById(`DO_DFV${i}`);
      console.log(DO_DFV_button);
      

      if (DIC_RST_button == null || DIC_EN_checkBox == null || DO_DFV_button == null) {
        continue;
      }

      DIC_RST_button.addEventListener('click', () => {
          const payload = this.getEditDigitalIutputPayload(i);
          payload.diCounterReset = 1;
          Api.editDigitalInputByPort(payload);
        }
      );

      DIC_EN_checkBox.addEventListener('change', () => {
        const payload = this.getEditDigitalIutputPayload(i);
        payload.diCounterStatus = 1 - payload.diCounterStatus;
        Api.editDigitalInputByPort(payload);
      });

      DO_DFV_button.addEventListener('click', () => {
        const payload = this.getEdittingDigitalOutputPayload(i);
        if (typeof payload["doDefaultValue"] === "number") {
          payload["doDefaultValue"] = 1 - payload["doDefaultValue"];
          Api.editDigitalOutputByPort(payload);
        }
      }
    );
    }
  }
  getEdittingDigitalOutputPayload = (index) => {
    const { doBoard } = this.state
    const output = doBoard[index]?.output;
    return {
      port: index,
      // doStatus: output?.doStatus,
      // doDefaultEnable: output?.doDefaultEnable,
      doDefaultValue: output?.doDefaultValue,
    };
  }
  
  getEditDigitalIutputPayload = (index) => {
    const input = this.state.diBoard[index]?.input;
    return {
      port:                    index,
      diStatus:                input?.diStatus,
      diCounterValue:          input?.diCounterValue,
      diCounterOverflowFlag:   input?.diCounterOverflowFlag,
      diCounterReset:          input?.diCounterReset,
      diCounterOverflowClear:  input?.diCounterOverflowClear,
      diCounterStatus:         input?.diCounterStatus,
    }
  }
  
  initIntervalSelect = () => {
    const refreshSelect = document.getElementById("refresh");
    if (refreshSelect) {
      refreshSelect.value = this.state.refreshTime;
      refreshSelect.addEventListener(
        'change',
        this.onRefreshTimeChange
      );
    }
  }

  onRefreshTimeChange = (e) => {
    this.state.refreshTime = e.target.value;
    const { intervalId } = this.state;

    if (intervalId) {
      clearInterval(intervalId);
    }

    this.state.intervalId = setInterval(
      this.loadPage,
      this.state.refreshTime
    );
  }

  loadPage = async() => {
    try {
      var mainstat = document.getElementById('display');
	    var loadstat = document.getElementById('loading');

      // Make sure we're displaying the status display
      if (mainstat != null && loadstat != null) {
        mainstat.style.display = 'inline';
        loadstat.style.display = 'none';
      }

      const digitalInputs = (await Api.getDigitalInput()).io.di;

      const digitalOutpus = (await Api.getDigitalOutput()).io.do;

      if (!(currentPage instanceof DicounterPage)) {
        return;
      }

      const { diBoard, doBoard } = this.state;
  
      digitalInputs.forEach((input) => {
        const { diIndex } = input;
        if (diBoard[diIndex] === undefined) {
          diBoard[diIndex] = {};
        }
        diBoard[diIndex].input = input;
      });

      digitalOutpus.forEach((output) => {
        const { doIndex } = output;
        if (doBoard[doIndex] === undefined) {
          doBoard[doIndex] = {};
        }
        doBoard[doIndex].output = output;
      });

      diBoard.forEach(item => {
        const { input } = item;

        const cells = [
          { name: "DIC_",     value: input.diStatus,               },
          { name: "DIC_EN",   value: input.diCounterStatus,        },
          { name: "DIC_OF",   value: input.diCounterOverflowFlag,  },
          { name: "DIC_VAL",  value: input.diCounterValue,         },
        ];        

        cells.forEach((cell) => {
          this.renderBoardCell({
            index:  input?.diIndex,
            name:   cell.name,
            value:  cell.value,
          });
        });
      });
      
      doBoard.forEach(item => {
        const { output } = item;
        
        const cells = [
          { name: "DO_",     value: output.diStatus,               },
          { name: "DO_DFE",  value: output.doDefaultEnable,        },
          { name: "DO_DFV",  value: output.doDefaultValue,         },
          { name: "DO_PSE",  value: output.doPulseStatus,          },
        ]; 

        cells.forEach((cell) => {
          this.renderBoardCell({
            index:  output?.doIndex,
            name:   cell.name,
            value:  cell.value,
          });
        });

      });

      digitalOutpus.forEach((item, index) => {
        
        const doPulseOnWidth = document.getElementById('doPulseOnWidth_' + index);
        const doPulseOffWidth = document.getElementById('doPulseOffWidth_' + index);
        setDomProperty(doPulseOnWidth, "value", item?.doPulseOnWidth);
        setDomProperty(doPulseOffWidth, "value", item?.doPulseOffWidth);
      });

      const lastUpdateTimeElem = document.getElementById("lastUpdateTime");
      setInnerText(lastUpdateTimeElem, (new Date()).toUTCString());

    } catch(error) {
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  renderBoardCell = ({ index, name, value }) => {
    const id = name + index;
    const cell = document.getElementById(id);

    if (cell == null) {
      return;
    }

    if (name == "DIC_VAL") {
      cell.innerHTML = value;
      return;
    }

    const flag = 0 < value;

    if (cell == null) {
      return;
    }
    if (name == "DIC_EN" || name == "DO_DFE" || name == "DO_PSE") {
      cell.checked = flag;
    } else if (name == "DIC_" || name == "DIC_OF" || name == "DO_") {
      setCircle(cell, flag);
    } 
    // else if (name == "DO_DFV") {

    // } 記得要補上，去看digital.js的initButtons()

    // else if (name == "DIC_OF") {
    //   setCircle(cell, flag);
    // } else if (name == "DO_") {
    //   setCircle(cell, flag);
    // } 

    cell.style.color = flag ? "#FF0000" : "#999999";
  }

  dispose() {
    const { intervalId } = this.state;
    if (intervalId !== undefined) {
      clearInterval(intervalId);
    }
  }
}