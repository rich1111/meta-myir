class SparkplugPage {
  constructor(props) {
    this.state = {
      enable: false
    };
    this.init();
    // Set a backend timer to reload connection status
    this.timer = setInterval(async () => {
      const config = await Api.getSparkplugConfig();
      this.setConnectStatus(config);
    }
    , 5000);
  }

  init = async () => {
    const info = await Api.getSysInfo();
    this.setHostName(info.sysInfo.device.hostName);

    const config = await Api.getSparkplugConfig();
    this.setSparkplugConfig(config);
    this.setConnectStatus(config);

    const plSubmit = document.getElementById("plSubmit");
    if (plSubmit) {
      plSubmit.addEventListener('click', this.submitSparkplug);
    }

    const disable = document.getElementById("disable");
    if (disable) {
      disable.addEventListener('click', this.switchEnable);
    }
    const enable = document.getElementById("enable");
    if (enable) {
      enable.addEventListener('click', this.switchEnable);
    }
    const scada = document.getElementById("scada");
    if (scada) {
      scada.addEventListener('click', this.switchEnable);
    }
  }

  setSparkplugConfig = (config) => {
    const serverUrl = document.getElementById("serverUrl");
    serverUrl.value = config.serverUrl;
    const username = document.getElementById("username");
    username.value = config.username;
    const password = document.getElementById("password");
    password.value = config.password;
    const groupID = document.getElementById("groupID");
    groupID.value = config.groupID;
    const nodeID = document.getElementById("nodeID");
    nodeID.value = config.nodeID;

    if (config.enable === 0) {
      document.getElementById("disable").checked = true;
      this.setSelected("disable");
    } else if (config.enable === 1) {
      const hostName = document.getElementById("hostName").innerHTML;
      
      if(config.username===config.groupID && config.nodeID===hostName) {
        document.getElementById("scada").checked = true;
        this.setSelected("scada");
      } else {
        document.getElementById("enable").checked = true;
        this.setSelected("enable");
      }
    }
  }

  setConnectStatus = (config) => {
    const errorMessage = document.getElementById("connectionError");
    errorMessage.innerHTML = config.errorMessage;

    const connect = document.getElementById("connect");
    const disconnect = document.getElementById("disconnect");
    // If connectedStatus is FALSE, errorMessage will be shown
    if (config.connectedStatus === 0){
      connect.style.visibility = 'hidden';
      disconnect.style.visibility = 'visible';
    } else {
      connect.style.visibility = 'visible';
      disconnect.style.visibility = 'hidden';
    }
  }

  submitSparkplug = async (e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };

    try {
      // Get the selected radio button value
      const eds = document.querySelector('input[name="eds"]:checked').value;
      const payload = {
        enable: 0,
        serverUrl: "",
        username: "",
        password: "",
        groupID: "",
        nodeID: ""
      };

      const serverUrl = document.getElementById("serverUrl").value;
      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;
      const groupID = document.getElementById("groupID").value;
      const nodeID = document.getElementById("nodeID").value;

      if (eds === "enable") {
        // 1: Enabled; Check allowed values
        if (serverUrl === "") {
          customErrorProps.data.error.message = "Please set a Server URL!";
          throw new CustomError(customErrorProps);
        }
        if (groupID === "") {
          customErrorProps.data.error.message = "Please set a Group ID!";
          throw new CustomError(customErrorProps);
        }
        if (nodeID === "") {
          customErrorProps.data.error.message = "Please set a Node ID!";
          throw new CustomError(customErrorProps);
        }
        payload.groupID = groupID;
        payload.nodeID = nodeID;
        payload.enable = 1;
      } else if(eds === "scada") {
        // 2: SCADA; Check allowed values
        if (serverUrl === "") {
          customErrorProps.data.error.message = "Please set a Server URL!";
          throw new CustomError(customErrorProps);
        }
        if (username === "") {
          customErrorProps.data.error.message = "Please set a User Name!";
          throw new CustomError(customErrorProps);
        }
        if (password === "") {
          customErrorProps.data.error.message = "Please set a Password!";
          throw new CustomError(customErrorProps);
        }
        payload.groupID = username;
        const hostName = document.getElementById("hostName").innerHTML;
        payload.nodeID = hostName;
        payload.enable = 1;
      } else {
        payload.groupID = groupID;
        payload.nodeID = nodeID;
      }
      payload.serverUrl = serverUrl;
      payload.username = username;
      payload.password = password;
      
      DialogUtility.confirm({ text: `System will ${eds==="disable" ? "disable" : "enable"} Sparkplug?` }).then(async (result) => {
        if (result.isConfirmed) {
          Api.setSparkplugConfig(payload);
          DialogUtility.showSuccess({});
        }
      });
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  switchEnable = async (e) => {
    const select = e.srcElement.defaultValue;

    this.setSelected(select);
  }

  setHostName = (hostname) => {
    const hostName = document.getElementById("hostName");
    hostName.innerHTML = hostname;
  }

  setSelected(select) {
    const conn = document.getElementById("conn");
    const url = document.getElementById("url");
    const user = document.getElementById("user");
    const pass = document.getElementById("pass");
    const group = document.getElementById("group");
    const node = document.getElementById("node");
    if(select==="disable") {
      conn.style.display="none";
      url.style.display="none";
      user.style.display="none";
      pass.style.display="none";
      group.style.display="none";
      node.style.display="none";
    } else if(select==="enable") {
      conn.style.display="block";
      url.style.display="block";
      user.style.display="block";
      pass.style.display="block";
      group.style.display="block";
      node.style.display="block";
    } else if(select==="scada") {
      conn.style.display="block";
      url.style.display="block";
      user.style.display="block";
      pass.style.display="block";
      group.style.display="none";
      node.style.display="none";
    }
  }

  dispose() {
    const plSubmit = document.getElementById("plSubmit");
    plSubmit.removeEventListener('click', this.plSubmit);
    // Remove timer
    console.log(this);
    clearInterval(this.timer);
  }

}