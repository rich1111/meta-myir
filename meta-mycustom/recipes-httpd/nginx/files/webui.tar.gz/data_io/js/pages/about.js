class AboutPage {
  constructor(props) {
    this.state = {
      timer: null,
      ntpAuto: null,
      ntpServer: {},
      nowTime: {},
      serverTimer: null,
      userRole: sessionStorage.getItem('role'),
      firmwareFile: null,
    };
    this.init();
  }

  init = () => {
    const basicDiv = document.querySelector('.tab.basic');
    const timeDiv = document.querySelector('.tab.time');
    const accountDiv = document.querySelector('.tab.account');
    const firewallDiv = this.state.userRole === "admin" ? document.querySelector('.tab.firewall') : null;
    const firmwareDiv = document.querySelector(".tab.firmware");
    
    if(firewallDiv){
      firewallDiv.style.display = this.state.userRole === "admin" ? "block" : "none";
    }

    if (this.state.timer) {
      clearInterval(this.state.timer);
    }
    
    basicDiv.addEventListener('click', () => {
      clearInterval(this.state.serverTimer);
      this.initBasic();
    });
    basicDiv.click();

    timeDiv.addEventListener('click', () => {
      clearInterval(this.state.timer);
      this.initTime();
    });

    accountDiv.addEventListener('click', () => {
      clearInterval(this.state.timer);
      clearInterval(this.state.serverTimer);
      this.initAccount();
    });

    if(firewallDiv){
      firewallDiv.addEventListener('click', () => {
        clearInterval(this.state.timer);
        clearInterval(this.state.serverTimer);
        this.initFirewall();
      });
    }

    firmwareDiv.addEventListener('click', () => {
      clearInterval(this.state.timer);
      clearInterval(this.state.serverTimer);
      this.initFirmware();
    });
  }

  initBasic = async () => {
    try {
      await this._initBasic();
      this.state.timer = setInterval(async () => {
        const config = await this._initBasic()
      }, 60000);
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  _initBasic = async () => {
    const model_name = document.getElementById("model_name");
    const alias_name = document.getElementById("alias_name");
    const loaction = document.getElementById("loaction");
    const wan_IP = document.getElementById("wan_IP");
    const hostname = document.getElementById("hostname");
    const last_boot_time = document.getElementById("last_boot_time");
    const lan_mac = document.getElementById("lan_mac");
    const firmware_version = document.getElementById("firmware_version");
    
    const sysInfo = (await Api.getSysInfo()).sysInfo;
    const { device, network } = sysInfo;
    sessionStorage.setItem('deviceIP', network?.WAN?.wanIp);
    const nameAndLocation = (await Api.getNameAndLocation());
    
    if (!(currentPage instanceof AboutPage)) {
      return;
    }

    let lastBootTime = '';
    if (device?.deviceUpTime) {
      const now = new Date()
      lastBootTime = new Date(now - device.deviceUpTime * 1000).toUTCString();
      // const bootTime = new Date(now - device.deviceUpTime * 1000);
  
      // lastBootTime = bootTime.toLocaleString(undefined, {
      //   timeZoneName: 'short',
      // });
    }

    setInnerText(model_name, device?.deviceName);
    setInnerText(alias_name, nameAndLocation.name);
    setInnerText(loaction, nameAndLocation.location);
    setInnerText(wan_IP, network?.WAN?.wanIp);
    setInnerText(hostname, device?.hostName);
    setInnerText(last_boot_time, lastBootTime);
    setInnerText(lan_mac, network?.WAN?.wanMac);
    setInnerText(firmware_version, device?.firmwareVersion);
  }

  initTime = async () => {
    const dateInput = document.getElementById("date");
    const timeInput = document.getElementById("time");
    const server1Input = document.getElementById("server0");
    const server2Input = document.getElementById("server1");
    const server3Input = document.getElementById("server2");
    const timeZoneInput = document.getElementById("timeZone");

    setDomProperty(dateInput, 'value', '');
    setDomProperty(timeInput, 'value', '');
    setDomProperty(server1Input, 'value', '');
    setDomProperty(server2Input, 'value', '');
    setDomProperty(server3Input, 'value', '');
    setDomProperty(timeZoneInput, 'value', '');

    const ntpRadio = document.getElementById("ntp");
    if (ntpRadio) {
      ntpRadio.addEventListener('click', this.switchEnable);
    }
    const manualRadio = document.getElementById("manual");
    if (manualRadio){
      manualRadio.addEventListener('click', this.switchEnable);
    }

    const defaultNtp = document.getElementById("defaultNtp");
    if (defaultNtp) {
      defaultNtp.addEventListener('click', this.setDefaultNtp);
    }
    const ntpSyncButton = document.getElementById("syncNtp");
    ntpSyncButton.removeEventListener('click', this.syncNtpServer);
    ntpSyncButton.addEventListener('click', this.syncNtpServer);
    const ntpSaveButton = document.getElementById("saveNtp");
    ntpSaveButton.addEventListener('click', this.ntpSave);

    const loadBrowserButton = document.getElementById("loadBrowser");
    loadBrowserButton.addEventListener('click', this.loadBrowser);

    const manualSaveButton = document.getElementById("saveManual");
    manualSaveButton.addEventListener('click', this.timeSave);

    setDisable();
    if(this.state.userRole !== "admin") {
      setDisableSingleOrButton(defaultNtp);
      setDisableSingleOrButton(ntpSyncButton);
      setDisableSingleOrButton(ntpSaveButton);
      setDisableSingleOrButton(loadBrowserButton);
      setDisableSingleOrButton(manualSaveButton);
    }

    if (this.state.serverTimer) {
      clearInterval(this.state.serverTimer);
    }
    try {
      const config = await Api.getTimeConfig();
      const { time, ntpAuto, ntpServers, timeZone } = config;

      if (ntpAuto === 1) {
        document.getElementById("ntp").checked = true;
        this.setSelected("ntp");
      } else {
        document.getElementById("manual").checked = true;
        this.setSelected("manual");
      }
      const getTimeZoneRes = await fetch('data/timezone.json');
      const timeZones = await getTimeZoneRes.json();
      
      this.state.ntpAuto = ntpAuto;
      this.state.ntpServer = ntpServers;
      this.updateNowTime(time);
      this.state.nowTime = time;
      
      let month = setFormatUniform(time.month);
      let day = setFormatUniform(time.day);
      let hour = setFormatUniform(time.hour);
      let min = setFormatUniform(time.min);
      let sec = setFormatUniform(time.sec);

      timeZones.forEach(timeZone => {
        const option = document.createElement('option');
        option.value = timeZone;
        option.text = timeZone;
        timeZoneInput.appendChild(option);
      });
      setDomProperty(timeZoneInput, 'value', timeZone);
      setDomProperty(dateInput, 'value', `${time.year}-${month}-${day}`);
      setDomProperty(timeInput, 'value', `${hour}:${min}:00`);
      setDomProperty(server1Input, 'value', ntpServers.ntpServer0);
      setDomProperty(server2Input, 'value', ntpServers.ntpServer1);
      setDomProperty(server3Input, 'value', ntpServers.ntpServer2);
      this.initFlatpickr();
      this.updateDisplay(time);
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }
  
  //Customized input date and time
  initFlatpickr = () => {
    flatpickr("#date", {
      dateFormat: "Y-m-d",
      locale: "en"
    });
    
    flatpickr("#time", {
      enableTime: true,
      noCalendar: true,  
      dateFormat: "H:i:S",
      time_24hr: true,
      enableSeconds: false,
      locale: "en"
    });
  }

  switchEnable = async (e) => {
    const select = e.srcElement.defaultValue;
    this.setSelected(select);
  }

  setSelected(select) {
    const serv0 = document.getElementById("serv0");
    const serv1 = document.getElementById("serv1");
    const serv2 = document.getElementById("serv2");
    const saveN = document.getElementById("saveN");

    const da = document.getElementById("da");
    const ti = document.getElementById("ti");
    const saveT = document.getElementById("saveT");

    if(select === "ntp") {
        serv0.style.display="block";
        serv1.style.display="block";
        serv2.style.display="block";
        saveN.style.display="block";

        da.style.display="none";
        ti.style.display="none";
        saveT.style.display="none";
    } else if(select === "manual") {
        serv0.style.display="none";
        serv1.style.display="none";
        serv2.style.display="none";
        saveN.style.display="none";

        da.style.display="block";
        ti.style.display="block";
        saveT.style.display="block";
    }
  }

  //顯示update後最新時間
  updateTime = async () => {
    try {
      if (this.state.serverTimer) {
        clearInterval(this.state.serverTimer);
      }
      const config = await Api.getTimeConfig();
      const { time, ntpServers, ntpAuto } = config;
      this.state.ntpAuto = ntpAuto;
      this.state.ntpServer = ntpServers;
      this.state.nowTime = time;
      this.updateNowTime(time);
      this.updateDisplay(time);
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  //將update後最新時間寫入DOM
  updateNowTime = (time) => {
    
    const serverTime = document.getElementById("serverTime");
    const dateInput = document.getElementById("date");
    const timeInput = document.getElementById("time");

    let month = setFormatUniform(time.month);
    let day = setFormatUniform(time.day);
    let hour = setFormatUniform(time.hour);
    let min = setFormatUniform(time.min);
    let sec = setFormatUniform(time.sec);
    const now = `${time.year}-${month}-${day} ${hour}:${min}:${sec}`;
    setDomProperty(serverTime, 'innerText', now);
    setDomProperty(dateInput, 'value', `${time.year}-${month}-${day}`);
    setDomProperty(timeInput, 'value', `${hour}:${min}:00`);
  }

  updateDisplay = (nowTime) => {
    let serverTime = new Date(
      nowTime.year,
      nowTime.month - 1, // JavaScript 的月份從0開始
      nowTime.day,
      nowTime.hour,
      nowTime.min,
      nowTime.sec
    );

    const updateOneSec = () => {
      const serverTimeElement = document.getElementById("serverTime");

      serverTime.setSeconds(serverTime.getSeconds() + 1);

      let year = serverTime.getFullYear();
      let month = setFormatUniform(serverTime.getMonth() + 1); // 月份從0開始，顯示需要加1
      let day = setFormatUniform(serverTime.getDate());
      let hour = setFormatUniform(serverTime.getHours());
      let min = setFormatUniform(serverTime.getMinutes());
      let sec = setFormatUniform(serverTime.getSeconds());

      const now = `${year}-${month}-${day} ${hour}:${min}:${sec}`;
      setDomProperty(serverTimeElement, 'innerText', now);
    };

    this.state.serverTimer = setInterval(updateOneSec, 1000);
  };

  setDefaultNtp = async (e) => {
    e.preventDefault();
    const server1Input = document.getElementById("server0");
    const server2Input = document.getElementById("server1");
    const server3Input = document.getElementById("server2");
    setDomProperty(server1Input, 'value', 'pool.ntp.org');
    setDomProperty(server2Input, 'value', 'time.windows.com');
    setDomProperty(server3Input, 'value', 'time.nist.gov');
  }
  syncNtpServer = async (e) => {
    e.preventDefault();
    
    const customErrorProps = {
      data: {
          error: {
          message: "",
          }
      }
    };
    const ntpServerPayload = {
      ntpAuto: 1,
      ntpServers: {
        ntpServer0: this.state.ntpServer.ntpServer0,
        ntpServer1: this.state.ntpServer.ntpServer1,
        ntpServer2: this.state.ntpServer.ntpServer2,
        ntpServer3: "", //只需要顯示3個server，補上空字串
      }
    }
    try {
      if(this.state.ntpServer.server0 === "" && this.state.ntpServer.server1 === "" && this.state.ntpServer.server2 === "") {
        customErrorProps.data.error.message = "NTP Server must be filled!";
        throw new CustomError(customErrorProps);
      }
      const setNtpAuto = await Api.setNTP(ntpServerPayload);
      const ntpSyncRes = await Api.syncNTP();
      
      DialogUtility.showSuccess({
        text: ntpSyncRes.error?.message,
      });
      setTimeout(() => {
        this.updateTime();
      }, 3000);
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }
  ntpSave = async(e) => {
    e.preventDefault();
    const customErrorProps = {
      data: {
          error: {
          message: "",
          }
      }
    };

    try {
      const server1Input = document.getElementById("server0").value;
      const server2Input = document.getElementById("server1").value;
      const server3Input = document.getElementById("server2").value;
      const timeZoneInput = document.getElementById("timeZone").value;

      const ntpServerPayload = {
        ntpAuto: 1,
        ntpServers: {
          ntpServer0: server1Input,
          ntpServer1: server2Input,
          ntpServer2: server3Input,
          ntpServer3: "", //只需要顯示3個server，補上空字串
        }
      }
      const timeZonePayload = {
        timeZone: timeZoneInput,
      }

      if(server1Input === "" && server2Input === "" && server3Input === "") {
        customErrorProps.data.error.message = "NTP Server must be filled!";
        throw new CustomError(customErrorProps);
      }
      const setNtp = await Api.setNTP(ntpServerPayload);
      const setTimeZone = await Api.setTimeZone(timeZonePayload);

      DialogUtility.showSuccess({
        text: setNtp.error?.message,
      });
      this.updateTime();
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }

  loadBrowser = (e) => {
    e.preventDefault();
    const dateInput = document.getElementById("date");
    const timeInput = document.getElementById("time");

    const now = new Date();
    const timeDiff = (now.getTimezoneOffset() / 60); //計算出時差
    now.setHours(now.getHours() - (timeDiff)) //加上時差
    const dateData = now.toJSON().split('T');
    const timeData = dateData[1].split('.');
    const date = dateData[0].split('-');
    const time = timeData[0].split(':');

    setDomProperty(dateInput, 'value', `${date[0]}-${date[1]}-${date[2]}`);
    setDomProperty(timeInput, 'value', `${time[0]}:${time[1]}:00`);
  };

  timeSave = async (e) => {
    e.preventDefault();
    
    const customErrorProps = {
      data: {
          error: {
          message: "",
          }
      }
    };

    try {
      const timeZoneInput = document.getElementById("timeZone").value;
      const dateInput = document.getElementById("date").value;
      const timeInput = document.getElementById("time").value;
      const date = dateInput.split('-');
      const time = timeInput.split(':');
            
      const ntpServerPayload = {
        ntpAuto: 0,
        ntpServers: {
          ntpServer0: this.state.ntpServer.ntpServer0,
          ntpServer1: this.state.ntpServer.ntpServer1,
          ntpServer2: this.state.ntpServer.ntpServer2,
          ntpServer3: "",
        }
      }

      const timeZonePayload = {
        timeZone: timeZoneInput,
      }

      const timePayload = {
        time: {
          year: Number(date[0]),
          month: Number(date[1]),
          day: Number(date[2]),
          hour: Number(time[0]),
          min: Number(time[1]),
          sec: 0,
        }
      }

      if(dateInput === "" || timeInput === "") {
        customErrorProps.data.error.message = "Date and Time must be filled!";
        throw new CustomError(customErrorProps);
      }

      const setNtpAuto = await Api.setNTP(ntpServerPayload);
      const setTimeZone = await Api.setTimeZone(timeZonePayload);
      const setTimeRes = await Api.setTimeConfig(timePayload);
      
      DialogUtility.showSuccess({
        text: setNtpAuto.error?.message,
      });
      this.updateTime();
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }


  initAccount = () => {
    const role = sessionStorage.getItem('role');
    const accountDiv = document.getElementById('nav-account');

    const generateForm = (showOldPassword, submitButtonId) => {
      return `
      <form class="form-horizontal">
        ${showOldPassword ? `
        <div class="control-group">
          <label class="control-label">Current Password:</label>
          <div class="controls">
            <input type="password" class="pwd" id="oldPassword" minlength="4" maxlength="16">
          </div>
        </div>` : ''}
        ${showOldPassword ? '': `
          <div class="control-group">
            <label class="control-label">Admin Password:</label>
            <div class="controls">
              <input type="password" class="pwd" id="adminPassword" minlength="4" maxlength="16">
            </div>
          </div>`}
        <div class="control-group">
          <label class="control-label">New Password:</label>
          <div class="controls">
            <input type="password" class="pwd" id="newPassword" minlength="4" maxlength="16">
          </div>
        </div>
        <div class="control-group">
          <label class="control-label">Confirm New Password:</label>
          <div class="controls">
            <input type="password" class="pwd" id="confirmPassword" minlength="4" maxlength="16">
          </div>
        </div>
        <div class="control-group">
          <div class="controls">
            <input type="button" id="${submitButtonId}" value="Save">
          </div>
        </div>
      </form>`;
    }

    if(role === "admin") {
      accountDiv.innerHTML = `
      <div class="widget-content nopadding">
        <nav>
          <div class="nav nav-tabs" id="nav-tab-account" role="tablist">
            <button class="tab admin nav-link active" id="nav-admin-tab" data-bs-toggle="tab" data-bs-target="#nav-admin" type="button" role="tab" aria-controls="nav-admin" aria-selected="true">Administrator</button>
            <button class="tab user nav-link" id="nav-user-tab" data-bs-toggle="tab" data-bs-target="#nav-user" type="button" role="tab" aria-controls="nav-user" aria-selected="false">User</button>
          </div>
        </nav>
        <div class="tab-content" id="nav-tabContent-account">
          <div class="tab-pane fade show active" id="nav-admin" role="tabpanel" aria-labelledby="nav-admin-tab">
            <div class="widget-content nopadding">
              ${generateForm(true, "passSubmitAdmin")}
            </div>
          </div>
          <div class="tab-pane fade" id="nav-user" role="tabpanel" aria-labelledby="nav-user-tab">
            <div class="widget-content nopadding">
              ${generateForm(false, "passSubmitUser")}
            </div>
          </div>
        </div>
      </div>`;

      document.getElementById("passSubmitAdmin").addEventListener('click', this.submitPassword);

      document.getElementById("nav-user-tab").addEventListener('click', () => {
        document.getElementById("passSubmitUser").addEventListener('click', this.submitPassword);
      });

    } else {
      accountDiv.innerHTML = `
      <div class="widget-content nopadding">
        ${generateForm(true, "passSubmitAdmin")}
      </div>`;
    }

    const passSubmit = document.getElementById("passSubmitAdmin");
    if (passSubmit) {
      passSubmit.addEventListener('click', this.submitPassword);
    }
  }

  submitPassword = async (e) => {
    e.preventDefault();
    
    const role = sessionStorage.getItem('role');
    const adminBtn = document.getElementById("nav-admin-tab") ? document.getElementById("nav-admin-tab") : null;
    const userBtn = document.getElementById("nav-user-tab") ? document.getElementById("nav-user-tab") : null;
    
    let newPasswordInput, confirmPasswordInput, oldPasswordInput, adminPasswordInput;
  
    if (role === 'admin') {
      const currentTabId = adminBtn.classList.contains('active') ? 'nav-admin' : 'nav-user';
      newPasswordInput = document.querySelector(`#${currentTabId} #newPassword`);
      confirmPasswordInput = document.querySelector(`#${currentTabId} #confirmPassword`);
      
      if (currentTabId === 'nav-user') {
        adminPasswordInput = document.querySelector(`#${currentTabId} #adminPassword`);
      } else {
        oldPasswordInput = document.querySelector(`#${currentTabId} #oldPassword`);
      }
    } else {
      newPasswordInput = document.getElementById("newPassword");
      confirmPasswordInput = document.getElementById("confirmPassword");
      oldPasswordInput = document.getElementById("oldPassword");
    }
  
    const customErrorProps = {
      data: {
        error: {
          message: "",
        }
      }
    };
  
    try {
      if (role === 'admin' && userBtn && userBtn.classList.contains('active')) {
        // Admin 改 user 密碼
        const adminPassword = adminPasswordInput ? adminPasswordInput.value : "";
        const newPassword = newPasswordInput.value;
        const confirmPassword = confirmPasswordInput.value;
  
        if (adminPassword === "" || newPassword === "" || confirmPassword === "") {
          customErrorProps.data.error.message = "Admin and New password fields must be filled!";
          throw new CustomError(customErrorProps);
        }
        if (newPassword !== confirmPassword) {
          customErrorProps.data.error.message = "Confirm password does not match!";
          throw new CustomError(customErrorProps);
        }
  
        const result = await DialogUtility.confirm({ text: "Change password! User will need to re-login with new password!" });
        if (result.isConfirmed) {
          const payload = {
            adminname: "admin",
            adminpassword: adminPassword,
            username: "user",
            newpassword: newPassword
          };
          const apiResult = await Api.adminChangePassword(payload).catch((err) => {
            ErrorUtility.handleError(err);
          });
          
          if (apiResult.code === 400) {
            DialogUtility.showError({ title: "Password change failed!", text: apiResult.message });
          } else {
            DialogUtility.showSuccess({ text: apiResult.error?.message });
            
            adminPasswordInput.value = ""; 
            newPasswordInput.value = "";
            confirmPasswordInput.value = ""; 
          }
        }
      } else {
        // Admin 改自己密碼或 user 改自己密碼
        const newPassword = newPasswordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        const oldPassword = oldPasswordInput ? oldPasswordInput.value : "";
  
        if (oldPassword === "" || newPassword === "" || confirmPassword === "") {
          customErrorProps.data.error.message = "Current and New password fields must be filled!";
          throw new CustomError(customErrorProps);
        }
        if (newPassword !== confirmPassword) {
          customErrorProps.data.error.message = "Confirm password does not match!";
          throw new CustomError(customErrorProps);
        }
    
        const username = role === 'admin' ? "admin" : "user";
    
        DialogUtility.confirm({ text: "Change password! You will need to re-login with new password!" }).then(async (result) => {
          if (result.isConfirmed) {
            const payload = {
              username,
              oldpassword: oldPassword,
              newpassword: newPassword
            };
            const result = await Api.changePassword(payload).catch((err) => {
              ErrorUtility.handleError(err);
            });
            if (result.code === 400) {
              DialogUtility.showError({ title: "Password change failed!", text: result.message });
            } else {
              location.replace("./login.html");
            }
          }
        });
      }
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  };


  initFirewall = async () => {
    try {
      const tbody = document.getElementById('tbody');
      const firewallSaveButton = document.getElementById('firewallSave');
      firewallSaveButton.removeEventListener('click', this.handleSaveFirewall);
      firewallSaveButton.addEventListener('click', this.handleSaveFirewall);
      if(this.state.userRole !== "admin") {
        document.getElementById("firewallSave").disabled = true;
      }

      tbody.innerHTML = '';
      for (let i = 0; i < 5; i++) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="font-style">${i + 1}</td>
          <td class="font-style"><input type="text" id="white_IP${i}" style="width:380px;"></td>
          <td class="font-style"><input type="text" id="netmask${i}" style="width:380px;"></td>
        `;
        tbody.appendChild(tr);
      }
      const getFirewall = await Api.getFirewallConfig();
      this.loadingFirewallPage(getFirewall);
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  }
  
  loadingFirewallPage = (config) => {
    setDisable();
    const { white_list, option } = config;
    const whiteList = white_list.ips;
    const whiteListEnable = document.getElementById('whiteListEnable');
    setDomProperty(whiteListEnable, 'checked', option === 1 ? true : false);

    whiteList.forEach((ip, index) => {
      const white_IPs = document.getElementById(`white_IP${index}`);
      const netmask = document.getElementById(`netmask${index}`);
      if(ip.ip.includes('/')) {
        const reArray = ip.ip.split('/');
        setValue(white_IPs, reArray[0]);
        setValue(netmask, reArray[1]);
      } else {
        setValue(white_IPs, ip.ip);
      }
    });
  }
  
  handleSaveFirewall =  async(e) => {
    // e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
          message: "",
          }
        }
      };

      try {
        const whiteListEnable = document.getElementById('whiteListEnable').checked;
        const tbody = document.getElementById('tbody');
        const tableIndex = tbody ? tbody.children.length : 0;
        
        const payload = {
          "option": whiteListEnable ? 1 : 0,
          "white_list": {
            "ips": []
          },
          "black_list": {
            "ips": []
          }
        };
        
        for (let i = 0; i < tableIndex; i++) {
          let white_IPs = document.getElementById(`white_IP${i}`).value;
          let netmask = document.getElementById(`netmask${i}`).value;
          if(white_IPs !== "" && netmask !== "") {
            payload.white_list.ips.push({ip: `${white_IPs}/${netmask}`});
          } else if(white_IPs !== "") {
            payload.white_list.ips.push({ip: white_IPs});
          }
        }
        if(payload.white_list.ips.length === 0 && whiteListEnable) {
          customErrorProps.data.error.message = "IP Address	must be filled!";
          throw new CustomError(customErrorProps);
        }

        const res = await Api.editFirewallConfig(payload);
        DialogUtility.showSuccess({
          text: res.error?.message,
        });
        this.initFirewall();
      } catch (error) {
        ErrorUtility.handleError(error);
      }
  }

  initFirmware = async () => {
    const serial = document.getElementById("serial");
    const fw_version = document.getElementById("fw_version");
    const firmwareFileSelect = document.getElementById('firmwareFileSelect');

    firmwareFileSelect.onchange = this.uploadFirmwareFile;

    const deviceConfig = (await Api.getSysInfo()).sysInfo.device;
    
    setInnerText(serial, deviceConfig?.hostName);
    setInnerText(fw_version, deviceConfig?.firmwareVersion);

    const firmwareSubmit = document.getElementById('firmwareSubmit');
    firmwareSubmit.addEventListener('click', this.firmwareSubmit);
  }

  uploadFirmwareFile = () => {
    try {
      const firmwareFileSelectSuccessText = document.getElementById('firmwareFileSelectSuccessText');
      const firmwareFileSelectErrorText = document.getElementById('firmwareFileSelectErrorText');
  
      setInnerHTML(firmwareFileSelectErrorText, "");
      setInnerHTML(firmwareFileSelectSuccessText, "");
  
      const firmwareFileSelect = document.getElementById('firmwareFileSelect');
      const file = firmwareFileSelect.files[0];
      this.state.firmwareFile = file;
  
      setInnerHTML(firmwareFileSelectSuccessText, "Upload File Success!");
    } catch(error) {
      const firmwareFileSelectErrorText = document.getElementById('firmwareFileSelectErrorText');
      setInnerHTML(firmwareFileSelectErrorText, "Upload File Failed");
    }
  }

  firmwareSubmit = async(e) => {
    e.preventDefault();
    try {
      this.firmwareClearAllHints();
      const { firmwareFile } = this.state;
  
      if (!firmwareFile) {
        const firmwareFileSelectErrorText = document.getElementById('firmwareFileSelectErrorText');
        setInnerHTML(firmwareFileSelectErrorText, "Please select a file!");
        return;
      }
  
      console.log(firmwareFile);
  
      const result = await DialogUtility.confirm({
        text: "Firmware update! Device will reboot after update, please re-login after reboot!",
      });
  
      if (result.isConfirmed) {
        initPageLoadingsForReboot();
  
        try {
          await Api.updateFirmware(firmwareFile, "firmware");
        } catch (error) {
          console.warn("Firmware update API may have disconnected as expected:", error);
        }
  
        const intervalId = setInterval(async () => {
          try {
            const sysInfoRes = await Api.getSysInfo();
  
            if (sysInfoRes.sysInfo.device.deviceUpTime < 119) {
              clearInterval(intervalId);
  
              DialogUtility.showSuccess({
                text: "Firmware update success!",
              });
              removePageLoadingsForReboot();
              location.replace("./login.html");
            }
          } catch (error) {
            console.error("Error while checking system info:", error);
          }
        }, 60000);
      }
    } catch (error) {
      ErrorUtility.handleError(error);
    }
  };
  
  firmwareClearAllHints = () => {
    const firmwareFileSelectErrorText = document.getElementById('firmwareFileSelectErrorText');
    const firmwareFileSelectSuccessText = document.getElementById('firmwareFileSelectSuccessText');
    setInnerHTML(firmwareFileSelectErrorText, "");
    setInnerHTML(firmwareFileSelectSuccessText, "");
  }

  dispose() {
    clearInterval(this.state.timer);
    clearInterval(this.state.serverTimer);
    const basicDiv = document.querySelector('.tab.basic');
    basicDiv.removeEventListener('click', this.initBasic);
    // const ntpSyncButton = document.getElementById("syncNtp");
  }
}