/**
 * For module 12, 16, 116
 */
class SnmpPage {
  constructor(props) {
    this.state = {
      modType: ""
    };
    this.init();
  }

  init = () => {
    switch (currentModuleType) {
      case MODULE_TYPE_CODE.MOD008:
        this.state.modType = "4AI4AO";
        break;
      case MODULE_TYPE_CODE.MOD108:
        this.state.modType = "8AI";
        break;
      case MODULE_TYPE_CODE.MOD012:
        this.state.modType = "8DI4RELAY";
        break;
      case MODULE_TYPE_CODE.MOD016:
        this.state.modType = "8DI8DO";
        break;
      case MODULE_TYPE_CODE.MOD016P:
        this.state.modType = "8DI6DO2PWM";
        break;
      case MODULE_TYPE_CODE.MOD116:
        this.state.modType = "16DI";
        break;
      case MODULE_TYPE_CODE.MOD216:
        this.state.modType = "16DO";
        break;
    }
    // this.state.modType = "8DI4RELAY"; // for testing

    this.initButtons();
    this.loadPage();
  }

  initButtons = () => {
    save.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const snmpAgentEnable = document.getElementById('snmpAgentEnable').checked ? 1 : 0;
        const snmpServer1 = document.getElementById('snmpServer1').value;
        const snmpServer2 = document.getElementById('snmpServer2').value;
        const communityName = document.getElementById('communityName').value;
        const payload = {
          snmpAgentEnable: snmpAgentEnable,
          snmpServer1: snmpServer1,
          snmpServer2: snmpServer2,
          communityName: communityName,
          di: [
            {
              diIndex: 0,
              diEnable: 1,
              diSpecificID: 0
            }
          ],
          do: [
            {
              doIndex: 0,
              doEnable: 1,
              doSpecificID: 8
            }
          ]
        }

        // Determine the type of device
        if (this.state.modType === "8DI4RELAY") {
          this.setParams_8DI4RELAY(customErrorProps, payload);
        } else if (this.state.modType === "8DI6DO2PWM") {
          this.setParams_8DI6DO2PWM(customErrorProps, payload);
        } else if (this.state.modType === "8DI8DO") {
          this.setParams_8DI8DO(customErrorProps, payload);
        } else if (this.state.modType === "16DI") {
          this.setParams_16DI(customErrorProps, payload);
        } else if (this.state.modType === "16DO") {
          this.setParams_16DO(customErrorProps, payload);
        }

        const res = await Api.editSnmpTrapAgent(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

  loadPage = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    try {
      const settings = await Api.getSnmpTrapAgent();
      const snmpAgentEnable = document.getElementById('snmpAgentEnable');
      const snmpServer1 = document.getElementById('snmpServer1');
      const snmpServer2 = document.getElementById('snmpServer2');
      const communityName = document.getElementById('communityName');

      setDomProperty(snmpAgentEnable, "checked", settings?.snmpAgentEnable === 1 ? true : false);
      setDomProperty(snmpServer1, "value", settings?.snmpServer1);
      setDomProperty(snmpServer2, "value", settings?.snmpServer2);
      setDomProperty(communityName, "value", settings?.communityName);

      // Make sure we're displaying the status display
      mainstat.style.display = 'inline';
      loadstat.style.display = 'none';

      // Determine the type of device
      if (this.state.modType === "8DI4RELAY") {
        this.loadPage_8DI4RELAY(settings);
      } else if (this.state.modType === "8DI6DO2PWM") {
        this.loadPage_8DI6DO2PWM(settings);
      } else if (this.state.modType === "8DI8DO") {
        this.loadPage_8DI8DO(settings);
      } else if (this.state.modType === "16DI") {
        this.loadPage_16DI(settings);
      } else if (this.state.modType === "16DO") {
        this.loadPage_16DO(settings);
      }

    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  // **********************************************************************************************
  // **************************************** 8DI4RELAY *******************************************
  // **********************************************************************************************
  setParams_8DI4RELAY(customErrorProps, payload) {
    // Set DI's
    for (let i = 0; i < 8; i++) {
      const diEnable = document.getElementById('enable_' + i).checked ? 1 : 0;
      const diSpecificID = parseInt(document.getElementById('sid_' + i).value);
      if (diSpecificID < 0 || diSpecificID > 20) {
        customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
        throw new CustomError(customErrorProps);
      }
      payload.di[i] = {
        "diIndex": i,
        "diEnable": diEnable,
        "diSpecificID": diSpecificID
      };
    }
    // Set Relay (DO's)
    for (let i = 0; i < 4; i++) {
      const doEnable = document.getElementById('enable_' + (i + 8)).checked ? 1 : 0;
      const doSpecificID = parseInt(document.getElementById('sid_' + (i + 8)).value);
      if (doSpecificID < 0 || doSpecificID > 20) {
        customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
        throw new CustomError(customErrorProps);
      }
      payload.do[i] = {
        "doIndex": i,
        "doEnable": doEnable,
        "doSpecificID": doSpecificID
      };
    }
  }
  //*****************************************************************************************
  loadPage_8DI4RELAY(settings) {
    // Set descriptions
    document.getElementById('headDesc').innerHTML = '8DI4RELAY Trap Settings';
    document.getElementById('channel_a').innerHTML = 'DI Channel';
    document.getElementById('channel_b').innerHTML = 'Relay Channel';

    const dis = settings.di;
    const dos = settings.do;
    for (let i = 0; i < 8; i++) {
      // Set all DI's
      document.getElementById('no_' + i).innerHTML = '' + (i + 1);
      const diEnable = document.getElementById('enable_' + i);
      const diSpecificID = document.getElementById('sid_' + i);
      const di = dis.filter((e) => e.diIndex == i)[0];
      setDomProperty(diEnable, "checked", di?.diEnable === 1 ? true : false);
      setDomProperty(diSpecificID, "value", di?.diSpecificID);
    }
    for (let i = 0; i < 4; i++) {
      // Set all Relay (DO's)
      document.getElementById('no_' + (i + 8)).innerHTML = '' + (i + 1);
      const doEnable = document.getElementById('enable_' + (i + 8));
      const doSpecificID = document.getElementById('sid_' + (i + 8));
      const ds = dos.filter((e) => e.doIndex == i)[0]; // Note: cannot use reserved keyword "do"
      setDomProperty(doEnable, "checked", ds?.doEnable === 1 ? true : false);
      setDomProperty(doSpecificID, "value", ds?.doSpecificID);
    }
    // Hide last 4 checkbox & inputs
    for (let i = 0; i < 4; i++) {
      const doEnable = document.getElementById('enable_' + (i + 12));
      const doSpecificID = document.getElementById('sid_' + (i + 12));
      doEnable.style.display = "none";
      doSpecificID.style.display = "none";
    }
  }

  // **********************************************************************************************
  // **************************************** 8DI6DO2PWM *******************************************
  // **********************************************************************************************
  setParams_8DI6DO2PWM(customErrorProps, payload) {
    // Set DI's
    for (let i = 0; i < 8; i++) {
      const diEnable = document.getElementById('enable_' + i).checked ? 1 : 0;
      const diSpecificID = parseInt(document.getElementById('sid_' + i).value);
      if (diSpecificID < 0 || diSpecificID > 20) {
        customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
        throw new CustomError(customErrorProps);
      }
      payload.di[i] = {
        "diIndex": i,
        "diEnable": diEnable,
        "diSpecificID": diSpecificID
      };
    }
    // Set DO's
    for (let i = 0; i < 6; i++) {
      const doEnable = document.getElementById('enable_' + (i + 8)).checked ? 1 : 0;
      const doSpecificID = parseInt(document.getElementById('sid_' + (i + 8)).value);
      if (doSpecificID < 0 || doSpecificID > 20) {
        customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
        throw new CustomError(customErrorProps);
      }
      payload.do[i] = {
        "doIndex": i,
        "doEnable": doEnable,
        "doSpecificID": doSpecificID
      };
    }
  }
  //*****************************************************************************************
  loadPage_8DI6DO2PWM(settings) {
    // Set descriptions
    document.getElementById('headDesc').innerHTML = '8DI6DO2PWM Trap Settings';
    document.getElementById('channel_a').innerHTML = 'DI Channel';
    document.getElementById('channel_b').innerHTML = 'DO Channel';

    const dis = settings.di;
    const dos = settings.do;
    for (let i = 0; i < 8; i++) {
      // Set all DI's
      document.getElementById('no_' + i).innerHTML = '' + (i + 1);
      const diEnable = document.getElementById('enable_' + i);
      const diSpecificID = document.getElementById('sid_' + i);
      const di = dis.filter((e) => e.diIndex == i)[0];
      setDomProperty(diEnable, "checked", di?.diEnable === 1 ? true : false);
      setDomProperty(diSpecificID, "value", di?.diSpecificID);
    }
    for (let i = 0; i < 6; i++) {
      // Set all DO's
      document.getElementById('no_' + (i + 8)).innerHTML = '' + (i + 1);
      const doEnable = document.getElementById('enable_' + (i + 8));
      const doSpecificID = document.getElementById('sid_' + (i + 8));
      const ds = dos.filter((e) => e.doIndex == i)[0]; // Note: cannot use reserved keyword "do"
      setDomProperty(doEnable, "checked", ds?.doEnable === 1 ? true : false);
      setDomProperty(doSpecificID, "value", ds?.doSpecificID);
    }
    // Hide last 2 checkbox & inputs (2PWM)
    for (let i = 0; i < 2; i++) {
      const doEnable = document.getElementById('enable_' + (i + 14));
      const doSpecificID = document.getElementById('sid_' + (i + 14));
      doEnable.style.display = "none";
      doSpecificID.style.display = "none";
    }
  }

  // **********************************************************************************************
  // **************************************** 8DI8DO **********************************************
  // **********************************************************************************************
  setParams_8DI8DO(customErrorProps, payload) {
    // Set DI's
    for (let i = 0; i < 8; i++) {
      const diEnable = document.getElementById('enable_' + i).checked ? 1 : 0;
      const diSpecificID = parseInt(document.getElementById('sid_' + i).value);
      if (diSpecificID < 0 || diSpecificID > 20) {
        customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
        throw new CustomError(customErrorProps);
      }
      payload.di[i] = {
        "diIndex": i,
        "diEnable": diEnable,
        "diSpecificID": diSpecificID
      };
    }
    // Set DO's
    for (let i = 0; i < 8; i++) {
      const doEnable = document.getElementById('enable_' + (i + 8)).checked ? 1 : 0;
      const doSpecificID = parseInt(document.getElementById('sid_' + (i + 8)).value);
      if (doSpecificID < 0 || doSpecificID > 20) {
        customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
        throw new CustomError(customErrorProps);
      }
      payload.do[i] = {
        "doIndex": i,
        "doEnable": doEnable,
        "doSpecificID": doSpecificID
      };
    }
  }
  //*****************************************************************************************
  loadPage_8DI8DO(settings) {
    // Set descriptions
    document.getElementById('headDesc').innerHTML = '8DI8DO Trap Settings';
    document.getElementById('channel_a').innerHTML = 'DI Channel';
    document.getElementById('channel_b').innerHTML = 'DO Channel';

    const dis = settings.di;
    const dos = settings.do;
    for (let i = 0; i < 8; i++) {
      // Set all DI's
      document.getElementById('no_' + i).innerHTML = '' + (i + 1);
      const diEnable = document.getElementById('enable_' + i);
      const diSpecificID = document.getElementById('sid_' + i);
      const di = dis.filter((e) => e.diIndex == i)[0];
      setDomProperty(diEnable, "checked", di?.diEnable === 1 ? true : false);
      setDomProperty(diSpecificID, "value", di?.diSpecificID);
    }
    for (let i = 0; i < 8; i++) {
      // Set all DO's
      document.getElementById('no_' + (i + 8)).innerHTML = '' + (i + 1);
      const doEnable = document.getElementById('enable_' + (i + 8));
      const doSpecificID = document.getElementById('sid_' + (i + 8));
      const ds = dos.filter((e) => e.doIndex == i)[0]; // Note: cannot use reserved keyword "do"
      setDomProperty(doEnable, "checked", ds?.doEnable === 1 ? true : false);
      setDomProperty(doSpecificID, "value", ds?.doSpecificID);
    }
  }

  // **********************************************************************************************
  // **************************************** 16DI ************************************************
  // **********************************************************************************************
  setParams_16DI(customErrorProps, payload) {
    // Set DI's
    for (let i = 0; i < 16; i++) {
      const diEnable = document.getElementById('enable_' + i).checked ? 1 : 0;
      const diSpecificID = parseInt(document.getElementById('sid_' + i).value);
      if (diSpecificID < 0 || diSpecificID > 20) {
        customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
        throw new CustomError(customErrorProps);
      }
      payload.di[i] = {
        "diIndex": i,
        "diEnable": diEnable,
        "diSpecificID": diSpecificID
      };
    }
    // Remove the DO's
    delete payload.do;
  }
  //*****************************************************************************************
  loadPage_16DI(settings) {
    // Set descriptions
    document.getElementById('headDesc').innerHTML = '16DI Trap Settings';
    document.getElementById('channel_a').innerHTML = 'DI Channel';
    document.getElementById('channel_b').innerHTML = 'DI Channel';

    const dis = settings.di;
    for (let i = 0; i < 16; i++) {
      // Set all DI's
      document.getElementById('no_' + i).innerHTML = '' + (i + 1);
      const diEnable = document.getElementById('enable_' + i);
      const diSpecificID = document.getElementById('sid_' + i);
      const di = dis.filter((e) => e.diIndex == i)[0];
      setDomProperty(diEnable, "checked", di?.diEnable === 1 ? true : false);
      setDomProperty(diSpecificID, "value", di?.diSpecificID);
    }
  }

  // **********************************************************************************************
  // **************************************** 16DO ************************************************
  // **********************************************************************************************
  setParams_16DO(customErrorProps, payload) {
    // Set DO's
    for (let i = 0; i < 16; i++) {
      const doEnable = document.getElementById('enable_' + i).checked ? 1 : 0;
      const doSpecificID = parseInt(document.getElementById('sid_' + i).value);
      if (doSpecificID < 0 || doSpecificID > 20) {
        customErrorProps.data.error.message = "Specific ID must be between 1 and 20";
        throw new CustomError(customErrorProps);
      }
      payload.do[i] = {
        "doIndex": i,
        "doEnable": doEnable,
        "doSpecificID": doSpecificID
      };
    }
    // Remove the DI's
    delete payload.di;
  }
  //*****************************************************************************************
  loadPage_16DO(settings) {
    // Set descriptions
    document.getElementById('headDesc').innerHTML = '16DO Trap Settings';
    document.getElementById('channel_a').innerHTML = 'DO Channel';
    document.getElementById('channel_b').innerHTML = 'DO Channel';

    const dos = settings.do;
    for (let i = 0; i < 16; i++) {
      // Set all DO's
      document.getElementById('no_' + i).innerHTML = '' + (i + 1);
      const doEnable = document.getElementById('enable_' + i);
      const doSpecificID = document.getElementById('sid_' + i);
      const ds = dos.filter((e) => e.doIndex == i)[0];
      setDomProperty(doEnable, "checked", ds?.doEnable === 1 ? true : false);
      setDomProperty(doSpecificID, "value", ds?.doSpecificID);
    }
  }

  dispose() {

  }
}