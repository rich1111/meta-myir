/**
 * For module 8
 */
class Ai4Ao4TuningPage {
  constructor(props) {
    this.state = {
      refereshTime: 1000,
      intervalId: undefined,
      board: [],
    };
    if (currentModuleType != MODULE_TYPE_CODE.MOD008) {
      return;
    }
    this.init();
  }

  init = async () => {
    this.initButtons();
    this.loadPage();
  }

  isFloat = (num) => {
    let pos = num.search("^\d+.?\d*");
    console.log("POSITION>>" + pos);
    if (pos === -1) {
      return false;
    } else {
      return true;
    }
  }

  initButtons = () => {
    const saveButton = document.getElementById("Save");
    saveButton.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const payload = {
          "io": {
            "aiTuning": [
              {
                "aiIndex": 0,
                "aiTuningRaw": 31688
              },
            ],
            "aoTuning": [
              {
                "aoIndex": 0,
                "aoTuningVolRaw": 65535,
                "aoTuningCurVolValue": 6.1
              }
            ]
          },
          "slot": 0
        };

        for (let i = 0; i < 4; i++) {
          const aiTuningRaw_elem = document.getElementById('aiTuningRaw_' + i);
          const aoTuningVolRaw_elem = document.getElementById('aoTuningVolRaw_' + i);
          const aoTuningCurVolValue_elem = document.getElementById('aoTuningCurVolValue_' + i);

          if (
            aiTuningRaw_elem == null ||
            aoTuningVolRaw_elem == null ||
            aoTuningCurVolValue_elem == null
          ) {
            continue;
          }

          const aiTuningRaw = parseInt(aiTuningRaw_elem.value);
          const aoTuningVolRaw = parseInt(aoTuningVolRaw_elem.value);
          const aoTuningCurVolValue = parseFloat(aoTuningCurVolValue_elem.value);

          if (
            !Number.isInteger(aiTuningRaw) ||
            !Number.isInteger(aoTuningVolRaw) ||
            isNaN(aoTuningCurVolValue)) {
            customErrorProps.data.error.message = "Please enter a number!";
            throw new CustomError(customErrorProps);
          }

          if (aiTuningRaw < 0 || aiTuningRaw > 65535) {
            customErrorProps.data.error.message = "AI TuningRaw value must be between 0 and 65535";
            throw new CustomError(customErrorProps);
          } else if (aoTuningVolRaw < 0 || aoTuningVolRaw > 65535) {
            customErrorProps.data.error.message = "AO TuningVolRaw value must be between 0 and 65535";
            throw new CustomError(customErrorProps);
          } else if (aoTuningCurVolValue < 0 || aoTuningCurVolValue > 10) {
            customErrorProps.data.error.message = "AO CurVolValue must be between 0 and 10";
            throw new CustomError(customErrorProps);
          }

          payload.io.aiTuning[i] = {
            "aiIndex": i,
            "aiTuningRaw": aiTuningRaw
          };

          payload.io.aoTuning[i] = {
            "aoIndex": i,
            "aoTuningVolRaw": aoTuningVolRaw,
            "aoTuningCurVolValue": aoTuningCurVolValue
          };
        }
        const res = await Api.editAIAOTuning(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

  onRefreshClick = (e) => {
    e.preventDefault();
    this.loadPage();
  }

  loadPage = async () => {
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    try {
      const aiaoTuning = (await Api.getAIAOTuning()).io;
      const analogInputs = aiaoTuning.aiTuning;
      const analogOutputs = aiaoTuning.aoTuning;

      if (mainstat == null || loadstat == null || !(currentPage instanceof Ai4Ao4TuningPage)) {
        return;
      }

      // Make sure we're displaying the status display
      mainstat.style.display = 'inline';
      loadstat.style.display = 'none';

      for (let i = 0; i < 4; i++) {
        const aiTuningRaw = document.getElementById('aiTuningRaw_' + i);
        const aoTuningVolRaw = document.getElementById('aoTuningVolRaw_' + i);
        const aoTuningCurVolValue = document.getElementById('aoTuningCurVolValue_' + i);

        const input = analogInputs.filter((e) => e.aiIndex == i)[0];
        const output = analogOutputs.filter((e) => e.aoIndex == i)[0];

        setDomProperty(aiTuningRaw, "value", input?.aiTuningRaw);
        setDomProperty(aoTuningVolRaw, "value", output?.aoTuningVolRaw);
        setDomProperty(aoTuningCurVolValue, "value", output?.aoTuningCurVolValue);

        const lastUpdateTimeElem = document.getElementById("lastUpdateTime");
        const now = (new Date()).toUTCString();
        setInnerText(lastUpdateTimeElem, now);
      }
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  dispose() {
    if (currentModuleType != MODULE_TYPE_CODE.MOD008) {
      return;
    }
  }
}
