/**
 * For module 8
 */
class Ai8TuningPage {
  constructor(props) {
    this.state = {
      refreshTime: 1000,
      intervalId: undefined,
      board: [],
    };
    if (currentModuleType != MODULE_TYPE_CODE.MOD108) {
      return;
    }
    this.init();
  }

  init = async () => {
    const { refreshTime } = this.state;

    this.initButtons();
    this.loadPage();

    this.state.intervalId = setInterval(
      this.loadPage, refreshTime
    );
    this.initIntervalSelect();
  }

  isFloat = (num) => {
    let pos = num.search("^\d+.?\d*");
    console.log("POSITION>>" + pos);
    if (pos === -1) {
      return false;
    } else {
      return true;
    }
  }

  initButtons = () => {
    const saveButton = document.getElementById("Save");
    saveButton.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const payload = {
          "io": {
            "aiTuning": [
              {
                "aiIndex": 0,
                "aiTuningRaw": 31688
              },
            ]
          },
          "slot": 0
        };

        for (let i = 0; i < 8; i++) {
          const aiTuningRaw_elem = document.getElementById('aiTuningRaw_' + i);

          if (
            aiTuningRaw_elem == null
          ) {
            continue;
          }

          const aiTuningRaw = parseInt(aiTuningRaw_elem.value);

          if (
            !Number.isInteger(aiTuningRaw)) {
            customErrorProps.data.error.message = "Please enter a number!";
            throw new CustomError(customErrorProps);
          }

          if (aiTuningRaw < 0 || aiTuningRaw > 65535) {
            customErrorProps.data.error.message = "AI TuningRaw value must be between 0 and 65535";
            throw new CustomError(customErrorProps);
          }

          payload.io.aiTuning[i] = {
            "aiIndex": i,
            "aiTuningRaw": aiTuningRaw
          };
        }
        const res = await Api.editAIAOTuning(payload);

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
        // Reload page after 1 seconds
        //setTimeout(() => window.location.reload(true), 1000);
        setTimeout(() => this.loadPage, 1000);
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });

    const manualRefresh = document.getElementById("manualRefresh");
    manualRefresh.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };
      this.loadPage();
    });

    const saveEEProm = document.getElementById("saveToEEProm");
    saveEEProm.addEventListener("click", async (e) => {
      e.preventDefault();
      const customErrorProps = {
        data: {
          error: {
            message: "",
          }
        }
      };

      try {
        const password = document.getElementById("password");
        if (password.value !== "eeprompassword") {
          customErrorProps.data.error.message = "EEPROM password do not match";
          throw new CustomError(customErrorProps);
        }
        const res = await Api.saveEEProm({});

        DialogUtility.showSuccess({
          text: res.error?.message,
        });
        // Clear password
        password.value = "";
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });

    const copyRaw = document.getElementById("copyRaw");
    copyRaw.addEventListener("click", async (e) => {
      e.preventDefault();

      try {
        for (let i = 0; i < 8; i++) {
          const aiValueRaw = document.getElementById('aiValueRaw_' + i);
          const aiTuningRaw = document.getElementById('aiTuningRaw_' + i);

          setDomProperty(aiTuningRaw, "value", aiValueRaw.innerHTML);
        }
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });

    const autoTuning = document.getElementById("autoTuning");
    autoTuning.addEventListener("click", async (e) => {
      e.preventDefault();

      try {
        for (let i = 0; i < 8; i++) {
          const aiValueRaw = document.getElementById('aiValueRaw_' + i);
          const aiTuningRaw = document.getElementById('aiTuningRaw_' + i);

          setDomProperty(aiTuningRaw, "value", aiValueRaw.innerHTML);
        }
        saveButton.click();
      } catch (error) {
        ErrorUtility.handleError(error);
      }
    });
  }

  onRefreshTimeChange = (e) => {
    try {
      const value = parseInt(e.target.value);
      if (isNaN(value)) {
        throw Error();
      }

      this.state.refreshTime = value;

      const { intervalId } = this.state;
      if (intervalId) {
        clearInterval(intervalId);
      }

      this.state.intervalId = setInterval(
        this.loadPage,
        this.state.refreshTime
      );
    } catch (error) {
      console.error(error);
      DialogUtility.showError({
        title: "Change Time Error",
        text: "Changing freshing time failed, please retry",
      });
    }
  }

  initIntervalSelect = () => {
    const refreshSelect = document.getElementById("refresh");
    const {
      refreshTime,
    } = this.state;

    if (refreshSelect) {
      refreshSelect.value = refreshTime;
      refreshSelect.addEventListener('change', this.onRefreshTimeChange);
    }
  }

  loadPage = async () => {
    console.log("loadPage...");
    var mainstat = document.getElementById('display');
    var loadstat = document.getElementById('loading');

    try {
      const aiaoTuning = (await Api.getAIAOTuning()).io;
      const analogInputs = aiaoTuning.aiTuning;

      if (mainstat == null || loadstat == null || !(currentPage instanceof Ai8TuningPage)) {
        return;
      }

      // Make sure we're displaying the status display
      mainstat.style.display = 'inline';
      loadstat.style.display = 'none';

      for (let i = 0; i < 8; i++) {
        const aiTuningRaw = document.getElementById('aiTuningRaw_' + i);

        const input = analogInputs.filter((e) => e.aiIndex == i)[0];

        setDomProperty(aiTuningRaw, "value", input?.aiTuningRaw);

        const lastUpdateTimeElem = document.getElementById("lastUpdateTime");
        const now = (new Date()).toUTCString();
        setInnerText(lastUpdateTimeElem, now);
      }

      const ai = (await Api.getAnalogInput()).io.ai;
      for (let i = 0; i < 8; i++) {
        const aiValueScaled = document.getElementById('aiValueScaled_' + i);
        const aiMode = document.getElementById('aiMode_' + i);
        const aiValueRaw = document.getElementById('aiValueRaw_' + i);

        const input = ai.filter((e) => e.aiIndex == i)[0];

        const aiValue = input?.aiValueScaled?.toFixedNoRounding(3);

        setInnerHTML(aiValueScaled, aiValue);
        setInnerHTML(aiMode, input?.aiMode == 2 ? 'mA' : 'V');
        setInnerHTML(aiValueRaw, input?.aiValueRaw?.toString());


        const last3Digits = aiValue.toString().split(".")[1]

        if (last3Digits === "000" || last3Digits === "001" || last3Digits === "999") {
          setStyle(aiValueScaled, "color", "black");
        } else if (last3Digits === "002" || last3Digits === "998") {
          setStyle(aiValueScaled, "color", "orange");
        } else {
          setStyle(aiValueScaled, "color", "red");
        }
      }
    } catch (error) {
      console.error(error);
      if (mainstat == null || loadstat == null) {
        return;
      }
      mainstat.style.display = 'none';
      loadstat.style.display = 'inline';
    }
  }

  dispose() {
    const { intervalId } = this.state;
    if (intervalId) {
      clearInterval(intervalId);
    }
  }
}
