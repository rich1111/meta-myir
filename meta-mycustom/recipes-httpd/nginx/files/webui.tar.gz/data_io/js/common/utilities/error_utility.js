class ErrorUtility { }

const ERROR_MSG_BY_CODE = {
  101: "The content version specified in the request is not supported.",
  102: "The document format specified in the request is not supported.",
  201: "The json format in the request is invalid.",
  202: "One of the node values is invalid.",
  203: "The I/O channels are disordered.",
  204: "A required channel index was not specified in the request body.",
  300: "One of the channel content in the request could not be set. Please refer to the detail information.",
  301: "The content in the request could not be set. (invalid value)",
}

ErrorUtility.handleError = (error, options) => {
  console.error("ErrorUtility:", error);

  let errorData;
  if (error.isCustom) {
    errorData = error.props?.data?.error;
  }

  let errorMsg;
  if (errorData !== undefined) {
    const errorCode = errorData.code;
    const prefixErrorMsg = errorCode != undefined ? `[E${errorCode}]` : "";

    errorMsg = ERROR_MSG_BY_CODE[errorCode];

    if (StringUtility.isNothingOrEmpty(errorMsg)) {
      errorMsg = `${prefixErrorMsg} ${errorData.message}`;
      if (options?.appendMsg) {
        errorMsg += options.appendMsg;
      }
    }
  }

  DialogUtility.showError({
    title: options?.title,
    text: errorMsg,
  });
}
