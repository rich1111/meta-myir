class DialogUtility { }

DialogUtility.confirm = ({
  title, text, confirmButtonText,
}) => {
  return Swal.fire({
    icon: 'warning',
    title: title || "Are you sure?",
    text: text,
    width: '450px',
    showCancelButton: true,
    confirmButtonText: confirmButtonText || "Yes"
  });
}

DialogUtility.showSuccess = ({
  title, text, confirmButtonText,
}) => {
  return Swal.fire({
    icon: 'success',
    title: title || "Success",
    text: text,
    confirmButtonText: confirmButtonText || "Confirm",
    width: '250px', // 設定對話框寬度
    showConfirmButton: false, // 移除確認按鈕
    timer: 2000,
    //position: 'top-end', // 設定對話框位置
  });
}

DialogUtility.showError = ({
  title, text, confirmButtonText,
}) => {
  return Swal.fire({
    icon: 'error',
    title: title || "Error",
    text: text || "Unknown Error",
    width: '450px',
    confirmButtonText: confirmButtonText || "Confirm"
  });
}

DialogUtility.showLoading = ({ }) => {
  return Swal.fire({
    title: 'Please Wait !',
    html: 'data uploading',// add html attribute if you want or remove
    allowOutsideClick: false,
    showConfirmButton: false,
    onBeforeOpen: () => {
      Swal.showLoading()
    },
  });
}

DialogUtility.closeLoading = () => {
  swal.close();
}
