setDomProperty = (dom, propertyName, value) => {
  if (dom != null) {
    dom[propertyName] = value;
  }
}

setValue = (dom, value) => {
  if (dom != null) {
    dom['value'] = value;
  }
}

setInnerText = (dom, value) => {
  if (dom != null) {
    dom.innerText = value;
  }
}

setInnerHTML = (dom, value) => {
  if (dom != null) {
    dom.innerHTML = value;
  }
}

setStyle = (dom, name, value) => {
  if (dom != null) {
    dom.style[name] = value;
  }
}

setCircle = (dom, flag, options) => {
  const {
    fillColor,
  } = options || {};

  const FILL_CIRCLE = "&#9679;";
  const HOLLOW_CIRCLE = "&#9675;";

  const FILL_COLOR = fillColor || "#00FF00";
  const HOLLOW_COLOR = "#000000";

  if (dom != null) {
    dom.innerHTML = flag ? FILL_CIRCLE : HOLLOW_CIRCLE;
    dom.style.color = flag ? FILL_COLOR : HOLLOW_COLOR;
    dom.style.fontSize = "126%";
  }
}

setCircleWithFont = (dom, flag) => {
  dom.style.border = "1px solid #000";
  dom.style.borderRadius = "50%";
  dom.style.display = "inline-block";
  dom.style.textAlign = "center";
  dom.style.width = "26px";
  dom.innerHTML = flag ? "H" : "L";
  dom.style.color = flag ? "#00FF00" : "#000000";
}

setFormatUniform = (value) => {  
  if(value < 10) {
    return `0${value}`;
  } else {
    return value;
  }
}
setDisable = async () => {
  const role = sessionStorage.getItem('role');
  const inputs = document.querySelectorAll('input[type="text"], input[type="number"], input[type="checkbox"], input[type="file"]');
  const selects = document.querySelectorAll('select');

  if(role !== 'admin') {
    if(inputs){
      inputs.forEach(input => {
        input.disabled = true;
      });
    }
    if(selects){
      selects.forEach(select => {
        select.disabled = true;
      });
    }
  }
}
setDisableWithRadio = () => {
  const role = sessionStorage.getItem('role');
  const inputs = document.querySelectorAll('input[type="text"], input[type="number"], input[type="checkbox"], input[type="file"], input[type="radio"], input[type="password"]');
  const selects = document.querySelectorAll('select');

  if(role !== 'admin') {
    if(inputs){
      inputs.forEach(input => {
        input.disabled = true;
      });
    }
    if(selects){
      selects.forEach(select => {
        select.disabled = true;
      });
    }
  }
}
setDisableWithButton = () => {
  const role = sessionStorage.getItem('role');
  const inputs = document.querySelectorAll('input[type="text"], input[type="number"], input[type="checkbox"], input[type="file"], input[type="radio"], input[type="password"]');
  const selects = document.querySelectorAll('select');
  const buttons = document.querySelectorAll('button');

  if(role !== 'admin') {
    if(inputs){
      inputs.forEach(input => {
        input.disabled = true;
      });
    }
    if(selects){
      selects.forEach(select => {
        select.disabled = true;
      });
    }
    if(buttons){
      buttons.forEach(button => {
        button.disabled = true;
      });
    }
  }
}
setDisableSingleOrButton = (dom) => {
  const role = sessionStorage.getItem('role');
  if(role !== 'admin') {
    dom.disabled = true;
  }
}
setDisableAllButton = () => {
  const role = sessionStorage.getItem('role');
  if(role !== 'admin') {
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
      button.disabled = true;
    });
  }
}
setDisableAllCheckbox = () => {
  const role = sessionStorage.getItem('role');
  if(role !== 'admin') {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
      checkbox.disabled = true;
    });
  }
}
