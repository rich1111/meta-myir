pushNamed = (pathName, options) => {
  if (options?.event) {
    event.preventDefault();
  }

  const search = window.location.search;
  let queryString = "";
  if (search.startsWith("?")) {
    const a = new URLSearchParams(search);
    const deviceIpOnSubNetwork = a.get("data_io_ip");
    if (deviceIpOnSubNetwork) {
      queryString = "?data_io_ip=" + deviceIpOnSubNetwork;
    }
  }

  window.history.pushState(
    {},
    pathName,
    basePath + pathName + queryString
  );
  replacePageContent(options);
}

window.onpopstate = () => {
  replacePageContent();
}

replacePageContent = (options) => {
  let path = getPathName();
  path = pathHandler(path);
  if (path === false) {
    throw Error();
  }

  const route = routes[path];
  if (route) {
    if (typeof currentPage?.dispose === "function") {
      currentPage.dispose();
    }
    mainContentElem.innerHTML = route.pageContent;
    currentPage = new route.constructor(options);
  }
}

getPathName = () => {
  let path = window.location.pathname;
  if (path.startsWith(`/${baseMidllePath}`)) {
    path = path.replace(`/${baseMidllePath}`, '');
  }
  return path;
}

pathHandler = (pathName) => {
  console.log("pathName=", pathName, currentModuleType);
  if (pathName === "/" || pathName === "") {
    return `/about`;
  }
  // if (pathName === "/" || pathName === "") {
  //   switch (currentModuleType) {
  //     case MODULE_TYPE_CODE.MOD008:
  //       return `/home_${MODULE_TYPE_TEXT.MOD008}`;
  //     case MODULE_TYPE_CODE.MOD108:
  //       return `/home_${MODULE_TYPE_TEXT.MOD108}`;
  //     case MODULE_TYPE_CODE.MOD208:
  //       return `/home_${MODULE_TYPE_TEXT.MOD208}`;
  //     case MODULE_TYPE_CODE.MOD012:
  //       return `/home_${MODULE_TYPE_TEXT.MOD012}`;
  //     case MODULE_TYPE_CODE.MOD016:
  //       return `/home_${MODULE_TYPE_TEXT.MOD016}`;
  //     case MODULE_TYPE_CODE.MOD016P:
  //       return `/home_${MODULE_TYPE_TEXT.MOD016P}`;
  //     case MODULE_TYPE_CODE.MOD116:
  //       return `/home_${MODULE_TYPE_TEXT.MOD116}`;
  //     case MODULE_TYPE_CODE.MOD216:
  //       return `/home_${MODULE_TYPE_TEXT.MOD216}`;
  //   }
  // } else if (pathName === "/Digital") {
  //   switch (currentModuleType) {
  //     case MODULE_TYPE_CODE.MOD016:
  //       return '/Digital';
  //     case MODULE_TYPE_CODE.MOD008:
  //     case MODULE_TYPE_CODE.MOD108:
  //     case MODULE_TYPE_CODE.MOD012:
  //       pushNamed("/");
  //       return false;
  //     case MODULE_TYPE_CODE.MOD116:
  //       return `/digital_${MODULE_TYPE_TEXT.MOD116}`;
  //     case MODULE_TYPE_CODE.MOD216:
  //       return `/digital_${MODULE_TYPE_TEXT.MOD216}`;
  //   }
  // }
  return pathName;
}

