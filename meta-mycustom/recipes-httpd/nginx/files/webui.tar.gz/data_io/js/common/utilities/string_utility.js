class StringUtility { }
class StringXUtility { }

StringUtility.isNothingOrEmpty = (str) => {
  if (str === null || str === undefined || str === "") {
    return true;
  }
  return false;
}
StringXUtility.isNothingOrEmpty = (str) => {
  if (str === null || str === undefined || str === "") {
    return true;
  }
  return false;
}

StringUtility.validIP = (address) => {
  if (address === null || address === "") return false;

  var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (address.match(ipformat)) {
    return true;
  } else {
    return false;
  }
}

StringXUtility.validIP = (address) => {
  if (address === null || address === "") return false;

  var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(X|25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(X|25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  if (address.match(ipformat)) {
    return true;
  } else {
    return false;
  }
}