// Used only for Api.login
async function httpPostX(url, options) {
    if (typeof options?.data === "object") {
        options.data = JSON.stringify(options.data);
    }

    const res = await fetch(url, {
        method: "POST",
        body: options?.data,
        headers: {
            'Content-Type': 'application/json',
            'Accept': '*/*'
        },
    });

    const resData = await res.json();
    if (res.status !== 200 && res.status !== 401) {
        throw new CustomError({
            status: res.status,
            data: resData,
        })
    }
    console.log("httpPostX: result=", resData);
    return resData;
}

// Used only for Api.iosearch
async function httpGetWithoutToken(url, options) {
    // Get "JWT" token from session and put in header
    const res = await fetch(url, {
        method: "GET",
        headers: {
            'Content-Type': 'application/json',
            'Accept': '*/*',
        },
    });

    const resData = await res.json();
    console.log("httpGetX: result=", resData);
    return resData;
}

// Used only for Api.refreshToken
async function httpGetX(url, options) {
    // Get "JWT" token from session and put in header
    const res = await fetch(url, {
        method: "GET",
        headers: {
            'Content-Type': 'application/json',
            'Accept': '*/*',
            'Authorization': "Bearer " + sessionStorage.getItem('token')
        },
    });

    const resData = await res.json();
    console.log("httpGetX: result=", resData);
    return resData;
}

async function httpGet(url, options) {
    await checkSessionExpiry();
    console.log("url =", url);
    
    // Get "JWT" token from session and put in header
    const res = await fetch(url, {
        method: "GET",
        headers: {
            'Content-Type': 'application/json',
            'Accept': '*/*',
            'Authorization': "Bearer " + sessionStorage.getItem('token')
        },
    });
    const contentType = res.headers.get("Content-Type");
    let resData;
    
    if (contentType && contentType.includes("application/json")) {
        resData = await res.json();
    } else if (contentType && contentType.includes("application/octet-stream") || contentType.includes("text/plain")) {
        resData = await res.blob(); // 用 blob 處理二進位資料
    }
    //  else if (contentType) {
    //     resData = await res.text(); // 用 text 處理純文字資料
    // }
    console.log("httpGet: result=", resData);
    return resData;
}

async function httpPut(url, options) {
    console.log("httpPut: url=", url, "options=", options);
    await checkSessionExpiry();
    const fetchOptions = {
        method: "PUT",
        headers: {
            'Content-Type': 'application/json',
            'Accept': '*/*',
            'Authorization': "Bearer " + sessionStorage.getItem('token')
        }
    };

    // 如果有資料，就將其轉換成 JSON 並設置 body
    if (options?.data) {
        fetchOptions.body = JSON.stringify(options.data);
    }

    const res = await fetch(url, fetchOptions);
    const resData = await res.json();
    console.log("httpPut: result=", resData);
    return resData;
}

async function httpPost(url, options) {
    await checkSessionExpiry();
    if (typeof options?.data === "object") {
        options.data = JSON.stringify(options.data);
    }
    console.log(options, options?.data);
    
    // Get "JWT" token from session and put in header
    const res = await fetch(url, {
        method: "POST",
        body: options?.data,
        headers: {
            'Content-Type': 'application/json',
            'Accept': '*/*',
            'Authorization': "Bearer " + sessionStorage.getItem('token')
        },
    });
    const resData = await res.json();
    console.log("httpPost: result=", resData);
    return resData;
}

async function httpPostFile(url, { file }, appendType) {
    console.log("file=", file);
    
    await checkSessionExpiry();
    const formData = new FormData();
    formData.append(appendType, file);

    // Get "JWT" token from session and put in header
    const res = await fetch(url, {
        method: "POST",
        body: formData,
        // 不需要加上此行 (ref: https://blog.csdn.net/zhangbo1116/article/details/88790740)
        // 'Content-Type': 'multipart/form-data'
        // 因為 fetch 會自動根據 FormData 對象的內容設置適當的 Content-Type
        headers: {
            'Accept': '*/*',
            'Authorization': "Bearer " + sessionStorage.getItem('token')
        },
    });
    const resData = await res.text();
    console.log("httpPostFile: result=", resData);

    return resData;
}

async function checkSessionExpiry() {
    // If last event over 15 minutes
    const lastEvent = new Date(sessionStorage.getItem("last-event")).getTime();
    if (lastEvent < (Date.now() - (15 * 60 * 1000))) {
        // logout of system
        await DialogUtility.showError({
            title: 'Session Expired', text: 'Please login again!'
        }).then((result) => {
            sessionStorage.clear();
            location.replace("./login.html");
        });
    }

    // Check if token near expiry, will expire 10 minutes from now?
    if ((Date.now() + (10 * 60 * 1000)) > new Date(sessionStorage.getItem("expire")).getTime()) {
        console.log("Token near expiry, refresh token!");
        // Refresh token here
        if (sessionStorage.getItem("refresh") === null || sessionStorage.getItem("refresh") === "false") {
            sessionStorage.setItem("refresh", true);
            try {
                const res = await Api.refreshToken();
                sessionStorage.setItem("expire", res.expire);
                sessionStorage.setItem("token", res.token);
            } catch (error) {
                console.log("Error refreshing token: ", error);
            }
            sessionStorage.setItem("refresh", false);
        }
    }
    // Reset last-event to now
    sessionStorage.setItem("last-event", new Date().toISOString());
}
async function checkTokenExpiry(res) {
    if(res.message === "Token expired") {
        await DialogUtility.showError({
            title: 'Token Expired', text: 'Please login again!'
        }).then((result) => {
            sessionStorage.clear();
            location.replace("./login.html");
        });
    }
}
