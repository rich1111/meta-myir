
class Api { }

Api.login = async (payload, options) => {
  const res = await httpPostX(`${baseNoAuthUrl}/login${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.iosearch = async(options) => {
  const res = await httpGetWithoutToken(`${baseNoAuthUrl}/iosearch${baseApiUrlSuffix}`);
  return res;
}

// Api.ipSearchio 有問疑時可以改用這個
// Api.io = async(options) => {
//   const res = await httpGetWithoutToken(`${baseNoAuthUrl}/io${baseApiUrlSuffix}`);
//   return res;
// }

Api.refreshToken = async (options) => {
  console.log("Token refreshing ...");
  const res = await httpGetX(`${baseApiUrl}/refresh_token${baseApiUrlSuffix}`);
  return res;
}

Api.changePassword = async (payload, options) => {
  const res = await httpPost(`${baseApiUrl}/change_user_pass${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}
Api.adminChangePassword = async (payload, options) => {
  const res = await httpPost(`${baseApiUrl}/admin_change_user_pass${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.getNetConfig = async (options) => {
  const res = await httpGet(`${baseApiUrl}/get_net_config${baseApiUrlSuffix}`);
  return res;
}

Api.setNetConfig = async (payload, options) => {
  const res = await httpPost(`${baseApiUrl}/change_net_config${baseApiUrlSuffix}`, {
    data: payload
  });
  return res;
}

Api.getPowerlinkConfig = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/powerlink${baseApiUrlSuffix}`);
  return res;
}

Api.setPowerlinkConfig = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/powerlink${baseApiUrlSuffix}`, {
    data: payload
  });
  return res;
}

Api.getSparkplugConfig = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/sparkplug${baseApiUrlSuffix}`);
  return res;
}

Api.setSparkplugConfig = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/sparkplug${baseApiUrlSuffix}`, {
    data: payload
  });
  return res;
}

Api.getSysInfo = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/sysInfo${baseApiUrlSuffix}`);
  return res;
}

Api.getDevice = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/sysInfo/device${baseApiUrlSuffix}`);
  return res;
}

Api.getNetwork = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/sysInfo/network${baseApiUrlSuffix}`);
  return res;
}

Api.editNetwork = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/sysInfo/network${baseApiUrlSuffix}`);
  return res;
}

Api.getNetworkLan = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/sysInfo/network/LAN${baseApiUrlSuffix}`);
  return res;
}

Api.editNetworkLan = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/sysInfo/network/LAN${baseApiUrlSuffix}`);
  return res;
}

Api.getDigitalInput = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/di${baseApiUrlSuffix}`);
  return res;
}

Api.editDigitalInput = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/di${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.getPwm = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/pwm${baseApiUrlSuffix}`);
  return res;
}

Api.editPwm = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/pwm${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.editDigitalInputByPort = async (payload, options) => {
  const {
    port, diStatus, diCounterValue, diCounterOverflowFlag, diCounterReset, diCounterOverflowClear, diCounterStatus,
  } = payload || {};

  let requestData = {
    io: {
      di: [
        {
          diIndex: port,
        }
      ]
    },
    slot: 0
  };

  if (diStatus !== undefined) { requestData.io.di[0].diStatus = diStatus; }
  if (diCounterValue !== undefined) { requestData.io.di[0].diCounterValue = diCounterValue; }
  if (diCounterOverflowFlag !== undefined) { requestData.io.di[0].diCounterOverflowFlag = diCounterOverflowFlag; }
  if (diCounterReset !== undefined) { requestData.io.di[0].diCounterReset = diCounterReset; }
  if (diCounterOverflowClear !== undefined) { requestData.io.di[0].diCounterOverflowClear = diCounterOverflowClear; }
  if (diCounterStatus !== undefined) { requestData.io.di[0].diCounterStatus = diCounterStatus; }

  const res = await httpPut(`${baseApiUrl}/slot/0/io/di/${port}${baseApiUrlSuffix}`, {
    data: requestData,
  });
  return res;
}

Api.getDigitalOutput = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/do${baseApiUrlSuffix}`);
  return res;
}

Api.editDigitalOutput = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/do${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.editDigitalOutputByPort = async (payload, options) => {
  const {
    port, doMode, doStatus, doDefaultEnable, doDefaultValue, doPulseStatus
  } = payload || {};

  let requestData = {
    io: {
      do: [
        {
          doIndex: port,
        }
      ]
    },
    slot: 0
  };

  if (doMode !== undefined) { requestData.io.do[0].doMode = doMode; }
  if (doStatus !== undefined) { requestData.io.do[0].doStatus = doStatus; }
  if (doDefaultEnable !== undefined) { requestData.io.do[0].doDefaultEnable = doDefaultEnable; }
  if (doDefaultValue !== undefined) { requestData.io.do[0].doDefaultValue = doDefaultValue; }
  if (doPulseStatus !== undefined) { requestData.io.do[0].doPulseStatus = doPulseStatus; }

  const res = await httpPut(`${baseApiUrl}/slot/0/io/do/${port}${baseApiUrlSuffix}`, {
    data: requestData,
  });
  return res;
}

// AI Calibration
Api.getAIOffsetGain = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/aiOffsetGain${baseApiUrlSuffix}`);
  return res;
}
Api.setAISystemOffsetCal = async (options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/aiSystemOffsetCal${baseApiUrlSuffix}`);
  return res;
}
Api.setAISystemGainCal = async (options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/aiSystemGainCal${baseApiUrlSuffix}`);
  return res;
}
Api.setAIInternalCal = async (options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/aiInternalCal${baseApiUrlSuffix}`);
  return res;
}

// AI Temperature
Api.getAITemp = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/aiGetTemperature${baseApiUrlSuffix}`);
  return res;
}
Api.setAITemp = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/aiSetTemperature${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

// AI/AO Tuning parameters
Api.getAIAOTuning = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/aiaoTuning${baseApiUrlSuffix}`);
  return res;
}
Api.editAIAOTuning = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/aiaoTuning${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}
Api.saveEEProm = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/eepromWriteDefault${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

// 以下先不做（因為有 ai,ao）
Api.getAnalogInput = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/ai${baseApiUrlSuffix}`);
  return res;
}

Api.getAnalogInputByPort = async (options) => {
  const port = options?.port || 0;
  const res = await httpGet(`${baseApiUrl}/slot/0/io/ai/${port}${baseApiUrlSuffix}`);
  return res;
}

Api.getAnalogOutput = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/ao${baseApiUrlSuffix}`);
  return res;
}

Api.editAnalogOutput = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/ao${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.restore = async () => {
  let requestData = {
    sysInfo: {
      restore: [
        {
          restoreDefault: 1,
        }
      ]
    },
    slot: 0
  };

  const res = await httpPut(`${baseApiUrl}/slot/0/sysInfo/restore`, {
    data: requestData,
  });
  return res;
}

Api.uploadFile = async (file, appendType) => {
  const res = await httpPostFile(`${baseApiUrl}/upload`, { file }, appendType);
  return res;
}

Api.getModbusAddressAgent = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/modbusAddress${baseApiUrlSuffix}`);
  return res;
}

Api.editModbusAddressAgent = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/modbusAddress${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.getSnmpTrapAgent = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/snmpTrapAgent${baseApiUrlSuffix}`);
  return res;
}

Api.editSnmpTrapAgent = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/snmpTrapAgent${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.getSnmpV3TrapAgent = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/snmpV3TrapAgent${baseApiUrlSuffix}`);
  return res;
}

Api.editSnmpV3TrapAgent = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/snmpV3TrapAgent${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.getMqttAgent = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/mqtt${baseApiUrlSuffix}`);
  return res;
}

Api.editMqttAgent = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/mqtt${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.getOpcuaAgent = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/opcuaSecurity${baseApiUrlSuffix}`);
  return res;
}

Api.editOpcuaAgent = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/opcuaSecurity${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}

Api.downloadCertFile = async (options) => {
  const res = await httpGet(`${baseApiUrl}/download/server_cert.der${baseApiUrlSuffix}`);
  return res;
}

Api.downloadKeyFile = async (options) => {
  const res = await httpGet(`${baseApiUrl}/download/server_key.pem${baseApiUrlSuffix}`);
  return res;
}

Api.getAwsConfigs = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/sysInfo/awsiot`);
  return res;
}

Api.editAwsConfigs = async (payload, options) => {
  let requestData = {
    sysInfo: {
      awsiot: [
        {
          // below inputs types: number (0 or 1)
          awsiotEnable: payload.awsiotEnable,
          connectionStatus: payload.connectionStatus,
          // below inputs types: string
          targetHost: payload.targetHost || "",
          topic: payload.topic || "",
          clientID: payload.clientID || "",
          thingName: payload.thingName || "",
          rootCAFile: payload.rootCAFile || "",
          certificateFile: payload.certificateFile || "",
          privateKeyFile: payload.privateKeyFile || "",
        }
      ]
    },
    slot: 0
  };

  const res = await httpPut(`${baseApiUrl}/slot/0/sysInfo/awsiot`, {
    data: requestData,
  });
  return res;
}

Api.getAzureConfigs = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/sysInfo/azureiot`);
  return res;
}

Api.editAzureConfigs = async (payload, options) => {
  let requestData = {
    sysInfo: {
      azureiot: [
        {
          // below inputs types: number (0 or 1)
          azureiotEnable: payload.azureiotEnable,
          connectionStatus: payload.connectionStatus,
          // below inputs types: string
          deviceConnectionString: payload.deviceConnectionString || "",
        }
      ]
    },
    slot: 0
  };

  const res = await httpPut(`${baseApiUrl}/slot/0/sysInfo/azureiot`, {
    data: requestData,
  });
  return res;
}

// I/O Setting
Api.getAlias = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io`);
  return res;
}
Api.editAlias = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io`, {
    data: payload,
  });
  return res;
}

// System Configuration
Api.getNameAndLocation = async (options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/sysGetNameLocation`);
  return res;
}
Api.editNameAndLocation = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/sysSetNameLocation`, {
    data: payload,
  });
  return res;
}
Api.getTimeConfig = async (options) => {
  const res = await httpGet(`${baseApiUrl}/get_time_setting`);
  return res;
}
Api.setTimeConfig = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/set_system_time`, {
    data: payload,
  });
  return res;
}

Api.setNTP = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/set_ntp_servers`, {
    data: payload,
  });
  return res;
}
Api.setTimeZone = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/set_time_zone`, {
    data: payload,
  });
  return res;
}
Api.syncNTP = async () => {
  const res = await httpPut(`${baseApiUrl}/sync_ntp_time`);
  return res;
}

Api.getFirewallConfig = async (options) => {
  const res = await httpGet(`${baseApiUrl}/get_firewall`);
  return res;
}

Api.editFirewallConfig = async (payload, options) => {
  const res = await httpPut(`${baseApiUrl}/set_firewall`, {
    data: payload,
  });
  return res;
}

// Peer to Peer
Api.getPeerToPeerSettings = async(payload) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/peerToPeer`);
  return res;
}
Api.editPeerToPeerSettings = async(payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/peerToPeer`, {
    data: payload,
  });
  return res;
}
Api.updateFirmware = async(file, appendType) => {
  const res = await httpPostFile(`${baseApiUrl}/updateFirmware`, { file }, appendType);
  return res;
}
Api.ipSearch = async(payload, options) => {
  const res = await httpPost(`${baseApiUrl}/ipsearch`, {
    data: payload,
  });
  return res;
}
Api.ipSearchio = async(payload, options) => {
  const res = await httpPost(`${baseApiUrl}/ipsearchio`, {
    data: payload,
  });
  return res;
}

//MQTT
Api.getMqttConfigs = async(options) => {
  const res = await httpGet(`${baseApiUrl}/slot/0/io/mqttClientICP${baseApiUrlSuffix}`);
  return res;
}

Api.editMqttConfigs = async(payload, options) => {
  const res = await httpPut(`${baseApiUrl}/slot/0/io/mqttClientICP${baseApiUrlSuffix}`, {
    data: payload,
  });
  return res;
}
