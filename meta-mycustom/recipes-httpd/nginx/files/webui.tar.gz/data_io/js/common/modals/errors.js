class CustomError extends Error {
  constructor(props, ...args) {
    console.log(props);
    super(...args);
    this.isCustom = true;
    this.props = props;
  }
}
