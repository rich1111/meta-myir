// value can be MODULE_TYPE_CODE.MOD016 or ... (in const.js)
let currentModuleType = undefined;

let mainContentElem;
let mainPageLoadingHint;

let routes = {};
let routePages = {};
let replacePageContent = () => { };
let currentPage;

let basePath;
let baseMidllePath;
// let baseApiUrlNoApi = `${window.location.origin}`;
let baseApiUrl = `${window.location.origin}/api`;
let baseNoAuthUrl = `${window.location.origin}/noauth`;
let baseApiUrlSuffix = "";