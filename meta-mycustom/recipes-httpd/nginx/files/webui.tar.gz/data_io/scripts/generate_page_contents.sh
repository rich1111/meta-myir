
echo 產生 js，內有一個變數，保有頁面內容

search_dir=$(pwd)
echo $search_dir

pageHtmlContents="const pageHtmlContents = {};"

for entry in "$search_dir"/*.htm
do
  echo "$entry"
  html_content="$(cat $entry | tr "\`" "\\\`")"
  r=$'\\\`'
  html_content="${html_content//\`/$r}"

  html_filename=${entry##*/}

  newContent="pageHtmlContents['$html_filename']=\`$html_content\`;"
  pageHtmlContents=$pageHtmlContents$newContent
done

if [ ! -d js/generated ]; then
  mkdir -p js/generated;
fi

cd js/generated

rm pageHtmlContents.js
touch pageHtmlContents.js
echo $pageHtmlContents >> pageHtmlContents.js