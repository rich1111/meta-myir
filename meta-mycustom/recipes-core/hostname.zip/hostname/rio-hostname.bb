SUMMARY = "Set hostname to RIO-<MACADDR>"
LICENSE = "MIT"
PR = "r0"

SRC_URI = ""

S = "${WORKDIR}"

do_install() {
    install -d ${D}${sysconfdir}/init.d

    cat << 'EOF' > ${D}${sysconfdir}/init.d/rio-hostname
#!/bin/sh
### BEGIN INIT INFO
# Provides:          rio-hostname
# Required-Start:    
# Required-Stop:     
# Default-Start:     S
# Default-Stop:      
# Short-Description: Set hostname based on eth0 MAC address
### END INIT INFO

case "$1" in
  start)
    if [ -e /sys/class/net/eth0/address ]; then
        MAC=$(cat /sys/class/net/eth0/address | tr -d ':')
        HOST="RIO-${MAC}"
        echo "${HOST}" > /etc/hostname
        hostname "${HOST}"
    fi
    ;;
  *)
    echo "Usage: $0 start"
    exit 1
    ;;
esac

exit 0
EOF

    chmod +x ${D}${sysconfdir}/init.d/rio-hostname

    # Link to runlevel
    install -d ${D}${sysconfdir}/rcS.d
    ln -sf ../init.d/rio-hostname ${D}${sysconfdir}/rcS.d/S01rio-hostname
}

FILES:${PN} += "${sysconfdir}/init.d/rio-hostname ${sysconfdir}/rcS.d/S01rio-hostname"
